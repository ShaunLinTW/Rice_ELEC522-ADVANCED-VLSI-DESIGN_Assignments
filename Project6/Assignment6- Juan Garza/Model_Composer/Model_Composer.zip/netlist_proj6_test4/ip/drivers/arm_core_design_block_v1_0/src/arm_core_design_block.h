#ifndef ARM_CORE_DESIGN_BLOCK__H
#define ARM_CORE_DESIGN_BLOCK__H
#ifdef __cplusplus
extern "C" {
#endif
/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "arm_core_design_block_hw.h"
/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
#else
typedef struct {
    u16 DeviceId;
    u32 arm_core_design_block_BaseAddress;
} arm_core_design_block_Config;
#endif
/**
* The arm_core_design_block driver instance data. The user is required to
* allocate a variable of this type for every arm_core_design_block device in the system.
* A pointer to a variable of this type is then passed to the driver
* API functions.
*/
typedef struct {
    u32 arm_core_design_block_BaseAddress;
    u32 IsReady;
} arm_core_design_block;
/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define arm_core_design_block_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define arm_core_design_block_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define arm_core_design_block_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define arm_core_design_block_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif
/************************** Function Prototypes *****************************/
#ifndef __linux__
int arm_core_design_block_Initialize(arm_core_design_block *InstancePtr, u16 DeviceId);
arm_core_design_block_Config* arm_core_design_block_LookupConfig(u16 DeviceId);
int arm_core_design_block_CfgInitialize(arm_core_design_block *InstancePtr, arm_core_design_block_Config *ConfigPtr);
#else
int arm_core_design_block_Initialize(arm_core_design_block *InstancePtr, const char* InstanceName);
int arm_core_design_block_Release(arm_core_design_block *InstancePtr);
#endif
/**
* Write to b_4 gateway of arm_core_design_block. Assignments are LSB-justified.
*
* @param	InstancePtr is the b_4 instance to operate on.
* @param	Data is value to be written to gateway b_4.
*
* @return	None.
*
* @note    .
*
*/
void arm_core_design_block_b_4_write(arm_core_design_block *InstancePtr, int Data);
/**
* Read from b_4 gateway of arm_core_design_block. Assignments are LSB-justified.
*
* @param	InstancePtr is the b_4 instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int arm_core_design_block_b_4_read(arm_core_design_block *InstancePtr);
/**
* Write to b_3 gateway of arm_core_design_block. Assignments are LSB-justified.
*
* @param	InstancePtr is the b_3 instance to operate on.
* @param	Data is value to be written to gateway b_3.
*
* @return	None.
*
* @note    .
*
*/
void arm_core_design_block_b_3_write(arm_core_design_block *InstancePtr, int Data);
/**
* Read from b_3 gateway of arm_core_design_block. Assignments are LSB-justified.
*
* @param	InstancePtr is the b_3 instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int arm_core_design_block_b_3_read(arm_core_design_block *InstancePtr);
/**
* Write to b_2 gateway of arm_core_design_block. Assignments are LSB-justified.
*
* @param	InstancePtr is the b_2 instance to operate on.
* @param	Data is value to be written to gateway b_2.
*
* @return	None.
*
* @note    .
*
*/
void arm_core_design_block_b_2_write(arm_core_design_block *InstancePtr, int Data);
/**
* Read from b_2 gateway of arm_core_design_block. Assignments are LSB-justified.
*
* @param	InstancePtr is the b_2 instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int arm_core_design_block_b_2_read(arm_core_design_block *InstancePtr);
/**
* Write to b_1 gateway of arm_core_design_block. Assignments are LSB-justified.
*
* @param	InstancePtr is the b_1 instance to operate on.
* @param	Data is value to be written to gateway b_1.
*
* @return	None.
*
* @note    .
*
*/
void arm_core_design_block_b_1_write(arm_core_design_block *InstancePtr, int Data);
/**
* Read from b_1 gateway of arm_core_design_block. Assignments are LSB-justified.
*
* @param	InstancePtr is the b_1 instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int arm_core_design_block_b_1_read(arm_core_design_block *InstancePtr);
/**
* Write to start_var gateway of arm_core_design_block. Assignments are LSB-justified.
*
* @param	InstancePtr is the start_var instance to operate on.
* @param	Data is value to be written to gateway start_var.
*
* @return	None.
*
* @note    .
*
*/
void arm_core_design_block_start_var_write(arm_core_design_block *InstancePtr, u32 Data);
/**
* Read from start_var gateway of arm_core_design_block. Assignments are LSB-justified.
*
* @param	InstancePtr is the start_var instance to operate on.
*
* @return	u32
*
* @note    .
*
*/
u32 arm_core_design_block_start_var_read(arm_core_design_block *InstancePtr);
/**
* Write to rst_var gateway of arm_core_design_block. Assignments are LSB-justified.
*
* @param	InstancePtr is the rst_var instance to operate on.
* @param	Data is value to be written to gateway rst_var.
*
* @return	None.
*
* @note    .
*
*/
void arm_core_design_block_rst_var_write(arm_core_design_block *InstancePtr, u32 Data);
/**
* Read from rst_var gateway of arm_core_design_block. Assignments are LSB-justified.
*
* @param	InstancePtr is the rst_var instance to operate on.
*
* @return	u32
*
* @note    .
*
*/
u32 arm_core_design_block_rst_var_read(arm_core_design_block *InstancePtr);
/**
* Write to a44_var gateway of arm_core_design_block. Assignments are LSB-justified.
*
* @param	InstancePtr is the a44_var instance to operate on.
* @param	Data is value to be written to gateway a44_var.
*
* @return	None.
*
* @note    .
*
*/
void arm_core_design_block_a44_var_write(arm_core_design_block *InstancePtr, int Data);
/**
* Read from a44_var gateway of arm_core_design_block. Assignments are LSB-justified.
*
* @param	InstancePtr is the a44_var instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int arm_core_design_block_a44_var_read(arm_core_design_block *InstancePtr);
/**
* Write to a43_var gateway of arm_core_design_block. Assignments are LSB-justified.
*
* @param	InstancePtr is the a43_var instance to operate on.
* @param	Data is value to be written to gateway a43_var.
*
* @return	None.
*
* @note    .
*
*/
void arm_core_design_block_a43_var_write(arm_core_design_block *InstancePtr, int Data);
/**
* Read from a43_var gateway of arm_core_design_block. Assignments are LSB-justified.
*
* @param	InstancePtr is the a43_var instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int arm_core_design_block_a43_var_read(arm_core_design_block *InstancePtr);
/**
* Write to a42_var gateway of arm_core_design_block. Assignments are LSB-justified.
*
* @param	InstancePtr is the a42_var instance to operate on.
* @param	Data is value to be written to gateway a42_var.
*
* @return	None.
*
* @note    .
*
*/
void arm_core_design_block_a42_var_write(arm_core_design_block *InstancePtr, int Data);
/**
* Read from a42_var gateway of arm_core_design_block. Assignments are LSB-justified.
*
* @param	InstancePtr is the a42_var instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int arm_core_design_block_a42_var_read(arm_core_design_block *InstancePtr);
/**
* Write to a41_var gateway of arm_core_design_block. Assignments are LSB-justified.
*
* @param	InstancePtr is the a41_var instance to operate on.
* @param	Data is value to be written to gateway a41_var.
*
* @return	None.
*
* @note    .
*
*/
void arm_core_design_block_a41_var_write(arm_core_design_block *InstancePtr, int Data);
/**
* Read from a41_var gateway of arm_core_design_block. Assignments are LSB-justified.
*
* @param	InstancePtr is the a41_var instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int arm_core_design_block_a41_var_read(arm_core_design_block *InstancePtr);
/**
* Write to a34_var gateway of arm_core_design_block. Assignments are LSB-justified.
*
* @param	InstancePtr is the a34_var instance to operate on.
* @param	Data is value to be written to gateway a34_var.
*
* @return	None.
*
* @note    .
*
*/
void arm_core_design_block_a34_var_write(arm_core_design_block *InstancePtr, int Data);
/**
* Read from a34_var gateway of arm_core_design_block. Assignments are LSB-justified.
*
* @param	InstancePtr is the a34_var instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int arm_core_design_block_a34_var_read(arm_core_design_block *InstancePtr);
/**
* Write to a33_var gateway of arm_core_design_block. Assignments are LSB-justified.
*
* @param	InstancePtr is the a33_var instance to operate on.
* @param	Data is value to be written to gateway a33_var.
*
* @return	None.
*
* @note    .
*
*/
void arm_core_design_block_a33_var_write(arm_core_design_block *InstancePtr, int Data);
/**
* Read from a33_var gateway of arm_core_design_block. Assignments are LSB-justified.
*
* @param	InstancePtr is the a33_var instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int arm_core_design_block_a33_var_read(arm_core_design_block *InstancePtr);
/**
* Write to a32_var gateway of arm_core_design_block. Assignments are LSB-justified.
*
* @param	InstancePtr is the a32_var instance to operate on.
* @param	Data is value to be written to gateway a32_var.
*
* @return	None.
*
* @note    .
*
*/
void arm_core_design_block_a32_var_write(arm_core_design_block *InstancePtr, int Data);
/**
* Read from a32_var gateway of arm_core_design_block. Assignments are LSB-justified.
*
* @param	InstancePtr is the a32_var instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int arm_core_design_block_a32_var_read(arm_core_design_block *InstancePtr);
/**
* Write to a31_var gateway of arm_core_design_block. Assignments are LSB-justified.
*
* @param	InstancePtr is the a31_var instance to operate on.
* @param	Data is value to be written to gateway a31_var.
*
* @return	None.
*
* @note    .
*
*/
void arm_core_design_block_a31_var_write(arm_core_design_block *InstancePtr, int Data);
/**
* Read from a31_var gateway of arm_core_design_block. Assignments are LSB-justified.
*
* @param	InstancePtr is the a31_var instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int arm_core_design_block_a31_var_read(arm_core_design_block *InstancePtr);
/**
* Write to a24_var gateway of arm_core_design_block. Assignments are LSB-justified.
*
* @param	InstancePtr is the a24_var instance to operate on.
* @param	Data is value to be written to gateway a24_var.
*
* @return	None.
*
* @note    .
*
*/
void arm_core_design_block_a24_var_write(arm_core_design_block *InstancePtr, int Data);
/**
* Read from a24_var gateway of arm_core_design_block. Assignments are LSB-justified.
*
* @param	InstancePtr is the a24_var instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int arm_core_design_block_a24_var_read(arm_core_design_block *InstancePtr);
/**
* Write to a23_var gateway of arm_core_design_block. Assignments are LSB-justified.
*
* @param	InstancePtr is the a23_var instance to operate on.
* @param	Data is value to be written to gateway a23_var.
*
* @return	None.
*
* @note    .
*
*/
void arm_core_design_block_a23_var_write(arm_core_design_block *InstancePtr, int Data);
/**
* Read from a23_var gateway of arm_core_design_block. Assignments are LSB-justified.
*
* @param	InstancePtr is the a23_var instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int arm_core_design_block_a23_var_read(arm_core_design_block *InstancePtr);
/**
* Write to a22_var gateway of arm_core_design_block. Assignments are LSB-justified.
*
* @param	InstancePtr is the a22_var instance to operate on.
* @param	Data is value to be written to gateway a22_var.
*
* @return	None.
*
* @note    .
*
*/
void arm_core_design_block_a22_var_write(arm_core_design_block *InstancePtr, int Data);
/**
* Read from a22_var gateway of arm_core_design_block. Assignments are LSB-justified.
*
* @param	InstancePtr is the a22_var instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int arm_core_design_block_a22_var_read(arm_core_design_block *InstancePtr);
/**
* Write to a21_var gateway of arm_core_design_block. Assignments are LSB-justified.
*
* @param	InstancePtr is the a21_var instance to operate on.
* @param	Data is value to be written to gateway a21_var.
*
* @return	None.
*
* @note    .
*
*/
void arm_core_design_block_a21_var_write(arm_core_design_block *InstancePtr, int Data);
/**
* Read from a21_var gateway of arm_core_design_block. Assignments are LSB-justified.
*
* @param	InstancePtr is the a21_var instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int arm_core_design_block_a21_var_read(arm_core_design_block *InstancePtr);
/**
* Write to a14_var gateway of arm_core_design_block. Assignments are LSB-justified.
*
* @param	InstancePtr is the a14_var instance to operate on.
* @param	Data is value to be written to gateway a14_var.
*
* @return	None.
*
* @note    .
*
*/
void arm_core_design_block_a14_var_write(arm_core_design_block *InstancePtr, int Data);
/**
* Read from a14_var gateway of arm_core_design_block. Assignments are LSB-justified.
*
* @param	InstancePtr is the a14_var instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int arm_core_design_block_a14_var_read(arm_core_design_block *InstancePtr);
/**
* Write to a13_var gateway of arm_core_design_block. Assignments are LSB-justified.
*
* @param	InstancePtr is the a13_var instance to operate on.
* @param	Data is value to be written to gateway a13_var.
*
* @return	None.
*
* @note    .
*
*/
void arm_core_design_block_a13_var_write(arm_core_design_block *InstancePtr, int Data);
/**
* Read from a13_var gateway of arm_core_design_block. Assignments are LSB-justified.
*
* @param	InstancePtr is the a13_var instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int arm_core_design_block_a13_var_read(arm_core_design_block *InstancePtr);
/**
* Write to a12_var gateway of arm_core_design_block. Assignments are LSB-justified.
*
* @param	InstancePtr is the a12_var instance to operate on.
* @param	Data is value to be written to gateway a12_var.
*
* @return	None.
*
* @note    .
*
*/
void arm_core_design_block_a12_var_write(arm_core_design_block *InstancePtr, int Data);
/**
* Read from a12_var gateway of arm_core_design_block. Assignments are LSB-justified.
*
* @param	InstancePtr is the a12_var instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int arm_core_design_block_a12_var_read(arm_core_design_block *InstancePtr);
/**
* Write to a11_var gateway of arm_core_design_block. Assignments are LSB-justified.
*
* @param	InstancePtr is the a11_var instance to operate on.
* @param	Data is value to be written to gateway a11_var.
*
* @return	None.
*
* @note    .
*
*/
void arm_core_design_block_a11_var_write(arm_core_design_block *InstancePtr, int Data);
/**
* Read from a11_var gateway of arm_core_design_block. Assignments are LSB-justified.
*
* @param	InstancePtr is the a11_var instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int arm_core_design_block_a11_var_read(arm_core_design_block *InstancePtr);
/**
* Read from qout_11 gateway of arm_core_design_block. Assignments are LSB-justified.
*
* @param	InstancePtr is the qout_11 instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int arm_core_design_block_qout_11_read(arm_core_design_block *InstancePtr);
/**
* Read from qout_12 gateway of arm_core_design_block. Assignments are LSB-justified.
*
* @param	InstancePtr is the qout_12 instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int arm_core_design_block_qout_12_read(arm_core_design_block *InstancePtr);
/**
* Read from qout_13 gateway of arm_core_design_block. Assignments are LSB-justified.
*
* @param	InstancePtr is the qout_13 instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int arm_core_design_block_qout_13_read(arm_core_design_block *InstancePtr);
/**
* Read from qout_14 gateway of arm_core_design_block. Assignments are LSB-justified.
*
* @param	InstancePtr is the qout_14 instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int arm_core_design_block_qout_14_read(arm_core_design_block *InstancePtr);
/**
* Read from qout_21 gateway of arm_core_design_block. Assignments are LSB-justified.
*
* @param	InstancePtr is the qout_21 instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int arm_core_design_block_qout_21_read(arm_core_design_block *InstancePtr);
/**
* Read from qout_22 gateway of arm_core_design_block. Assignments are LSB-justified.
*
* @param	InstancePtr is the qout_22 instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int arm_core_design_block_qout_22_read(arm_core_design_block *InstancePtr);
/**
* Read from qout_23 gateway of arm_core_design_block. Assignments are LSB-justified.
*
* @param	InstancePtr is the qout_23 instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int arm_core_design_block_qout_23_read(arm_core_design_block *InstancePtr);
/**
* Read from qout_24 gateway of arm_core_design_block. Assignments are LSB-justified.
*
* @param	InstancePtr is the qout_24 instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int arm_core_design_block_qout_24_read(arm_core_design_block *InstancePtr);
/**
* Read from qout_31 gateway of arm_core_design_block. Assignments are LSB-justified.
*
* @param	InstancePtr is the qout_31 instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int arm_core_design_block_qout_31_read(arm_core_design_block *InstancePtr);
/**
* Read from qout_32 gateway of arm_core_design_block. Assignments are LSB-justified.
*
* @param	InstancePtr is the qout_32 instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int arm_core_design_block_qout_32_read(arm_core_design_block *InstancePtr);
/**
* Read from qout_33 gateway of arm_core_design_block. Assignments are LSB-justified.
*
* @param	InstancePtr is the qout_33 instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int arm_core_design_block_qout_33_read(arm_core_design_block *InstancePtr);
/**
* Read from qout_34 gateway of arm_core_design_block. Assignments are LSB-justified.
*
* @param	InstancePtr is the qout_34 instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int arm_core_design_block_qout_34_read(arm_core_design_block *InstancePtr);
/**
* Read from qout_41 gateway of arm_core_design_block. Assignments are LSB-justified.
*
* @param	InstancePtr is the qout_41 instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int arm_core_design_block_qout_41_read(arm_core_design_block *InstancePtr);
/**
* Read from qout_42 gateway of arm_core_design_block. Assignments are LSB-justified.
*
* @param	InstancePtr is the qout_42 instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int arm_core_design_block_qout_42_read(arm_core_design_block *InstancePtr);
/**
* Read from qout_43 gateway of arm_core_design_block. Assignments are LSB-justified.
*
* @param	InstancePtr is the qout_43 instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int arm_core_design_block_qout_43_read(arm_core_design_block *InstancePtr);
/**
* Read from qout_44 gateway of arm_core_design_block. Assignments are LSB-justified.
*
* @param	InstancePtr is the qout_44 instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int arm_core_design_block_qout_44_read(arm_core_design_block *InstancePtr);
/**
* Read from rout_11 gateway of arm_core_design_block. Assignments are LSB-justified.
*
* @param	InstancePtr is the rout_11 instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int arm_core_design_block_rout_11_read(arm_core_design_block *InstancePtr);
/**
* Read from rout_21 gateway of arm_core_design_block. Assignments are LSB-justified.
*
* @param	InstancePtr is the rout_21 instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int arm_core_design_block_rout_21_read(arm_core_design_block *InstancePtr);
/**
* Read from rout_22 gateway of arm_core_design_block. Assignments are LSB-justified.
*
* @param	InstancePtr is the rout_22 instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int arm_core_design_block_rout_22_read(arm_core_design_block *InstancePtr);
/**
* Read from rout_31 gateway of arm_core_design_block. Assignments are LSB-justified.
*
* @param	InstancePtr is the rout_31 instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int arm_core_design_block_rout_31_read(arm_core_design_block *InstancePtr);
/**
* Read from rout_32 gateway of arm_core_design_block. Assignments are LSB-justified.
*
* @param	InstancePtr is the rout_32 instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int arm_core_design_block_rout_32_read(arm_core_design_block *InstancePtr);
/**
* Read from rout_33 gateway of arm_core_design_block. Assignments are LSB-justified.
*
* @param	InstancePtr is the rout_33 instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int arm_core_design_block_rout_33_read(arm_core_design_block *InstancePtr);
/**
* Read from rout_41 gateway of arm_core_design_block. Assignments are LSB-justified.
*
* @param	InstancePtr is the rout_41 instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int arm_core_design_block_rout_41_read(arm_core_design_block *InstancePtr);
/**
* Read from rout_42 gateway of arm_core_design_block. Assignments are LSB-justified.
*
* @param	InstancePtr is the rout_42 instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int arm_core_design_block_rout_42_read(arm_core_design_block *InstancePtr);
/**
* Read from rout_43 gateway of arm_core_design_block. Assignments are LSB-justified.
*
* @param	InstancePtr is the rout_43 instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int arm_core_design_block_rout_43_read(arm_core_design_block *InstancePtr);
/**
* Read from rout_44 gateway of arm_core_design_block. Assignments are LSB-justified.
*
* @param	InstancePtr is the rout_44 instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int arm_core_design_block_rout_44_read(arm_core_design_block *InstancePtr);
/**
* Read from qout_2 gateway of arm_core_design_block. Assignments are LSB-justified.
*
* @param	InstancePtr is the qout_2 instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int arm_core_design_block_qout_2_read(arm_core_design_block *InstancePtr);
/**
* Read from qout_3 gateway of arm_core_design_block. Assignments are LSB-justified.
*
* @param	InstancePtr is the qout_3 instance to operate on.
*
* @return	u32
*
* @note    .
*
*/
u32 arm_core_design_block_qout_3_read(arm_core_design_block *InstancePtr);
/**
* Read from qout_1 gateway of arm_core_design_block. Assignments are LSB-justified.
*
* @param	InstancePtr is the qout_1 instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int arm_core_design_block_qout_1_read(arm_core_design_block *InstancePtr);
/**
* Read from qout_4 gateway of arm_core_design_block. Assignments are LSB-justified.
*
* @param	InstancePtr is the qout_4 instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int arm_core_design_block_qout_4_read(arm_core_design_block *InstancePtr);
#ifdef __cplusplus
}
#endif
#endif
