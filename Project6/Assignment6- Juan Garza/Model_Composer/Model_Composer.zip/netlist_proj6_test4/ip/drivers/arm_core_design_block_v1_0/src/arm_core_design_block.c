#include "arm_core_design_block.h"
#ifndef __linux__
int arm_core_design_block_CfgInitialize(arm_core_design_block *InstancePtr, arm_core_design_block_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->arm_core_design_block_BaseAddress = ConfigPtr->arm_core_design_block_BaseAddress;

    InstancePtr->IsReady = 1;
    return XST_SUCCESS;
}
#endif
void arm_core_design_block_b_4_write(arm_core_design_block *InstancePtr, int Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    arm_core_design_block_WriteReg(InstancePtr->arm_core_design_block_BaseAddress, 0, Data);
}
int arm_core_design_block_b_4_read(arm_core_design_block *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = arm_core_design_block_ReadReg(InstancePtr->arm_core_design_block_BaseAddress, 0);
    return Data;
}
void arm_core_design_block_b_3_write(arm_core_design_block *InstancePtr, int Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    arm_core_design_block_WriteReg(InstancePtr->arm_core_design_block_BaseAddress, 4, Data);
}
int arm_core_design_block_b_3_read(arm_core_design_block *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = arm_core_design_block_ReadReg(InstancePtr->arm_core_design_block_BaseAddress, 4);
    return Data;
}
void arm_core_design_block_b_2_write(arm_core_design_block *InstancePtr, int Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    arm_core_design_block_WriteReg(InstancePtr->arm_core_design_block_BaseAddress, 8, Data);
}
int arm_core_design_block_b_2_read(arm_core_design_block *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = arm_core_design_block_ReadReg(InstancePtr->arm_core_design_block_BaseAddress, 8);
    return Data;
}
void arm_core_design_block_b_1_write(arm_core_design_block *InstancePtr, int Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    arm_core_design_block_WriteReg(InstancePtr->arm_core_design_block_BaseAddress, 12, Data);
}
int arm_core_design_block_b_1_read(arm_core_design_block *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = arm_core_design_block_ReadReg(InstancePtr->arm_core_design_block_BaseAddress, 12);
    return Data;
}
void arm_core_design_block_start_var_write(arm_core_design_block *InstancePtr, u32 Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    arm_core_design_block_WriteReg(InstancePtr->arm_core_design_block_BaseAddress, 16, Data);
}
u32 arm_core_design_block_start_var_read(arm_core_design_block *InstancePtr) {

    u32 Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = arm_core_design_block_ReadReg(InstancePtr->arm_core_design_block_BaseAddress, 16);
    return Data;
}
void arm_core_design_block_rst_var_write(arm_core_design_block *InstancePtr, u32 Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    arm_core_design_block_WriteReg(InstancePtr->arm_core_design_block_BaseAddress, 20, Data);
}
u32 arm_core_design_block_rst_var_read(arm_core_design_block *InstancePtr) {

    u32 Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = arm_core_design_block_ReadReg(InstancePtr->arm_core_design_block_BaseAddress, 20);
    return Data;
}
void arm_core_design_block_a44_var_write(arm_core_design_block *InstancePtr, int Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    arm_core_design_block_WriteReg(InstancePtr->arm_core_design_block_BaseAddress, 24, Data);
}
int arm_core_design_block_a44_var_read(arm_core_design_block *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = arm_core_design_block_ReadReg(InstancePtr->arm_core_design_block_BaseAddress, 24);
    return Data;
}
void arm_core_design_block_a43_var_write(arm_core_design_block *InstancePtr, int Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    arm_core_design_block_WriteReg(InstancePtr->arm_core_design_block_BaseAddress, 28, Data);
}
int arm_core_design_block_a43_var_read(arm_core_design_block *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = arm_core_design_block_ReadReg(InstancePtr->arm_core_design_block_BaseAddress, 28);
    return Data;
}
void arm_core_design_block_a42_var_write(arm_core_design_block *InstancePtr, int Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    arm_core_design_block_WriteReg(InstancePtr->arm_core_design_block_BaseAddress, 32, Data);
}
int arm_core_design_block_a42_var_read(arm_core_design_block *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = arm_core_design_block_ReadReg(InstancePtr->arm_core_design_block_BaseAddress, 32);
    return Data;
}
void arm_core_design_block_a41_var_write(arm_core_design_block *InstancePtr, int Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    arm_core_design_block_WriteReg(InstancePtr->arm_core_design_block_BaseAddress, 36, Data);
}
int arm_core_design_block_a41_var_read(arm_core_design_block *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = arm_core_design_block_ReadReg(InstancePtr->arm_core_design_block_BaseAddress, 36);
    return Data;
}
void arm_core_design_block_a34_var_write(arm_core_design_block *InstancePtr, int Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    arm_core_design_block_WriteReg(InstancePtr->arm_core_design_block_BaseAddress, 40, Data);
}
int arm_core_design_block_a34_var_read(arm_core_design_block *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = arm_core_design_block_ReadReg(InstancePtr->arm_core_design_block_BaseAddress, 40);
    return Data;
}
void arm_core_design_block_a33_var_write(arm_core_design_block *InstancePtr, int Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    arm_core_design_block_WriteReg(InstancePtr->arm_core_design_block_BaseAddress, 44, Data);
}
int arm_core_design_block_a33_var_read(arm_core_design_block *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = arm_core_design_block_ReadReg(InstancePtr->arm_core_design_block_BaseAddress, 44);
    return Data;
}
void arm_core_design_block_a32_var_write(arm_core_design_block *InstancePtr, int Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    arm_core_design_block_WriteReg(InstancePtr->arm_core_design_block_BaseAddress, 48, Data);
}
int arm_core_design_block_a32_var_read(arm_core_design_block *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = arm_core_design_block_ReadReg(InstancePtr->arm_core_design_block_BaseAddress, 48);
    return Data;
}
void arm_core_design_block_a31_var_write(arm_core_design_block *InstancePtr, int Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    arm_core_design_block_WriteReg(InstancePtr->arm_core_design_block_BaseAddress, 52, Data);
}
int arm_core_design_block_a31_var_read(arm_core_design_block *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = arm_core_design_block_ReadReg(InstancePtr->arm_core_design_block_BaseAddress, 52);
    return Data;
}
void arm_core_design_block_a24_var_write(arm_core_design_block *InstancePtr, int Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    arm_core_design_block_WriteReg(InstancePtr->arm_core_design_block_BaseAddress, 56, Data);
}
int arm_core_design_block_a24_var_read(arm_core_design_block *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = arm_core_design_block_ReadReg(InstancePtr->arm_core_design_block_BaseAddress, 56);
    return Data;
}
void arm_core_design_block_a23_var_write(arm_core_design_block *InstancePtr, int Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    arm_core_design_block_WriteReg(InstancePtr->arm_core_design_block_BaseAddress, 60, Data);
}
int arm_core_design_block_a23_var_read(arm_core_design_block *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = arm_core_design_block_ReadReg(InstancePtr->arm_core_design_block_BaseAddress, 60);
    return Data;
}
void arm_core_design_block_a22_var_write(arm_core_design_block *InstancePtr, int Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    arm_core_design_block_WriteReg(InstancePtr->arm_core_design_block_BaseAddress, 64, Data);
}
int arm_core_design_block_a22_var_read(arm_core_design_block *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = arm_core_design_block_ReadReg(InstancePtr->arm_core_design_block_BaseAddress, 64);
    return Data;
}
void arm_core_design_block_a21_var_write(arm_core_design_block *InstancePtr, int Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    arm_core_design_block_WriteReg(InstancePtr->arm_core_design_block_BaseAddress, 68, Data);
}
int arm_core_design_block_a21_var_read(arm_core_design_block *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = arm_core_design_block_ReadReg(InstancePtr->arm_core_design_block_BaseAddress, 68);
    return Data;
}
void arm_core_design_block_a14_var_write(arm_core_design_block *InstancePtr, int Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    arm_core_design_block_WriteReg(InstancePtr->arm_core_design_block_BaseAddress, 72, Data);
}
int arm_core_design_block_a14_var_read(arm_core_design_block *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = arm_core_design_block_ReadReg(InstancePtr->arm_core_design_block_BaseAddress, 72);
    return Data;
}
void arm_core_design_block_a13_var_write(arm_core_design_block *InstancePtr, int Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    arm_core_design_block_WriteReg(InstancePtr->arm_core_design_block_BaseAddress, 76, Data);
}
int arm_core_design_block_a13_var_read(arm_core_design_block *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = arm_core_design_block_ReadReg(InstancePtr->arm_core_design_block_BaseAddress, 76);
    return Data;
}
void arm_core_design_block_a12_var_write(arm_core_design_block *InstancePtr, int Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    arm_core_design_block_WriteReg(InstancePtr->arm_core_design_block_BaseAddress, 80, Data);
}
int arm_core_design_block_a12_var_read(arm_core_design_block *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = arm_core_design_block_ReadReg(InstancePtr->arm_core_design_block_BaseAddress, 80);
    return Data;
}
void arm_core_design_block_a11_var_write(arm_core_design_block *InstancePtr, int Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    arm_core_design_block_WriteReg(InstancePtr->arm_core_design_block_BaseAddress, 84, Data);
}
int arm_core_design_block_a11_var_read(arm_core_design_block *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = arm_core_design_block_ReadReg(InstancePtr->arm_core_design_block_BaseAddress, 84);
    return Data;
}
int arm_core_design_block_qout_11_read(arm_core_design_block *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = arm_core_design_block_ReadReg(InstancePtr->arm_core_design_block_BaseAddress, 88);
    return Data;
}
int arm_core_design_block_qout_12_read(arm_core_design_block *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = arm_core_design_block_ReadReg(InstancePtr->arm_core_design_block_BaseAddress, 92);
    return Data;
}
int arm_core_design_block_qout_13_read(arm_core_design_block *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = arm_core_design_block_ReadReg(InstancePtr->arm_core_design_block_BaseAddress, 96);
    return Data;
}
int arm_core_design_block_qout_14_read(arm_core_design_block *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = arm_core_design_block_ReadReg(InstancePtr->arm_core_design_block_BaseAddress, 100);
    return Data;
}
int arm_core_design_block_qout_21_read(arm_core_design_block *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = arm_core_design_block_ReadReg(InstancePtr->arm_core_design_block_BaseAddress, 104);
    return Data;
}
int arm_core_design_block_qout_22_read(arm_core_design_block *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = arm_core_design_block_ReadReg(InstancePtr->arm_core_design_block_BaseAddress, 108);
    return Data;
}
int arm_core_design_block_qout_23_read(arm_core_design_block *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = arm_core_design_block_ReadReg(InstancePtr->arm_core_design_block_BaseAddress, 112);
    return Data;
}
int arm_core_design_block_qout_24_read(arm_core_design_block *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = arm_core_design_block_ReadReg(InstancePtr->arm_core_design_block_BaseAddress, 116);
    return Data;
}
int arm_core_design_block_qout_31_read(arm_core_design_block *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = arm_core_design_block_ReadReg(InstancePtr->arm_core_design_block_BaseAddress, 120);
    return Data;
}
int arm_core_design_block_qout_32_read(arm_core_design_block *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = arm_core_design_block_ReadReg(InstancePtr->arm_core_design_block_BaseAddress, 124);
    return Data;
}
int arm_core_design_block_qout_33_read(arm_core_design_block *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = arm_core_design_block_ReadReg(InstancePtr->arm_core_design_block_BaseAddress, 128);
    return Data;
}
int arm_core_design_block_qout_34_read(arm_core_design_block *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = arm_core_design_block_ReadReg(InstancePtr->arm_core_design_block_BaseAddress, 132);
    return Data;
}
int arm_core_design_block_qout_41_read(arm_core_design_block *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = arm_core_design_block_ReadReg(InstancePtr->arm_core_design_block_BaseAddress, 136);
    return Data;
}
int arm_core_design_block_qout_42_read(arm_core_design_block *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = arm_core_design_block_ReadReg(InstancePtr->arm_core_design_block_BaseAddress, 140);
    return Data;
}
int arm_core_design_block_qout_43_read(arm_core_design_block *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = arm_core_design_block_ReadReg(InstancePtr->arm_core_design_block_BaseAddress, 144);
    return Data;
}
int arm_core_design_block_qout_44_read(arm_core_design_block *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = arm_core_design_block_ReadReg(InstancePtr->arm_core_design_block_BaseAddress, 148);
    return Data;
}
int arm_core_design_block_rout_11_read(arm_core_design_block *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = arm_core_design_block_ReadReg(InstancePtr->arm_core_design_block_BaseAddress, 152);
    return Data;
}
int arm_core_design_block_rout_21_read(arm_core_design_block *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = arm_core_design_block_ReadReg(InstancePtr->arm_core_design_block_BaseAddress, 156);
    return Data;
}
int arm_core_design_block_rout_22_read(arm_core_design_block *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = arm_core_design_block_ReadReg(InstancePtr->arm_core_design_block_BaseAddress, 160);
    return Data;
}
int arm_core_design_block_rout_31_read(arm_core_design_block *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = arm_core_design_block_ReadReg(InstancePtr->arm_core_design_block_BaseAddress, 164);
    return Data;
}
int arm_core_design_block_rout_32_read(arm_core_design_block *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = arm_core_design_block_ReadReg(InstancePtr->arm_core_design_block_BaseAddress, 168);
    return Data;
}
int arm_core_design_block_rout_33_read(arm_core_design_block *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = arm_core_design_block_ReadReg(InstancePtr->arm_core_design_block_BaseAddress, 172);
    return Data;
}
int arm_core_design_block_rout_41_read(arm_core_design_block *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = arm_core_design_block_ReadReg(InstancePtr->arm_core_design_block_BaseAddress, 176);
    return Data;
}
int arm_core_design_block_rout_42_read(arm_core_design_block *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = arm_core_design_block_ReadReg(InstancePtr->arm_core_design_block_BaseAddress, 180);
    return Data;
}
int arm_core_design_block_rout_43_read(arm_core_design_block *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = arm_core_design_block_ReadReg(InstancePtr->arm_core_design_block_BaseAddress, 184);
    return Data;
}
int arm_core_design_block_rout_44_read(arm_core_design_block *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = arm_core_design_block_ReadReg(InstancePtr->arm_core_design_block_BaseAddress, 188);
    return Data;
}
int arm_core_design_block_qout_2_read(arm_core_design_block *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = arm_core_design_block_ReadReg(InstancePtr->arm_core_design_block_BaseAddress, 192);
    return Data;
}
u32 arm_core_design_block_qout_3_read(arm_core_design_block *InstancePtr) {

    u32 Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = arm_core_design_block_ReadReg(InstancePtr->arm_core_design_block_BaseAddress, 196);
    return Data;
}
int arm_core_design_block_qout_1_read(arm_core_design_block *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = arm_core_design_block_ReadReg(InstancePtr->arm_core_design_block_BaseAddress, 200);
    return Data;
}
int arm_core_design_block_qout_4_read(arm_core_design_block *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = arm_core_design_block_ReadReg(InstancePtr->arm_core_design_block_BaseAddress, 204);
    return Data;
}
