/**
*
* @file arm_core_design_block_hw.h
*
* This header file contains identifiers and driver functions (or
* macros) that can be used to access the device.  The user should refer to the
* hardware device specification for more details of the device operation.
*/ 
#define ARM_CORE_DESIGN_BLOCK_B_4 0x0/**< b_4 */
#define ARM_CORE_DESIGN_BLOCK_B_3 0x4/**< b_3 */
#define ARM_CORE_DESIGN_BLOCK_B_2 0x8/**< b_2 */
#define ARM_CORE_DESIGN_BLOCK_B_1 0xc/**< b_1 */
#define ARM_CORE_DESIGN_BLOCK_START_VAR 0x10/**< start_var */
#define ARM_CORE_DESIGN_BLOCK_RST_VAR 0x14/**< rst_var */
#define ARM_CORE_DESIGN_BLOCK_A44_VAR 0x18/**< a44_var */
#define ARM_CORE_DESIGN_BLOCK_A43_VAR 0x1c/**< a43_var */
#define ARM_CORE_DESIGN_BLOCK_A42_VAR 0x20/**< a42_var */
#define ARM_CORE_DESIGN_BLOCK_A41_VAR 0x24/**< a41_var */
#define ARM_CORE_DESIGN_BLOCK_A34_VAR 0x28/**< a34_var */
#define ARM_CORE_DESIGN_BLOCK_A33_VAR 0x2c/**< a33_var */
#define ARM_CORE_DESIGN_BLOCK_A32_VAR 0x30/**< a32_var */
#define ARM_CORE_DESIGN_BLOCK_A31_VAR 0x34/**< a31_var */
#define ARM_CORE_DESIGN_BLOCK_A24_VAR 0x38/**< a24_var */
#define ARM_CORE_DESIGN_BLOCK_A23_VAR 0x3c/**< a23_var */
#define ARM_CORE_DESIGN_BLOCK_A22_VAR 0x40/**< a22_var */
#define ARM_CORE_DESIGN_BLOCK_A21_VAR 0x44/**< a21_var */
#define ARM_CORE_DESIGN_BLOCK_A14_VAR 0x48/**< a14_var */
#define ARM_CORE_DESIGN_BLOCK_A13_VAR 0x4c/**< a13_var */
#define ARM_CORE_DESIGN_BLOCK_A12_VAR 0x50/**< a12_var */
#define ARM_CORE_DESIGN_BLOCK_A11_VAR 0x54/**< a11_var */
#define ARM_CORE_DESIGN_BLOCK_QOUT_11 0x58/**< qout_11 */
#define ARM_CORE_DESIGN_BLOCK_QOUT_12 0x5c/**< qout_12 */
#define ARM_CORE_DESIGN_BLOCK_QOUT_13 0x60/**< qout_13 */
#define ARM_CORE_DESIGN_BLOCK_QOUT_14 0x64/**< qout_14 */
#define ARM_CORE_DESIGN_BLOCK_QOUT_21 0x68/**< qout_21 */
#define ARM_CORE_DESIGN_BLOCK_QOUT_22 0x6c/**< qout_22 */
#define ARM_CORE_DESIGN_BLOCK_QOUT_23 0x70/**< qout_23 */
#define ARM_CORE_DESIGN_BLOCK_QOUT_24 0x74/**< qout_24 */
#define ARM_CORE_DESIGN_BLOCK_QOUT_31 0x78/**< qout_31 */
#define ARM_CORE_DESIGN_BLOCK_QOUT_32 0x7c/**< qout_32 */
#define ARM_CORE_DESIGN_BLOCK_QOUT_33 0x80/**< qout_33 */
#define ARM_CORE_DESIGN_BLOCK_QOUT_34 0x84/**< qout_34 */
#define ARM_CORE_DESIGN_BLOCK_QOUT_41 0x88/**< qout_41 */
#define ARM_CORE_DESIGN_BLOCK_QOUT_42 0x8c/**< qout_42 */
#define ARM_CORE_DESIGN_BLOCK_QOUT_43 0x90/**< qout_43 */
#define ARM_CORE_DESIGN_BLOCK_QOUT_44 0x94/**< qout_44 */
#define ARM_CORE_DESIGN_BLOCK_ROUT_11 0x98/**< rout_11 */
#define ARM_CORE_DESIGN_BLOCK_ROUT_21 0x9c/**< rout_21 */
#define ARM_CORE_DESIGN_BLOCK_ROUT_22 0xa0/**< rout_22 */
#define ARM_CORE_DESIGN_BLOCK_ROUT_31 0xa4/**< rout_31 */
#define ARM_CORE_DESIGN_BLOCK_ROUT_32 0xa8/**< rout_32 */
#define ARM_CORE_DESIGN_BLOCK_ROUT_33 0xac/**< rout_33 */
#define ARM_CORE_DESIGN_BLOCK_ROUT_41 0xb0/**< rout_41 */
#define ARM_CORE_DESIGN_BLOCK_ROUT_42 0xb4/**< rout_42 */
#define ARM_CORE_DESIGN_BLOCK_ROUT_43 0xb8/**< rout_43 */
#define ARM_CORE_DESIGN_BLOCK_ROUT_44 0xbc/**< rout_44 */
#define ARM_CORE_DESIGN_BLOCK_QOUT_2 0xc0/**< qout_2 */
#define ARM_CORE_DESIGN_BLOCK_QOUT_3 0xc4/**< qout_3 */
#define ARM_CORE_DESIGN_BLOCK_QOUT_1 0xc8/**< qout_1 */
#define ARM_CORE_DESIGN_BLOCK_QOUT_4 0xcc/**< qout_4 */
