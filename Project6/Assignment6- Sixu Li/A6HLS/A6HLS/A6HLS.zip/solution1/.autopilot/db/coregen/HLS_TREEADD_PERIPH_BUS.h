// 0x00 : Control signals
//        bit 0  - ap_start (Read/Write/COH)
//        bit 1  - ap_done (Read/COR)
//        bit 2  - ap_idle (Read)
//        bit 3  - ap_ready (Read/COR)
//        bit 7  - auto_restart (Read/Write)
//        bit 9  - interrupt (Read)
//        others - reserved
// 0x04 : Global Interrupt Enable Register
//        bit 0  - Global Interrupt Enable (Read/Write)
//        others - reserved
// 0x08 : IP Interrupt Enable Register (Read/Write)
//        bit 0 - enable ap_done interrupt (Read/Write)
//        bit 1 - enable ap_ready interrupt (Read/Write)
//        others - reserved
// 0x0c : IP Interrupt Status Register (Read/COR)
//        bit 0 - ap_done (Read/COR)
//        bit 1 - ap_ready (Read/COR)
//        others - reserved
// 0x10 : Data signal of a11
//        bit 23~0 - a11[23:0] (Read/Write)
//        others   - reserved
// 0x14 : reserved
// 0x18 : Data signal of a12
//        bit 23~0 - a12[23:0] (Read/Write)
//        others   - reserved
// 0x1c : reserved
// 0x20 : Data signal of a13
//        bit 23~0 - a13[23:0] (Read/Write)
//        others   - reserved
// 0x24 : reserved
// 0x28 : Data signal of a14
//        bit 23~0 - a14[23:0] (Read/Write)
//        others   - reserved
// 0x2c : reserved
// 0x30 : Data signal of a21
//        bit 23~0 - a21[23:0] (Read/Write)
//        others   - reserved
// 0x34 : reserved
// 0x38 : Data signal of a22
//        bit 23~0 - a22[23:0] (Read/Write)
//        others   - reserved
// 0x3c : reserved
// 0x40 : Data signal of a23
//        bit 23~0 - a23[23:0] (Read/Write)
//        others   - reserved
// 0x44 : reserved
// 0x48 : Data signal of a24
//        bit 23~0 - a24[23:0] (Read/Write)
//        others   - reserved
// 0x4c : reserved
// 0x50 : Data signal of a31
//        bit 23~0 - a31[23:0] (Read/Write)
//        others   - reserved
// 0x54 : reserved
// 0x58 : Data signal of a32
//        bit 23~0 - a32[23:0] (Read/Write)
//        others   - reserved
// 0x5c : reserved
// 0x60 : Data signal of a33
//        bit 23~0 - a33[23:0] (Read/Write)
//        others   - reserved
// 0x64 : reserved
// 0x68 : Data signal of a34
//        bit 23~0 - a34[23:0] (Read/Write)
//        others   - reserved
// 0x6c : reserved
// 0x70 : Data signal of a41
//        bit 23~0 - a41[23:0] (Read/Write)
//        others   - reserved
// 0x74 : reserved
// 0x78 : Data signal of a42
//        bit 23~0 - a42[23:0] (Read/Write)
//        others   - reserved
// 0x7c : reserved
// 0x80 : Data signal of a43
//        bit 23~0 - a43[23:0] (Read/Write)
//        others   - reserved
// 0x84 : reserved
// 0x88 : Data signal of a44
//        bit 23~0 - a44[23:0] (Read/Write)
//        others   - reserved
// 0x8c : reserved
// 0x90 : Data signal of b1
//        bit 23~0 - b1[23:0] (Read/Write)
//        others   - reserved
// 0x94 : reserved
// 0x98 : Data signal of b2
//        bit 23~0 - b2[23:0] (Read/Write)
//        others   - reserved
// 0x9c : reserved
// 0xa0 : Data signal of b3
//        bit 23~0 - b3[23:0] (Read/Write)
//        others   - reserved
// 0xa4 : reserved
// 0xa8 : Data signal of b4
//        bit 23~0 - b4[23:0] (Read/Write)
//        others   - reserved
// 0xac : reserved
// 0xb0 : Data signal of x1
//        bit 23~0 - x1[23:0] (Read)
//        others   - reserved
// 0xb4 : Control signal of x1
//        bit 0  - x1_ap_vld (Read/COR)
//        others - reserved
// 0xc0 : Data signal of x2
//        bit 23~0 - x2[23:0] (Read)
//        others   - reserved
// 0xc4 : Control signal of x2
//        bit 0  - x2_ap_vld (Read/COR)
//        others - reserved
// 0xd0 : Data signal of x3
//        bit 23~0 - x3[23:0] (Read)
//        others   - reserved
// 0xd4 : Control signal of x3
//        bit 0  - x3_ap_vld (Read/COR)
//        others - reserved
// 0xe0 : Data signal of x4
//        bit 23~0 - x4[23:0] (Read)
//        others   - reserved
// 0xe4 : Control signal of x4
//        bit 0  - x4_ap_vld (Read/COR)
//        others - reserved
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define HLS_TREEADD_PERIPH_BUS_ADDR_AP_CTRL  0x00
#define HLS_TREEADD_PERIPH_BUS_ADDR_GIE      0x04
#define HLS_TREEADD_PERIPH_BUS_ADDR_IER      0x08
#define HLS_TREEADD_PERIPH_BUS_ADDR_ISR      0x0c
#define HLS_TREEADD_PERIPH_BUS_ADDR_A11_DATA 0x10
#define HLS_TREEADD_PERIPH_BUS_BITS_A11_DATA 24
#define HLS_TREEADD_PERIPH_BUS_ADDR_A12_DATA 0x18
#define HLS_TREEADD_PERIPH_BUS_BITS_A12_DATA 24
#define HLS_TREEADD_PERIPH_BUS_ADDR_A13_DATA 0x20
#define HLS_TREEADD_PERIPH_BUS_BITS_A13_DATA 24
#define HLS_TREEADD_PERIPH_BUS_ADDR_A14_DATA 0x28
#define HLS_TREEADD_PERIPH_BUS_BITS_A14_DATA 24
#define HLS_TREEADD_PERIPH_BUS_ADDR_A21_DATA 0x30
#define HLS_TREEADD_PERIPH_BUS_BITS_A21_DATA 24
#define HLS_TREEADD_PERIPH_BUS_ADDR_A22_DATA 0x38
#define HLS_TREEADD_PERIPH_BUS_BITS_A22_DATA 24
#define HLS_TREEADD_PERIPH_BUS_ADDR_A23_DATA 0x40
#define HLS_TREEADD_PERIPH_BUS_BITS_A23_DATA 24
#define HLS_TREEADD_PERIPH_BUS_ADDR_A24_DATA 0x48
#define HLS_TREEADD_PERIPH_BUS_BITS_A24_DATA 24
#define HLS_TREEADD_PERIPH_BUS_ADDR_A31_DATA 0x50
#define HLS_TREEADD_PERIPH_BUS_BITS_A31_DATA 24
#define HLS_TREEADD_PERIPH_BUS_ADDR_A32_DATA 0x58
#define HLS_TREEADD_PERIPH_BUS_BITS_A32_DATA 24
#define HLS_TREEADD_PERIPH_BUS_ADDR_A33_DATA 0x60
#define HLS_TREEADD_PERIPH_BUS_BITS_A33_DATA 24
#define HLS_TREEADD_PERIPH_BUS_ADDR_A34_DATA 0x68
#define HLS_TREEADD_PERIPH_BUS_BITS_A34_DATA 24
#define HLS_TREEADD_PERIPH_BUS_ADDR_A41_DATA 0x70
#define HLS_TREEADD_PERIPH_BUS_BITS_A41_DATA 24
#define HLS_TREEADD_PERIPH_BUS_ADDR_A42_DATA 0x78
#define HLS_TREEADD_PERIPH_BUS_BITS_A42_DATA 24
#define HLS_TREEADD_PERIPH_BUS_ADDR_A43_DATA 0x80
#define HLS_TREEADD_PERIPH_BUS_BITS_A43_DATA 24
#define HLS_TREEADD_PERIPH_BUS_ADDR_A44_DATA 0x88
#define HLS_TREEADD_PERIPH_BUS_BITS_A44_DATA 24
#define HLS_TREEADD_PERIPH_BUS_ADDR_B1_DATA  0x90
#define HLS_TREEADD_PERIPH_BUS_BITS_B1_DATA  24
#define HLS_TREEADD_PERIPH_BUS_ADDR_B2_DATA  0x98
#define HLS_TREEADD_PERIPH_BUS_BITS_B2_DATA  24
#define HLS_TREEADD_PERIPH_BUS_ADDR_B3_DATA  0xa0
#define HLS_TREEADD_PERIPH_BUS_BITS_B3_DATA  24
#define HLS_TREEADD_PERIPH_BUS_ADDR_B4_DATA  0xa8
#define HLS_TREEADD_PERIPH_BUS_BITS_B4_DATA  24
#define HLS_TREEADD_PERIPH_BUS_ADDR_X1_DATA  0xb0
#define HLS_TREEADD_PERIPH_BUS_BITS_X1_DATA  24
#define HLS_TREEADD_PERIPH_BUS_ADDR_X1_CTRL  0xb4
#define HLS_TREEADD_PERIPH_BUS_ADDR_X2_DATA  0xc0
#define HLS_TREEADD_PERIPH_BUS_BITS_X2_DATA  24
#define HLS_TREEADD_PERIPH_BUS_ADDR_X2_CTRL  0xc4
#define HLS_TREEADD_PERIPH_BUS_ADDR_X3_DATA  0xd0
#define HLS_TREEADD_PERIPH_BUS_BITS_X3_DATA  24
#define HLS_TREEADD_PERIPH_BUS_ADDR_X3_CTRL  0xd4
#define HLS_TREEADD_PERIPH_BUS_ADDR_X4_DATA  0xe0
#define HLS_TREEADD_PERIPH_BUS_BITS_X4_DATA  24
#define HLS_TREEADD_PERIPH_BUS_ADDR_X4_CTRL  0xe4
