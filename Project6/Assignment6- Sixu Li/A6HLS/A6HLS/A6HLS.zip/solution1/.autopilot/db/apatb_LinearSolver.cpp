#include <systemc>
#include <iostream>
#include <cstdlib>
#include <cstddef>
#include <stdint.h>
#include "SysCFileHandler.h"
#include "ap_int.h"
#include "ap_fixed.h"
#include <complex>
#include <stdbool.h>
#include "autopilot_cbe.h"
#include "hls_stream.h"
#include "hls_half.h"
#include "hls_signal_handler.h"

using namespace std;
using namespace sc_core;
using namespace sc_dt;

// wrapc file define:
#define AUTOTB_TVIN_a11 "../tv/cdatafile/c.LinearSolver.autotvin_a11.dat"
#define AUTOTB_TVOUT_a11 "../tv/cdatafile/c.LinearSolver.autotvout_a11.dat"
#define AUTOTB_TVIN_a12 "../tv/cdatafile/c.LinearSolver.autotvin_a12.dat"
#define AUTOTB_TVOUT_a12 "../tv/cdatafile/c.LinearSolver.autotvout_a12.dat"
#define AUTOTB_TVIN_a13 "../tv/cdatafile/c.LinearSolver.autotvin_a13.dat"
#define AUTOTB_TVOUT_a13 "../tv/cdatafile/c.LinearSolver.autotvout_a13.dat"
#define AUTOTB_TVIN_a14 "../tv/cdatafile/c.LinearSolver.autotvin_a14.dat"
#define AUTOTB_TVOUT_a14 "../tv/cdatafile/c.LinearSolver.autotvout_a14.dat"
#define AUTOTB_TVIN_a21 "../tv/cdatafile/c.LinearSolver.autotvin_a21.dat"
#define AUTOTB_TVOUT_a21 "../tv/cdatafile/c.LinearSolver.autotvout_a21.dat"
#define AUTOTB_TVIN_a22 "../tv/cdatafile/c.LinearSolver.autotvin_a22.dat"
#define AUTOTB_TVOUT_a22 "../tv/cdatafile/c.LinearSolver.autotvout_a22.dat"
#define AUTOTB_TVIN_a23 "../tv/cdatafile/c.LinearSolver.autotvin_a23.dat"
#define AUTOTB_TVOUT_a23 "../tv/cdatafile/c.LinearSolver.autotvout_a23.dat"
#define AUTOTB_TVIN_a24 "../tv/cdatafile/c.LinearSolver.autotvin_a24.dat"
#define AUTOTB_TVOUT_a24 "../tv/cdatafile/c.LinearSolver.autotvout_a24.dat"
#define AUTOTB_TVIN_a31 "../tv/cdatafile/c.LinearSolver.autotvin_a31.dat"
#define AUTOTB_TVOUT_a31 "../tv/cdatafile/c.LinearSolver.autotvout_a31.dat"
#define AUTOTB_TVIN_a32 "../tv/cdatafile/c.LinearSolver.autotvin_a32.dat"
#define AUTOTB_TVOUT_a32 "../tv/cdatafile/c.LinearSolver.autotvout_a32.dat"
#define AUTOTB_TVIN_a33 "../tv/cdatafile/c.LinearSolver.autotvin_a33.dat"
#define AUTOTB_TVOUT_a33 "../tv/cdatafile/c.LinearSolver.autotvout_a33.dat"
#define AUTOTB_TVIN_a34 "../tv/cdatafile/c.LinearSolver.autotvin_a34.dat"
#define AUTOTB_TVOUT_a34 "../tv/cdatafile/c.LinearSolver.autotvout_a34.dat"
#define AUTOTB_TVIN_a41 "../tv/cdatafile/c.LinearSolver.autotvin_a41.dat"
#define AUTOTB_TVOUT_a41 "../tv/cdatafile/c.LinearSolver.autotvout_a41.dat"
#define AUTOTB_TVIN_a42 "../tv/cdatafile/c.LinearSolver.autotvin_a42.dat"
#define AUTOTB_TVOUT_a42 "../tv/cdatafile/c.LinearSolver.autotvout_a42.dat"
#define AUTOTB_TVIN_a43 "../tv/cdatafile/c.LinearSolver.autotvin_a43.dat"
#define AUTOTB_TVOUT_a43 "../tv/cdatafile/c.LinearSolver.autotvout_a43.dat"
#define AUTOTB_TVIN_a44 "../tv/cdatafile/c.LinearSolver.autotvin_a44.dat"
#define AUTOTB_TVOUT_a44 "../tv/cdatafile/c.LinearSolver.autotvout_a44.dat"
#define AUTOTB_TVIN_b1 "../tv/cdatafile/c.LinearSolver.autotvin_b1.dat"
#define AUTOTB_TVOUT_b1 "../tv/cdatafile/c.LinearSolver.autotvout_b1.dat"
#define AUTOTB_TVIN_b2 "../tv/cdatafile/c.LinearSolver.autotvin_b2.dat"
#define AUTOTB_TVOUT_b2 "../tv/cdatafile/c.LinearSolver.autotvout_b2.dat"
#define AUTOTB_TVIN_b3 "../tv/cdatafile/c.LinearSolver.autotvin_b3.dat"
#define AUTOTB_TVOUT_b3 "../tv/cdatafile/c.LinearSolver.autotvout_b3.dat"
#define AUTOTB_TVIN_b4 "../tv/cdatafile/c.LinearSolver.autotvin_b4.dat"
#define AUTOTB_TVOUT_b4 "../tv/cdatafile/c.LinearSolver.autotvout_b4.dat"
#define AUTOTB_TVIN_x1 "../tv/cdatafile/c.LinearSolver.autotvin_x1.dat"
#define AUTOTB_TVOUT_x1 "../tv/cdatafile/c.LinearSolver.autotvout_x1.dat"
#define AUTOTB_TVIN_x2 "../tv/cdatafile/c.LinearSolver.autotvin_x2.dat"
#define AUTOTB_TVOUT_x2 "../tv/cdatafile/c.LinearSolver.autotvout_x2.dat"
#define AUTOTB_TVIN_x3 "../tv/cdatafile/c.LinearSolver.autotvin_x3.dat"
#define AUTOTB_TVOUT_x3 "../tv/cdatafile/c.LinearSolver.autotvout_x3.dat"
#define AUTOTB_TVIN_x4 "../tv/cdatafile/c.LinearSolver.autotvin_x4.dat"
#define AUTOTB_TVOUT_x4 "../tv/cdatafile/c.LinearSolver.autotvout_x4.dat"

#define INTER_TCL "../tv/cdatafile/ref.tcl"

// tvout file define:
#define AUTOTB_TVOUT_PC_a11 "../tv/rtldatafile/rtl.LinearSolver.autotvout_a11.dat"
#define AUTOTB_TVOUT_PC_a12 "../tv/rtldatafile/rtl.LinearSolver.autotvout_a12.dat"
#define AUTOTB_TVOUT_PC_a13 "../tv/rtldatafile/rtl.LinearSolver.autotvout_a13.dat"
#define AUTOTB_TVOUT_PC_a14 "../tv/rtldatafile/rtl.LinearSolver.autotvout_a14.dat"
#define AUTOTB_TVOUT_PC_a21 "../tv/rtldatafile/rtl.LinearSolver.autotvout_a21.dat"
#define AUTOTB_TVOUT_PC_a22 "../tv/rtldatafile/rtl.LinearSolver.autotvout_a22.dat"
#define AUTOTB_TVOUT_PC_a23 "../tv/rtldatafile/rtl.LinearSolver.autotvout_a23.dat"
#define AUTOTB_TVOUT_PC_a24 "../tv/rtldatafile/rtl.LinearSolver.autotvout_a24.dat"
#define AUTOTB_TVOUT_PC_a31 "../tv/rtldatafile/rtl.LinearSolver.autotvout_a31.dat"
#define AUTOTB_TVOUT_PC_a32 "../tv/rtldatafile/rtl.LinearSolver.autotvout_a32.dat"
#define AUTOTB_TVOUT_PC_a33 "../tv/rtldatafile/rtl.LinearSolver.autotvout_a33.dat"
#define AUTOTB_TVOUT_PC_a34 "../tv/rtldatafile/rtl.LinearSolver.autotvout_a34.dat"
#define AUTOTB_TVOUT_PC_a41 "../tv/rtldatafile/rtl.LinearSolver.autotvout_a41.dat"
#define AUTOTB_TVOUT_PC_a42 "../tv/rtldatafile/rtl.LinearSolver.autotvout_a42.dat"
#define AUTOTB_TVOUT_PC_a43 "../tv/rtldatafile/rtl.LinearSolver.autotvout_a43.dat"
#define AUTOTB_TVOUT_PC_a44 "../tv/rtldatafile/rtl.LinearSolver.autotvout_a44.dat"
#define AUTOTB_TVOUT_PC_b1 "../tv/rtldatafile/rtl.LinearSolver.autotvout_b1.dat"
#define AUTOTB_TVOUT_PC_b2 "../tv/rtldatafile/rtl.LinearSolver.autotvout_b2.dat"
#define AUTOTB_TVOUT_PC_b3 "../tv/rtldatafile/rtl.LinearSolver.autotvout_b3.dat"
#define AUTOTB_TVOUT_PC_b4 "../tv/rtldatafile/rtl.LinearSolver.autotvout_b4.dat"
#define AUTOTB_TVOUT_PC_x1 "../tv/rtldatafile/rtl.LinearSolver.autotvout_x1.dat"
#define AUTOTB_TVOUT_PC_x2 "../tv/rtldatafile/rtl.LinearSolver.autotvout_x2.dat"
#define AUTOTB_TVOUT_PC_x3 "../tv/rtldatafile/rtl.LinearSolver.autotvout_x3.dat"
#define AUTOTB_TVOUT_PC_x4 "../tv/rtldatafile/rtl.LinearSolver.autotvout_x4.dat"


static const bool little_endian()
{
  int a = 1;
  return *(char*)&a == 1;
}

inline static void rev_endian(char* p, size_t nbytes)
{
  std::reverse(p, p+nbytes);
}

template<size_t bit_width>
struct transaction {
  typedef uint64_t depth_t;
  static const size_t wbytes = (bit_width+7)>>3;
  static const size_t dbytes = sizeof(depth_t);
  const depth_t depth;
  const size_t vbytes;
  const size_t tbytes;
  char * const p;
  typedef char (*p_dat)[wbytes];
  p_dat vp;

  transaction(depth_t depth)
    : depth(depth), vbytes(wbytes*depth), tbytes(dbytes+vbytes),
      p(new char[tbytes]) {
    *(depth_t*)p = depth;
    rev_endian(p, dbytes);
    vp = (p_dat) (p+dbytes);
  }

  void reorder() {
    rev_endian(p, dbytes);
    p_dat vp = (p_dat) (p+dbytes);
    for (depth_t i = 0; i < depth; ++i) {
      rev_endian(vp[i], wbytes);
    }
  }

  template<size_t psize>
  void import(char* param, depth_t num, int64_t offset) {
    param -= offset*psize;
    for (depth_t i = 0; i < num; ++i) {
      memcpy(vp[i], param, wbytes);
      param += psize;
      if (little_endian()) {
        rev_endian(vp[i], wbytes);
      }
    }
    vp += num;
  }

  template<size_t psize>
  void send(char* param, depth_t num) {
    for (depth_t i = 0; i < num; ++i) {
      memcpy(param, vp[i], wbytes);
      param += psize;
    }
    vp += num;
  }

  template<size_t psize>
  void send(char* param, depth_t num, int64_t skip) {
    for (depth_t i = 0; i < num; ++i) {
      memcpy(param, vp[skip+i], wbytes);
      param += psize;
    }
  }

  ~transaction() { if (p) { delete[] p; } }
};


inline static const std::string begin_str(int num)
{
  return std::string("[[transaction]]           ")
         .append(std::to_string(num))
         .append("\n");
}

inline static const std::string end_str()
{
  return std::string("[[/transaction]]\n");
}

const std::string formatData(unsigned char *pos, size_t wbits)
{
  bool LE = little_endian();
  size_t wbytes = (wbits+7)>>3;
  size_t i = LE ? wbytes-1 : 0;
  auto next = [&] () {
    auto c = pos[i];
    LE ? --i : ++i;
    return c;
  };
  std::ostringstream ss;
  ss << "0x";
  if (int t = (wbits & 0x7)) {
    if (t <= 4) {
      unsigned char mask = (1<<t)-1;
      ss << std::hex << std::setfill('0') << std::setw(1)
         << (int) (next() & mask);
      wbytes -= 1;
    }
  }
  for (size_t i = 0; i < wbytes; ++i) {
    ss << std::hex << std::setfill('0') << std::setw(2) << (int)next();
  }
  ss.put('\n');
  return ss.str();
}

static bool RTLOutputCheckAndReplacement(std::string &data)
{
  bool changed = false;
  for (size_t i = 2; i < data.size(); ++i) {
    if (data[i] == 'X' || data[i] == 'x') {
      data[i] = '0';
      changed = true;
    }
  }
  return changed;
}

struct SimException : public std::exception {
  const char *msg;
  const size_t line;
  SimException(const char *msg, const size_t line)
    : msg(msg), line(line)
  {
  }
};

template<size_t bit_width>
class PostCheck
{
  static const char *bad;
  static const char *err;
  std::fstream stream;
  std::string s;

  void send(char *p, ap_uint<bit_width> &data, size_t l, size_t rest)
  {
    if (rest == 0) {
      if (!little_endian()) {
        const size_t wbytes = (bit_width+7)>>3;
        rev_endian(p-wbytes, wbytes);
      }
    } else if (rest < 8) {
      *p = data.range(l+rest-1, l).to_uint();
      send(p+1, data, l+rest, 0);
    } else {
      *p = data.range(l+8-1, l).to_uint();
      send(p+1, data, l+8, rest-8);
    }
  }

  void readline()
  {
    std::getline(stream, s);
    if (stream.eof()) {
      throw SimException(bad, __LINE__);
    }
  }

public:
  char *param;
  size_t psize;
  size_t depth;

  PostCheck(const char *file)
  {
    stream.open(file);
    if (stream.fail()) {
      throw SimException(err, __LINE__);
    } else {
      readline();
      if (s != "[[[runtime]]]") {
        throw SimException(bad, __LINE__);
      }
    }
  }

  ~PostCheck() noexcept(false)
  {
    stream.close();
  }

  void run(size_t AESL_transaction_pc, size_t skip)
  {
    if (stream.peek() == '[') {
      readline();
    }

    for (size_t i = 0; i < skip; ++i) {
      readline();
    }

    bool foundX = false;
    for (size_t i = 0; i < depth; ++i) {
      readline();
      foundX |= RTLOutputCheckAndReplacement(s);
      ap_uint<bit_width> data(s.c_str(), 16);
      send(param+i*psize, data, 0, bit_width);
    }
    if (foundX) {
      std::cerr << "WARNING: [SIM 212-201] RTL produces unknown value "
                << "'x' or 'X' on some port, possible cause: "
                << "There are uninitialized variables in the design.\n";
    }

    if (stream.peek() == '[') {
      readline();
    }
  }
};

template<size_t bit_width>
const char* PostCheck<bit_width>::bad = "Bad TV file";

template<size_t bit_width>
const char* PostCheck<bit_width>::err = "Error on TV file";
      
class INTER_TCL_FILE {
  public:
INTER_TCL_FILE(const char* name) {
  mName = name; 
  a11_depth = 0;
  a12_depth = 0;
  a13_depth = 0;
  a14_depth = 0;
  a21_depth = 0;
  a22_depth = 0;
  a23_depth = 0;
  a24_depth = 0;
  a31_depth = 0;
  a32_depth = 0;
  a33_depth = 0;
  a34_depth = 0;
  a41_depth = 0;
  a42_depth = 0;
  a43_depth = 0;
  a44_depth = 0;
  b1_depth = 0;
  b2_depth = 0;
  b3_depth = 0;
  b4_depth = 0;
  x1_depth = 0;
  x2_depth = 0;
  x3_depth = 0;
  x4_depth = 0;
  trans_num =0;
}
~INTER_TCL_FILE() {
  mFile.open(mName);
  if (!mFile.good()) {
    cout << "Failed to open file ref.tcl" << endl;
    exit (1); 
  }
  string total_list = get_depth_list();
  mFile << "set depth_list {\n";
  mFile << total_list;
  mFile << "}\n";
  mFile << "set trans_num "<<trans_num<<endl;
  mFile.close();
}
string get_depth_list () {
  stringstream total_list;
  total_list << "{a11 " << a11_depth << "}\n";
  total_list << "{a12 " << a12_depth << "}\n";
  total_list << "{a13 " << a13_depth << "}\n";
  total_list << "{a14 " << a14_depth << "}\n";
  total_list << "{a21 " << a21_depth << "}\n";
  total_list << "{a22 " << a22_depth << "}\n";
  total_list << "{a23 " << a23_depth << "}\n";
  total_list << "{a24 " << a24_depth << "}\n";
  total_list << "{a31 " << a31_depth << "}\n";
  total_list << "{a32 " << a32_depth << "}\n";
  total_list << "{a33 " << a33_depth << "}\n";
  total_list << "{a34 " << a34_depth << "}\n";
  total_list << "{a41 " << a41_depth << "}\n";
  total_list << "{a42 " << a42_depth << "}\n";
  total_list << "{a43 " << a43_depth << "}\n";
  total_list << "{a44 " << a44_depth << "}\n";
  total_list << "{b1 " << b1_depth << "}\n";
  total_list << "{b2 " << b2_depth << "}\n";
  total_list << "{b3 " << b3_depth << "}\n";
  total_list << "{b4 " << b4_depth << "}\n";
  total_list << "{x1 " << x1_depth << "}\n";
  total_list << "{x2 " << x2_depth << "}\n";
  total_list << "{x3 " << x3_depth << "}\n";
  total_list << "{x4 " << x4_depth << "}\n";
  return total_list.str();
}
void set_num (int num , int* class_num) {
  (*class_num) = (*class_num) > num ? (*class_num) : num;
}
void set_string(std::string list, std::string* class_list) {
  (*class_list) = list;
}
  public:
    int a11_depth;
    int a12_depth;
    int a13_depth;
    int a14_depth;
    int a21_depth;
    int a22_depth;
    int a23_depth;
    int a24_depth;
    int a31_depth;
    int a32_depth;
    int a33_depth;
    int a34_depth;
    int a41_depth;
    int a42_depth;
    int a43_depth;
    int a44_depth;
    int b1_depth;
    int b2_depth;
    int b3_depth;
    int b4_depth;
    int x1_depth;
    int x2_depth;
    int x3_depth;
    int x4_depth;
    int trans_num;
  private:
    ofstream mFile;
    const char* mName;
};


struct __cosim_s4__ { char data[4]; };
extern "C" void LinearSolver_hw_stub_wrapper(__cosim_s4__*, __cosim_s4__*, __cosim_s4__*, __cosim_s4__*, __cosim_s4__*, __cosim_s4__*, __cosim_s4__*, __cosim_s4__*, __cosim_s4__*, __cosim_s4__*, __cosim_s4__*, __cosim_s4__*, __cosim_s4__*, __cosim_s4__*, __cosim_s4__*, __cosim_s4__*, __cosim_s4__*, __cosim_s4__*, __cosim_s4__*, __cosim_s4__*, volatile void *, volatile void *, volatile void *, volatile void *);

extern "C" void apatb_LinearSolver_hw(__cosim_s4__* __xlx_apatb_param_a11, __cosim_s4__* __xlx_apatb_param_a12, __cosim_s4__* __xlx_apatb_param_a13, __cosim_s4__* __xlx_apatb_param_a14, __cosim_s4__* __xlx_apatb_param_a21, __cosim_s4__* __xlx_apatb_param_a22, __cosim_s4__* __xlx_apatb_param_a23, __cosim_s4__* __xlx_apatb_param_a24, __cosim_s4__* __xlx_apatb_param_a31, __cosim_s4__* __xlx_apatb_param_a32, __cosim_s4__* __xlx_apatb_param_a33, __cosim_s4__* __xlx_apatb_param_a34, __cosim_s4__* __xlx_apatb_param_a41, __cosim_s4__* __xlx_apatb_param_a42, __cosim_s4__* __xlx_apatb_param_a43, __cosim_s4__* __xlx_apatb_param_a44, __cosim_s4__* __xlx_apatb_param_b1, __cosim_s4__* __xlx_apatb_param_b2, __cosim_s4__* __xlx_apatb_param_b3, __cosim_s4__* __xlx_apatb_param_b4, volatile void * __xlx_apatb_param_x1, volatile void * __xlx_apatb_param_x2, volatile void * __xlx_apatb_param_x3, volatile void * __xlx_apatb_param_x4) {
  refine_signal_handler();
  fstream wrapc_switch_file_token;
  wrapc_switch_file_token.open(".hls_cosim_wrapc_switch.log");
static AESL_FILE_HANDLER aesl_fh;
  int AESL_i;
  if (wrapc_switch_file_token.good())
  {

    CodeState = ENTER_WRAPC_PC;
    static unsigned AESL_transaction_pc = 0;
    string AESL_token;
    string AESL_num;
{
      static ifstream rtl_tv_out_file;
      if (!rtl_tv_out_file.is_open()) {
        rtl_tv_out_file.open(AUTOTB_TVOUT_PC_x1);
        if (rtl_tv_out_file.good()) {
          rtl_tv_out_file >> AESL_token;
          if (AESL_token != "[[[runtime]]]")
            exit(1);
        }
      }
  
      if (rtl_tv_out_file.good()) {
        rtl_tv_out_file >> AESL_token; 
        rtl_tv_out_file >> AESL_num;  // transaction number
        if (AESL_token != "[[transaction]]") {
          cerr << "Unexpected token: " << AESL_token << endl;
          exit(1);
        }
        if (atoi(AESL_num.c_str()) == AESL_transaction_pc) {
          std::vector<sc_bv<24> > x1_pc_buffer(1);
          int i = 0;
          bool has_unknown_value = false;
          rtl_tv_out_file >> AESL_token; //data
          while (AESL_token != "[[/transaction]]"){

            has_unknown_value |= RTLOutputCheckAndReplacement(AESL_token);
  
            // push token into output port buffer
            if (AESL_token != "") {
              x1_pc_buffer[i] = AESL_token.c_str();;
              i++;
            }
  
            rtl_tv_out_file >> AESL_token; //data or [[/transaction]]
            if (AESL_token == "[[[/runtime]]]" || rtl_tv_out_file.eof())
              exit(1);
          }
          if (has_unknown_value) {
            cerr << "WARNING: [SIM 212-201] RTL produces unknown value 'x' or 'X' on port " 
                 << "x1" << ", possible cause: There are uninitialized variables in the C design."
                 << endl; 
          }
  
          if (i > 0) {((char*)__xlx_apatb_param_x1)[0*3+0] = x1_pc_buffer[0].range(7, 0).to_int64();
((char*)__xlx_apatb_param_x1)[0*3+1] = x1_pc_buffer[0].range(15, 8).to_int64();
((char*)__xlx_apatb_param_x1)[0*3+2] = x1_pc_buffer[0].range(23, 16).to_int64();
}
        } // end transaction
      } // end file is good
    } // end post check logic bolck
  {
      static ifstream rtl_tv_out_file;
      if (!rtl_tv_out_file.is_open()) {
        rtl_tv_out_file.open(AUTOTB_TVOUT_PC_x2);
        if (rtl_tv_out_file.good()) {
          rtl_tv_out_file >> AESL_token;
          if (AESL_token != "[[[runtime]]]")
            exit(1);
        }
      }
  
      if (rtl_tv_out_file.good()) {
        rtl_tv_out_file >> AESL_token; 
        rtl_tv_out_file >> AESL_num;  // transaction number
        if (AESL_token != "[[transaction]]") {
          cerr << "Unexpected token: " << AESL_token << endl;
          exit(1);
        }
        if (atoi(AESL_num.c_str()) == AESL_transaction_pc) {
          std::vector<sc_bv<24> > x2_pc_buffer(1);
          int i = 0;
          bool has_unknown_value = false;
          rtl_tv_out_file >> AESL_token; //data
          while (AESL_token != "[[/transaction]]"){

            has_unknown_value |= RTLOutputCheckAndReplacement(AESL_token);
  
            // push token into output port buffer
            if (AESL_token != "") {
              x2_pc_buffer[i] = AESL_token.c_str();;
              i++;
            }
  
            rtl_tv_out_file >> AESL_token; //data or [[/transaction]]
            if (AESL_token == "[[[/runtime]]]" || rtl_tv_out_file.eof())
              exit(1);
          }
          if (has_unknown_value) {
            cerr << "WARNING: [SIM 212-201] RTL produces unknown value 'x' or 'X' on port " 
                 << "x2" << ", possible cause: There are uninitialized variables in the C design."
                 << endl; 
          }
  
          if (i > 0) {((char*)__xlx_apatb_param_x2)[0*3+0] = x2_pc_buffer[0].range(7, 0).to_int64();
((char*)__xlx_apatb_param_x2)[0*3+1] = x2_pc_buffer[0].range(15, 8).to_int64();
((char*)__xlx_apatb_param_x2)[0*3+2] = x2_pc_buffer[0].range(23, 16).to_int64();
}
        } // end transaction
      } // end file is good
    } // end post check logic bolck
  {
      static ifstream rtl_tv_out_file;
      if (!rtl_tv_out_file.is_open()) {
        rtl_tv_out_file.open(AUTOTB_TVOUT_PC_x3);
        if (rtl_tv_out_file.good()) {
          rtl_tv_out_file >> AESL_token;
          if (AESL_token != "[[[runtime]]]")
            exit(1);
        }
      }
  
      if (rtl_tv_out_file.good()) {
        rtl_tv_out_file >> AESL_token; 
        rtl_tv_out_file >> AESL_num;  // transaction number
        if (AESL_token != "[[transaction]]") {
          cerr << "Unexpected token: " << AESL_token << endl;
          exit(1);
        }
        if (atoi(AESL_num.c_str()) == AESL_transaction_pc) {
          std::vector<sc_bv<24> > x3_pc_buffer(1);
          int i = 0;
          bool has_unknown_value = false;
          rtl_tv_out_file >> AESL_token; //data
          while (AESL_token != "[[/transaction]]"){

            has_unknown_value |= RTLOutputCheckAndReplacement(AESL_token);
  
            // push token into output port buffer
            if (AESL_token != "") {
              x3_pc_buffer[i] = AESL_token.c_str();;
              i++;
            }
  
            rtl_tv_out_file >> AESL_token; //data or [[/transaction]]
            if (AESL_token == "[[[/runtime]]]" || rtl_tv_out_file.eof())
              exit(1);
          }
          if (has_unknown_value) {
            cerr << "WARNING: [SIM 212-201] RTL produces unknown value 'x' or 'X' on port " 
                 << "x3" << ", possible cause: There are uninitialized variables in the C design."
                 << endl; 
          }
  
          if (i > 0) {((char*)__xlx_apatb_param_x3)[0*3+0] = x3_pc_buffer[0].range(7, 0).to_int64();
((char*)__xlx_apatb_param_x3)[0*3+1] = x3_pc_buffer[0].range(15, 8).to_int64();
((char*)__xlx_apatb_param_x3)[0*3+2] = x3_pc_buffer[0].range(23, 16).to_int64();
}
        } // end transaction
      } // end file is good
    } // end post check logic bolck
  {
      static ifstream rtl_tv_out_file;
      if (!rtl_tv_out_file.is_open()) {
        rtl_tv_out_file.open(AUTOTB_TVOUT_PC_x4);
        if (rtl_tv_out_file.good()) {
          rtl_tv_out_file >> AESL_token;
          if (AESL_token != "[[[runtime]]]")
            exit(1);
        }
      }
  
      if (rtl_tv_out_file.good()) {
        rtl_tv_out_file >> AESL_token; 
        rtl_tv_out_file >> AESL_num;  // transaction number
        if (AESL_token != "[[transaction]]") {
          cerr << "Unexpected token: " << AESL_token << endl;
          exit(1);
        }
        if (atoi(AESL_num.c_str()) == AESL_transaction_pc) {
          std::vector<sc_bv<24> > x4_pc_buffer(1);
          int i = 0;
          bool has_unknown_value = false;
          rtl_tv_out_file >> AESL_token; //data
          while (AESL_token != "[[/transaction]]"){

            has_unknown_value |= RTLOutputCheckAndReplacement(AESL_token);
  
            // push token into output port buffer
            if (AESL_token != "") {
              x4_pc_buffer[i] = AESL_token.c_str();;
              i++;
            }
  
            rtl_tv_out_file >> AESL_token; //data or [[/transaction]]
            if (AESL_token == "[[[/runtime]]]" || rtl_tv_out_file.eof())
              exit(1);
          }
          if (has_unknown_value) {
            cerr << "WARNING: [SIM 212-201] RTL produces unknown value 'x' or 'X' on port " 
                 << "x4" << ", possible cause: There are uninitialized variables in the C design."
                 << endl; 
          }
  
          if (i > 0) {((char*)__xlx_apatb_param_x4)[0*3+0] = x4_pc_buffer[0].range(7, 0).to_int64();
((char*)__xlx_apatb_param_x4)[0*3+1] = x4_pc_buffer[0].range(15, 8).to_int64();
((char*)__xlx_apatb_param_x4)[0*3+2] = x4_pc_buffer[0].range(23, 16).to_int64();
}
        } // end transaction
      } // end file is good
    } // end post check logic bolck
  
    AESL_transaction_pc++;
    return ;
  }
static unsigned AESL_transaction;
static INTER_TCL_FILE tcl_file(INTER_TCL);
std::vector<char> __xlx_sprintf_buffer(1024);
CodeState = ENTER_WRAPC;
CodeState = DUMP_INPUTS;
// print a11 Transactions
{
aesl_fh.write(AUTOTB_TVIN_a11, begin_str(AESL_transaction));
{
auto *pos = (unsigned char*)__xlx_apatb_param_a11;
aesl_fh.write(AUTOTB_TVIN_a11, formatData(pos, 24));
}
  tcl_file.set_num(1, &tcl_file.a11_depth);
aesl_fh.write(AUTOTB_TVIN_a11, end_str());
}

// print a12 Transactions
{
aesl_fh.write(AUTOTB_TVIN_a12, begin_str(AESL_transaction));
{
auto *pos = (unsigned char*)__xlx_apatb_param_a12;
aesl_fh.write(AUTOTB_TVIN_a12, formatData(pos, 24));
}
  tcl_file.set_num(1, &tcl_file.a12_depth);
aesl_fh.write(AUTOTB_TVIN_a12, end_str());
}

// print a13 Transactions
{
aesl_fh.write(AUTOTB_TVIN_a13, begin_str(AESL_transaction));
{
auto *pos = (unsigned char*)__xlx_apatb_param_a13;
aesl_fh.write(AUTOTB_TVIN_a13, formatData(pos, 24));
}
  tcl_file.set_num(1, &tcl_file.a13_depth);
aesl_fh.write(AUTOTB_TVIN_a13, end_str());
}

// print a14 Transactions
{
aesl_fh.write(AUTOTB_TVIN_a14, begin_str(AESL_transaction));
{
auto *pos = (unsigned char*)__xlx_apatb_param_a14;
aesl_fh.write(AUTOTB_TVIN_a14, formatData(pos, 24));
}
  tcl_file.set_num(1, &tcl_file.a14_depth);
aesl_fh.write(AUTOTB_TVIN_a14, end_str());
}

// print a21 Transactions
{
aesl_fh.write(AUTOTB_TVIN_a21, begin_str(AESL_transaction));
{
auto *pos = (unsigned char*)__xlx_apatb_param_a21;
aesl_fh.write(AUTOTB_TVIN_a21, formatData(pos, 24));
}
  tcl_file.set_num(1, &tcl_file.a21_depth);
aesl_fh.write(AUTOTB_TVIN_a21, end_str());
}

// print a22 Transactions
{
aesl_fh.write(AUTOTB_TVIN_a22, begin_str(AESL_transaction));
{
auto *pos = (unsigned char*)__xlx_apatb_param_a22;
aesl_fh.write(AUTOTB_TVIN_a22, formatData(pos, 24));
}
  tcl_file.set_num(1, &tcl_file.a22_depth);
aesl_fh.write(AUTOTB_TVIN_a22, end_str());
}

// print a23 Transactions
{
aesl_fh.write(AUTOTB_TVIN_a23, begin_str(AESL_transaction));
{
auto *pos = (unsigned char*)__xlx_apatb_param_a23;
aesl_fh.write(AUTOTB_TVIN_a23, formatData(pos, 24));
}
  tcl_file.set_num(1, &tcl_file.a23_depth);
aesl_fh.write(AUTOTB_TVIN_a23, end_str());
}

// print a24 Transactions
{
aesl_fh.write(AUTOTB_TVIN_a24, begin_str(AESL_transaction));
{
auto *pos = (unsigned char*)__xlx_apatb_param_a24;
aesl_fh.write(AUTOTB_TVIN_a24, formatData(pos, 24));
}
  tcl_file.set_num(1, &tcl_file.a24_depth);
aesl_fh.write(AUTOTB_TVIN_a24, end_str());
}

// print a31 Transactions
{
aesl_fh.write(AUTOTB_TVIN_a31, begin_str(AESL_transaction));
{
auto *pos = (unsigned char*)__xlx_apatb_param_a31;
aesl_fh.write(AUTOTB_TVIN_a31, formatData(pos, 24));
}
  tcl_file.set_num(1, &tcl_file.a31_depth);
aesl_fh.write(AUTOTB_TVIN_a31, end_str());
}

// print a32 Transactions
{
aesl_fh.write(AUTOTB_TVIN_a32, begin_str(AESL_transaction));
{
auto *pos = (unsigned char*)__xlx_apatb_param_a32;
aesl_fh.write(AUTOTB_TVIN_a32, formatData(pos, 24));
}
  tcl_file.set_num(1, &tcl_file.a32_depth);
aesl_fh.write(AUTOTB_TVIN_a32, end_str());
}

// print a33 Transactions
{
aesl_fh.write(AUTOTB_TVIN_a33, begin_str(AESL_transaction));
{
auto *pos = (unsigned char*)__xlx_apatb_param_a33;
aesl_fh.write(AUTOTB_TVIN_a33, formatData(pos, 24));
}
  tcl_file.set_num(1, &tcl_file.a33_depth);
aesl_fh.write(AUTOTB_TVIN_a33, end_str());
}

// print a34 Transactions
{
aesl_fh.write(AUTOTB_TVIN_a34, begin_str(AESL_transaction));
{
auto *pos = (unsigned char*)__xlx_apatb_param_a34;
aesl_fh.write(AUTOTB_TVIN_a34, formatData(pos, 24));
}
  tcl_file.set_num(1, &tcl_file.a34_depth);
aesl_fh.write(AUTOTB_TVIN_a34, end_str());
}

// print a41 Transactions
{
aesl_fh.write(AUTOTB_TVIN_a41, begin_str(AESL_transaction));
{
auto *pos = (unsigned char*)__xlx_apatb_param_a41;
aesl_fh.write(AUTOTB_TVIN_a41, formatData(pos, 24));
}
  tcl_file.set_num(1, &tcl_file.a41_depth);
aesl_fh.write(AUTOTB_TVIN_a41, end_str());
}

// print a42 Transactions
{
aesl_fh.write(AUTOTB_TVIN_a42, begin_str(AESL_transaction));
{
auto *pos = (unsigned char*)__xlx_apatb_param_a42;
aesl_fh.write(AUTOTB_TVIN_a42, formatData(pos, 24));
}
  tcl_file.set_num(1, &tcl_file.a42_depth);
aesl_fh.write(AUTOTB_TVIN_a42, end_str());
}

// print a43 Transactions
{
aesl_fh.write(AUTOTB_TVIN_a43, begin_str(AESL_transaction));
{
auto *pos = (unsigned char*)__xlx_apatb_param_a43;
aesl_fh.write(AUTOTB_TVIN_a43, formatData(pos, 24));
}
  tcl_file.set_num(1, &tcl_file.a43_depth);
aesl_fh.write(AUTOTB_TVIN_a43, end_str());
}

// print a44 Transactions
{
aesl_fh.write(AUTOTB_TVIN_a44, begin_str(AESL_transaction));
{
auto *pos = (unsigned char*)__xlx_apatb_param_a44;
aesl_fh.write(AUTOTB_TVIN_a44, formatData(pos, 24));
}
  tcl_file.set_num(1, &tcl_file.a44_depth);
aesl_fh.write(AUTOTB_TVIN_a44, end_str());
}

// print b1 Transactions
{
aesl_fh.write(AUTOTB_TVIN_b1, begin_str(AESL_transaction));
{
auto *pos = (unsigned char*)__xlx_apatb_param_b1;
aesl_fh.write(AUTOTB_TVIN_b1, formatData(pos, 24));
}
  tcl_file.set_num(1, &tcl_file.b1_depth);
aesl_fh.write(AUTOTB_TVIN_b1, end_str());
}

// print b2 Transactions
{
aesl_fh.write(AUTOTB_TVIN_b2, begin_str(AESL_transaction));
{
auto *pos = (unsigned char*)__xlx_apatb_param_b2;
aesl_fh.write(AUTOTB_TVIN_b2, formatData(pos, 24));
}
  tcl_file.set_num(1, &tcl_file.b2_depth);
aesl_fh.write(AUTOTB_TVIN_b2, end_str());
}

// print b3 Transactions
{
aesl_fh.write(AUTOTB_TVIN_b3, begin_str(AESL_transaction));
{
auto *pos = (unsigned char*)__xlx_apatb_param_b3;
aesl_fh.write(AUTOTB_TVIN_b3, formatData(pos, 24));
}
  tcl_file.set_num(1, &tcl_file.b3_depth);
aesl_fh.write(AUTOTB_TVIN_b3, end_str());
}

// print b4 Transactions
{
aesl_fh.write(AUTOTB_TVIN_b4, begin_str(AESL_transaction));
{
auto *pos = (unsigned char*)__xlx_apatb_param_b4;
aesl_fh.write(AUTOTB_TVIN_b4, formatData(pos, 24));
}
  tcl_file.set_num(1, &tcl_file.b4_depth);
aesl_fh.write(AUTOTB_TVIN_b4, end_str());
}

// print x1 Transactions
{
aesl_fh.write(AUTOTB_TVIN_x1, begin_str(AESL_transaction));
{
auto *pos = (unsigned char*)__xlx_apatb_param_x1;
aesl_fh.write(AUTOTB_TVIN_x1, formatData(pos, 24));
}
  tcl_file.set_num(1, &tcl_file.x1_depth);
aesl_fh.write(AUTOTB_TVIN_x1, end_str());
}

// print x2 Transactions
{
aesl_fh.write(AUTOTB_TVIN_x2, begin_str(AESL_transaction));
{
auto *pos = (unsigned char*)__xlx_apatb_param_x2;
aesl_fh.write(AUTOTB_TVIN_x2, formatData(pos, 24));
}
  tcl_file.set_num(1, &tcl_file.x2_depth);
aesl_fh.write(AUTOTB_TVIN_x2, end_str());
}

// print x3 Transactions
{
aesl_fh.write(AUTOTB_TVIN_x3, begin_str(AESL_transaction));
{
auto *pos = (unsigned char*)__xlx_apatb_param_x3;
aesl_fh.write(AUTOTB_TVIN_x3, formatData(pos, 24));
}
  tcl_file.set_num(1, &tcl_file.x3_depth);
aesl_fh.write(AUTOTB_TVIN_x3, end_str());
}

// print x4 Transactions
{
aesl_fh.write(AUTOTB_TVIN_x4, begin_str(AESL_transaction));
{
auto *pos = (unsigned char*)__xlx_apatb_param_x4;
aesl_fh.write(AUTOTB_TVIN_x4, formatData(pos, 24));
}
  tcl_file.set_num(1, &tcl_file.x4_depth);
aesl_fh.write(AUTOTB_TVIN_x4, end_str());
}

CodeState = CALL_C_DUT;
LinearSolver_hw_stub_wrapper(__xlx_apatb_param_a11, __xlx_apatb_param_a12, __xlx_apatb_param_a13, __xlx_apatb_param_a14, __xlx_apatb_param_a21, __xlx_apatb_param_a22, __xlx_apatb_param_a23, __xlx_apatb_param_a24, __xlx_apatb_param_a31, __xlx_apatb_param_a32, __xlx_apatb_param_a33, __xlx_apatb_param_a34, __xlx_apatb_param_a41, __xlx_apatb_param_a42, __xlx_apatb_param_a43, __xlx_apatb_param_a44, __xlx_apatb_param_b1, __xlx_apatb_param_b2, __xlx_apatb_param_b3, __xlx_apatb_param_b4, __xlx_apatb_param_x1, __xlx_apatb_param_x2, __xlx_apatb_param_x3, __xlx_apatb_param_x4);
CodeState = DUMP_OUTPUTS;
// print x1 Transactions
{
aesl_fh.write(AUTOTB_TVOUT_x1, begin_str(AESL_transaction));
{
auto *pos = (unsigned char*)__xlx_apatb_param_x1;
aesl_fh.write(AUTOTB_TVOUT_x1, formatData(pos, 24));
}
  tcl_file.set_num(1, &tcl_file.x1_depth);
aesl_fh.write(AUTOTB_TVOUT_x1, end_str());
}

// print x2 Transactions
{
aesl_fh.write(AUTOTB_TVOUT_x2, begin_str(AESL_transaction));
{
auto *pos = (unsigned char*)__xlx_apatb_param_x2;
aesl_fh.write(AUTOTB_TVOUT_x2, formatData(pos, 24));
}
  tcl_file.set_num(1, &tcl_file.x2_depth);
aesl_fh.write(AUTOTB_TVOUT_x2, end_str());
}

// print x3 Transactions
{
aesl_fh.write(AUTOTB_TVOUT_x3, begin_str(AESL_transaction));
{
auto *pos = (unsigned char*)__xlx_apatb_param_x3;
aesl_fh.write(AUTOTB_TVOUT_x3, formatData(pos, 24));
}
  tcl_file.set_num(1, &tcl_file.x3_depth);
aesl_fh.write(AUTOTB_TVOUT_x3, end_str());
}

// print x4 Transactions
{
aesl_fh.write(AUTOTB_TVOUT_x4, begin_str(AESL_transaction));
{
auto *pos = (unsigned char*)__xlx_apatb_param_x4;
aesl_fh.write(AUTOTB_TVOUT_x4, formatData(pos, 24));
}
  tcl_file.set_num(1, &tcl_file.x4_depth);
aesl_fh.write(AUTOTB_TVOUT_x4, end_str());
}

CodeState = DELETE_CHAR_BUFFERS;
AESL_transaction++;
tcl_file.set_num(AESL_transaction , &tcl_file.trans_num);
}
