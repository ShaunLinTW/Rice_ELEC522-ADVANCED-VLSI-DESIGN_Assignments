#ifndef PROJECT5__H
#define PROJECT5__H
#ifdef __cplusplus
extern "C" {
#endif
/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "project5_hw.h"
/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
#else
typedef struct {
    u16 DeviceId;
    u32 project5_BaseAddress;
} project5_Config;
#endif
/**
* The project5 driver instance data. The user is required to
* allocate a variable of this type for every project5 device in the system.
* A pointer to a variable of this type is then passed to the driver
* API functions.
*/
typedef struct {
    u32 project5_BaseAddress;
    u32 IsReady;
} project5;
/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define project5_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define project5_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define project5_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define project5_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif
/************************** Function Prototypes *****************************/
#ifndef __linux__
int project5_Initialize(project5 *InstancePtr, u16 DeviceId);
project5_Config* project5_LookupConfig(u16 DeviceId);
int project5_CfgInitialize(project5 *InstancePtr, project5_Config *ConfigPtr);
#else
int project5_Initialize(project5 *InstancePtr, const char* InstanceName);
int project5_Release(project5 *InstancePtr);
#endif
/**
* Write to matrix_b_input gateway of project5. Assignments are LSB-justified.
*
* @param	InstancePtr is the matrix_b_input instance to operate on.
* @param	Data is value to be written to gateway matrix_b_input.
*
* @return	None.
*
* @note    .
*
*/
void project5_matrix_b_input_write(project5 *InstancePtr, int Data);
/**
* Read from matrix_b_input gateway of project5. Assignments are LSB-justified.
*
* @param	InstancePtr is the matrix_b_input instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int project5_matrix_b_input_read(project5 *InstancePtr);
/**
* Write to start gateway of project5. Assignments are LSB-justified.
*
* @param	InstancePtr is the start instance to operate on.
* @param	Data is value to be written to gateway start.
*
* @return	None.
*
* @note    .
*
*/
void project5_start_write(project5 *InstancePtr, u32 Data);
/**
* Read from start gateway of project5. Assignments are LSB-justified.
*
* @param	InstancePtr is the start instance to operate on.
*
* @return	u32
*
* @note    .
*
*/
u32 project5_start_read(project5 *InstancePtr);
/**
* Write to mfq4 gateway of project5. Assignments are LSB-justified.
*
* @param	InstancePtr is the mfq4 instance to operate on.
* @param	Data is value to be written to gateway mfq4.
*
* @return	None.
*
* @note    .
*
*/
void project5_mfq4_write(project5 *InstancePtr, int Data);
/**
* Read from mfq4 gateway of project5. Assignments are LSB-justified.
*
* @param	InstancePtr is the mfq4 instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int project5_mfq4_read(project5 *InstancePtr);
/**
* Write to mfq1 gateway of project5. Assignments are LSB-justified.
*
* @param	InstancePtr is the mfq1 instance to operate on.
* @param	Data is value to be written to gateway mfq1.
*
* @return	None.
*
* @note    .
*
*/
void project5_mfq1_write(project5 *InstancePtr, int Data);
/**
* Read from mfq1 gateway of project5. Assignments are LSB-justified.
*
* @param	InstancePtr is the mfq1 instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int project5_mfq1_read(project5 *InstancePtr);
/**
* Write to row4a gateway of project5. Assignments are LSB-justified.
*
* @param	InstancePtr is the row4a instance to operate on.
* @param	Data is value to be written to gateway row4a.
*
* @return	None.
*
* @note    .
*
*/
void project5_row4a_write(project5 *InstancePtr, int Data);
/**
* Read from row4a gateway of project5. Assignments are LSB-justified.
*
* @param	InstancePtr is the row4a instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int project5_row4a_read(project5 *InstancePtr);
/**
* Write to mfq3 gateway of project5. Assignments are LSB-justified.
*
* @param	InstancePtr is the mfq3 instance to operate on.
* @param	Data is value to be written to gateway mfq3.
*
* @return	None.
*
* @note    .
*
*/
void project5_mfq3_write(project5 *InstancePtr, int Data);
/**
* Read from mfq3 gateway of project5. Assignments are LSB-justified.
*
* @param	InstancePtr is the mfq3 instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int project5_mfq3_read(project5 *InstancePtr);
/**
* Write to row3a gateway of project5. Assignments are LSB-justified.
*
* @param	InstancePtr is the row3a instance to operate on.
* @param	Data is value to be written to gateway row3a.
*
* @return	None.
*
* @note    .
*
*/
void project5_row3a_write(project5 *InstancePtr, int Data);
/**
* Read from row3a gateway of project5. Assignments are LSB-justified.
*
* @param	InstancePtr is the row3a instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int project5_row3a_read(project5 *InstancePtr);
/**
* Write to mfq2 gateway of project5. Assignments are LSB-justified.
*
* @param	InstancePtr is the mfq2 instance to operate on.
* @param	Data is value to be written to gateway mfq2.
*
* @return	None.
*
* @note    .
*
*/
void project5_mfq2_write(project5 *InstancePtr, int Data);
/**
* Read from mfq2 gateway of project5. Assignments are LSB-justified.
*
* @param	InstancePtr is the mfq2 instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int project5_mfq2_read(project5 *InstancePtr);
/**
* Write to row2a gateway of project5. Assignments are LSB-justified.
*
* @param	InstancePtr is the row2a instance to operate on.
* @param	Data is value to be written to gateway row2a.
*
* @return	None.
*
* @note    .
*
*/
void project5_row2a_write(project5 *InstancePtr, int Data);
/**
* Read from row2a gateway of project5. Assignments are LSB-justified.
*
* @param	InstancePtr is the row2a instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int project5_row2a_read(project5 *InstancePtr);
/**
* Write to ctrl_input gateway of project5. Assignments are LSB-justified.
*
* @param	InstancePtr is the ctrl_input instance to operate on.
* @param	Data is value to be written to gateway ctrl_input.
*
* @return	None.
*
* @note    .
*
*/
void project5_ctrl_input_write(project5 *InstancePtr, u32 Data);
/**
* Read from ctrl_input gateway of project5. Assignments are LSB-justified.
*
* @param	InstancePtr is the ctrl_input instance to operate on.
*
* @return	u32
*
* @note    .
*
*/
u32 project5_ctrl_input_read(project5 *InstancePtr);
/**
* Write to row1a gateway of project5. Assignments are LSB-justified.
*
* @param	InstancePtr is the row1a instance to operate on.
* @param	Data is value to be written to gateway row1a.
*
* @return	None.
*
* @note    .
*
*/
void project5_row1a_write(project5 *InstancePtr, int Data);
/**
* Read from row1a gateway of project5. Assignments are LSB-justified.
*
* @param	InstancePtr is the row1a instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int project5_row1a_read(project5 *InstancePtr);
/**
* Read from r2out gateway of project5. Assignments are LSB-justified.
*
* @param	InstancePtr is the r2out instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int project5_r2out_read(project5 *InstancePtr);
/**
* Read from r3out gateway of project5. Assignments are LSB-justified.
*
* @param	InstancePtr is the r3out instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int project5_r3out_read(project5 *InstancePtr);
/**
* Read from r1out gateway of project5. Assignments are LSB-justified.
*
* @param	InstancePtr is the r1out instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int project5_r1out_read(project5 *InstancePtr);
/**
* Read from r4out gateway of project5. Assignments are LSB-justified.
*
* @param	InstancePtr is the r4out instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int project5_r4out_read(project5 *InstancePtr);
/**
* Read from y2out gateway of project5. Assignments are LSB-justified.
*
* @param	InstancePtr is the y2out instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int project5_y2out_read(project5 *InstancePtr);
/**
* Read from yout3 gateway of project5. Assignments are LSB-justified.
*
* @param	InstancePtr is the yout3 instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int project5_yout3_read(project5 *InstancePtr);
/**
* Read from yout4 gateway of project5. Assignments are LSB-justified.
*
* @param	InstancePtr is the yout4 instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int project5_yout4_read(project5 *InstancePtr);
/**
* Read from done gateway of project5. Assignments are LSB-justified.
*
* @param	InstancePtr is the done instance to operate on.
*
* @return	u32
*
* @note    .
*
*/
u32 project5_done_read(project5 *InstancePtr);
/**
* Read from y1output gateway of project5. Assignments are LSB-justified.
*
* @param	InstancePtr is the y1output instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int project5_y1output_read(project5 *InstancePtr);
#ifdef __cplusplus
}
#endif
#endif
