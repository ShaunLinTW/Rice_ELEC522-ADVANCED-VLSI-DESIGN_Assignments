#include "project5.h"
#ifndef __linux__
int project5_CfgInitialize(project5 *InstancePtr, project5_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->project5_BaseAddress = ConfigPtr->project5_BaseAddress;

    InstancePtr->IsReady = 1;
    return XST_SUCCESS;
}
#endif
void project5_matrix_b_input_write(project5 *InstancePtr, int Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    project5_WriteReg(InstancePtr->project5_BaseAddress, 0, Data);
}
int project5_matrix_b_input_read(project5 *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = project5_ReadReg(InstancePtr->project5_BaseAddress, 0);
    return Data;
}
void project5_start_write(project5 *InstancePtr, u32 Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    project5_WriteReg(InstancePtr->project5_BaseAddress, 4, Data);
}
u32 project5_start_read(project5 *InstancePtr) {

    u32 Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = project5_ReadReg(InstancePtr->project5_BaseAddress, 4);
    return Data;
}
void project5_mfq4_write(project5 *InstancePtr, int Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    project5_WriteReg(InstancePtr->project5_BaseAddress, 8, Data);
}
int project5_mfq4_read(project5 *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = project5_ReadReg(InstancePtr->project5_BaseAddress, 8);
    return Data;
}
void project5_mfq1_write(project5 *InstancePtr, int Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    project5_WriteReg(InstancePtr->project5_BaseAddress, 12, Data);
}
int project5_mfq1_read(project5 *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = project5_ReadReg(InstancePtr->project5_BaseAddress, 12);
    return Data;
}
void project5_row4a_write(project5 *InstancePtr, int Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    project5_WriteReg(InstancePtr->project5_BaseAddress, 16, Data);
}
int project5_row4a_read(project5 *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = project5_ReadReg(InstancePtr->project5_BaseAddress, 16);
    return Data;
}
void project5_mfq3_write(project5 *InstancePtr, int Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    project5_WriteReg(InstancePtr->project5_BaseAddress, 20, Data);
}
int project5_mfq3_read(project5 *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = project5_ReadReg(InstancePtr->project5_BaseAddress, 20);
    return Data;
}
void project5_row3a_write(project5 *InstancePtr, int Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    project5_WriteReg(InstancePtr->project5_BaseAddress, 24, Data);
}
int project5_row3a_read(project5 *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = project5_ReadReg(InstancePtr->project5_BaseAddress, 24);
    return Data;
}
void project5_mfq2_write(project5 *InstancePtr, int Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    project5_WriteReg(InstancePtr->project5_BaseAddress, 28, Data);
}
int project5_mfq2_read(project5 *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = project5_ReadReg(InstancePtr->project5_BaseAddress, 28);
    return Data;
}
void project5_row2a_write(project5 *InstancePtr, int Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    project5_WriteReg(InstancePtr->project5_BaseAddress, 32, Data);
}
int project5_row2a_read(project5 *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = project5_ReadReg(InstancePtr->project5_BaseAddress, 32);
    return Data;
}
void project5_ctrl_input_write(project5 *InstancePtr, u32 Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    project5_WriteReg(InstancePtr->project5_BaseAddress, 36, Data);
}
u32 project5_ctrl_input_read(project5 *InstancePtr) {

    u32 Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = project5_ReadReg(InstancePtr->project5_BaseAddress, 36);
    return Data;
}
void project5_row1a_write(project5 *InstancePtr, int Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    project5_WriteReg(InstancePtr->project5_BaseAddress, 40, Data);
}
int project5_row1a_read(project5 *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = project5_ReadReg(InstancePtr->project5_BaseAddress, 40);
    return Data;
}
int project5_r2out_read(project5 *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = project5_ReadReg(InstancePtr->project5_BaseAddress, 44);
    return Data;
}
int project5_r3out_read(project5 *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = project5_ReadReg(InstancePtr->project5_BaseAddress, 48);
    return Data;
}
int project5_r1out_read(project5 *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = project5_ReadReg(InstancePtr->project5_BaseAddress, 52);
    return Data;
}
int project5_r4out_read(project5 *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = project5_ReadReg(InstancePtr->project5_BaseAddress, 56);
    return Data;
}
int project5_y2out_read(project5 *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = project5_ReadReg(InstancePtr->project5_BaseAddress, 60);
    return Data;
}
int project5_yout3_read(project5 *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = project5_ReadReg(InstancePtr->project5_BaseAddress, 64);
    return Data;
}
int project5_yout4_read(project5 *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = project5_ReadReg(InstancePtr->project5_BaseAddress, 68);
    return Data;
}
u32 project5_done_read(project5 *InstancePtr) {

    u32 Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = project5_ReadReg(InstancePtr->project5_BaseAddress, 72);
    return Data;
}
int project5_y1output_read(project5 *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = project5_ReadReg(InstancePtr->project5_BaseAddress, 76);
    return Data;
}
