/**
* @file project5_sinit.c
*
* The implementation of the project5 driver's static initialzation
* functionality.
*
* @note
*
* None
*
*/
#ifndef __linux__
#include "xstatus.h"
#include "xparameters.h"
#include "project5.h"
extern project5_Config project5_ConfigTable[];
/**
* Lookup the device configuration based on the unique device ID.  The table
* ConfigTable contains the configuration info for each device in the system.
*
* @param DeviceId is the device identifier to lookup.
*
* @return
*     - A pointer of data type project5_Config which
*    points to the device configuration if DeviceID is found.
*    - NULL if DeviceID is not found.
*
* @note    None.
*
*/
project5_Config *project5_LookupConfig(u16 DeviceId) {
    project5_Config *ConfigPtr = NULL;
    int Index;
    for (Index = 0; Index < XPAR_PROJECT5_NUM_INSTANCES; Index++) {
        if (project5_ConfigTable[Index].DeviceId == DeviceId) {
            ConfigPtr = &project5_ConfigTable[Index];
            break;
        }
    }
    return ConfigPtr;
}
int project5_Initialize(project5 *InstancePtr, u16 DeviceId) {
    project5_Config *ConfigPtr;
    Xil_AssertNonvoid(InstancePtr != NULL);
    ConfigPtr = project5_LookupConfig(DeviceId);
    if (ConfigPtr == NULL) {
        InstancePtr->IsReady = 0;
        return (XST_DEVICE_NOT_FOUND);
    }
    return project5_CfgInitialize(InstancePtr, ConfigPtr);
}
#endif
