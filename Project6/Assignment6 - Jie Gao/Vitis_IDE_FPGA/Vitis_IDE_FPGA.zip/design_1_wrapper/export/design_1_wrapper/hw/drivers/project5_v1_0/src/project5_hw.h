/**
*
* @file project5_hw.h
*
* This header file contains identifiers and driver functions (or
* macros) that can be used to access the device.  The user should refer to the
* hardware device specification for more details of the device operation.
*/ 
#define PROJECT5_MATRIX_B_INPUT 0x0/**< matrix_b_input */
#define PROJECT5_START 0x4/**< start */
#define PROJECT5_MFQ4 0x8/**< mfq4 */
#define PROJECT5_MFQ1 0xc/**< mfq1 */
#define PROJECT5_ROW4A 0x10/**< row4a */
#define PROJECT5_MFQ3 0x14/**< mfq3 */
#define PROJECT5_ROW3A 0x18/**< row3a */
#define PROJECT5_MFQ2 0x1c/**< mfq2 */
#define PROJECT5_ROW2A 0x20/**< row2a */
#define PROJECT5_CTRL_INPUT 0x24/**< ctrl_input */
#define PROJECT5_ROW1A 0x28/**< row1a */
#define PROJECT5_R2OUT 0x2c/**< r2out */
#define PROJECT5_R3OUT 0x30/**< r3out */
#define PROJECT5_R1OUT 0x34/**< r1out */
#define PROJECT5_R4OUT 0x38/**< r4out */
#define PROJECT5_Y2OUT 0x3c/**< y2out */
#define PROJECT5_YOUT3 0x40/**< yout3 */
#define PROJECT5_YOUT4 0x44/**< yout4 */
#define PROJECT5_DONE 0x48/**< done */
#define PROJECT5_Y1OUTPUT 0x4c/**< y1output */
