/**
* @file lab_6_lin_solver_sinit.c
*
* The implementation of the lab_6_lin_solver driver's static initialzation
* functionality.
*
* @note
*
* None
*
*/
#ifndef __linux__
#include "xstatus.h"
#include "xparameters.h"
#include "lab_6_lin_solver.h"
extern lab_6_lin_solver_Config lab_6_lin_solver_ConfigTable[];
/**
* Lookup the device configuration based on the unique device ID.  The table
* ConfigTable contains the configuration info for each device in the system.
*
* @param DeviceId is the device identifier to lookup.
*
* @return
*     - A pointer of data type lab_6_lin_solver_Config which
*    points to the device configuration if DeviceID is found.
*    - NULL if DeviceID is not found.
*
* @note    None.
*
*/
lab_6_lin_solver_Config *lab_6_lin_solver_LookupConfig(u16 DeviceId) {
    lab_6_lin_solver_Config *ConfigPtr = NULL;
    int Index;
    for (Index = 0; Index < XPAR_LAB_6_LIN_SOLVER_NUM_INSTANCES; Index++) {
        if (lab_6_lin_solver_ConfigTable[Index].DeviceId == DeviceId) {
            ConfigPtr = &lab_6_lin_solver_ConfigTable[Index];
            break;
        }
    }
    return ConfigPtr;
}
int lab_6_lin_solver_Initialize(lab_6_lin_solver *InstancePtr, u16 DeviceId) {
    lab_6_lin_solver_Config *ConfigPtr;
    Xil_AssertNonvoid(InstancePtr != NULL);
    ConfigPtr = lab_6_lin_solver_LookupConfig(DeviceId);
    if (ConfigPtr == NULL) {
        InstancePtr->IsReady = 0;
        return (XST_DEVICE_NOT_FOUND);
    }
    return lab_6_lin_solver_CfgInitialize(InstancePtr, ConfigPtr);
}
#endif
