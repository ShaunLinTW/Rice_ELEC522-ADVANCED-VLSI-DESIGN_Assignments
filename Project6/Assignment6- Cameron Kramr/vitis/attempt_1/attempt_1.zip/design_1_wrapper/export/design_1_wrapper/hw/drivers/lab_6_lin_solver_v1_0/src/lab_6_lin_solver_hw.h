/**
*
* @file lab_6_lin_solver_hw.h
*
* This header file contains identifiers and driver functions (or
* macros) that can be used to access the device.  The user should refer to the
* hardware device specification for more details of the device operation.
*/ 
#define LAB_6_LIN_SOLVER_B_4 0x0/**< b_4 */
#define LAB_6_LIN_SOLVER_B_2 0x4/**< b_2 */
#define LAB_6_LIN_SOLVER_B_1 0x8/**< b_1 */
#define LAB_6_LIN_SOLVER_B_3 0xc/**< b_3 */
#define LAB_6_LIN_SOLVER_IN_8 0x10/**< in_8 */
#define LAB_6_LIN_SOLVER_IN_7 0x14/**< in_7 */
#define LAB_6_LIN_SOLVER_IN_6 0x18/**< in_6 */
#define LAB_6_LIN_SOLVER_IN_5 0x1c/**< in_5 */
#define LAB_6_LIN_SOLVER_IN_43 0x20/**< in_43 */
#define LAB_6_LIN_SOLVER_IN_42 0x24/**< in_42 */
#define LAB_6_LIN_SOLVER_IN_41 0x28/**< in_41 */
#define LAB_6_LIN_SOLVER_IN_33 0x2c/**< in_33 */
#define LAB_6_LIN_SOLVER_IN_32 0x30/**< in_32 */
#define LAB_6_LIN_SOLVER_IN_31 0x34/**< in_31 */
#define LAB_6_LIN_SOLVER_IN_23 0x38/**< in_23 */
#define LAB_6_LIN_SOLVER_IN_22 0x3c/**< in_22 */
#define LAB_6_LIN_SOLVER_IN_21 0x40/**< in_21 */
#define LAB_6_LIN_SOLVER_IN_13 0x44/**< in_13 */
#define LAB_6_LIN_SOLVER_IN_12 0x48/**< in_12 */
#define LAB_6_LIN_SOLVER_IN_11 0x4c/**< in_11 */
#define LAB_6_LIN_SOLVER_START_NEW 0x0/**< start_new */
#define LAB_6_LIN_SOLVER_AP_RST 0x4/**< ap_rst */
#define LAB_6_LIN_SOLVER_DONE_OUT 0x8/**< done_out */
#define LAB_6_LIN_SOLVER_C_1 0x0/**< c_1 */
#define LAB_6_LIN_SOLVER_C_2 0x4/**< c_2 */
#define LAB_6_LIN_SOLVER_C_3 0x8/**< c_3 */
#define LAB_6_LIN_SOLVER_C_4 0xc/**< c_4 */
#define LAB_6_LIN_SOLVER_R_11 0x10/**< r_11 */
#define LAB_6_LIN_SOLVER_R_12 0x14/**< r_12 */
#define LAB_6_LIN_SOLVER_R_13 0x18/**< r_13 */
#define LAB_6_LIN_SOLVER_R_14 0x1c/**< r_14 */
#define LAB_6_LIN_SOLVER_R_22 0x20/**< r_22 */
#define LAB_6_LIN_SOLVER_R_23 0x24/**< r_23 */
#define LAB_6_LIN_SOLVER_R_24 0x28/**< r_24 */
#define LAB_6_LIN_SOLVER_R_33 0x2c/**< r_33 */
#define LAB_6_LIN_SOLVER_R_34 0x30/**< r_34 */
#define LAB_6_LIN_SOLVER_R_44 0x34/**< r_44 */
