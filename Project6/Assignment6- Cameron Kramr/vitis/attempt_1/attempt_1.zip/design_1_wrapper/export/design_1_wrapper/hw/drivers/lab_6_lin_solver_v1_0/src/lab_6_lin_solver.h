#ifndef LAB_6_LIN_SOLVER__H
#define LAB_6_LIN_SOLVER__H
#ifdef __cplusplus
extern "C" {
#endif
/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "lab_6_lin_solver_hw.h"
/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
#else
typedef struct {
    u16 DeviceId;
    u32 lab_6_lin_solver_array_input_BaseAddress;
    u32 lab_6_lin_solver_control_BaseAddress;
    u32 lab_6_lin_solver_output_BaseAddress;
} lab_6_lin_solver_Config;
#endif
/**
* The lab_6_lin_solver driver instance data. The user is required to
* allocate a variable of this type for every lab_6_lin_solver device in the system.
* A pointer to a variable of this type is then passed to the driver
* API functions.
*/
typedef struct {
    u32 lab_6_lin_solver_array_input_BaseAddress;
    u32 lab_6_lin_solver_control_BaseAddress;
    u32 lab_6_lin_solver_output_BaseAddress;
    u32 IsReady;
} lab_6_lin_solver;
/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define lab_6_lin_solver_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define lab_6_lin_solver_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define lab_6_lin_solver_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define lab_6_lin_solver_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif
/************************** Function Prototypes *****************************/
#ifndef __linux__
int lab_6_lin_solver_Initialize(lab_6_lin_solver *InstancePtr, u16 DeviceId);
lab_6_lin_solver_Config* lab_6_lin_solver_LookupConfig(u16 DeviceId);
int lab_6_lin_solver_CfgInitialize(lab_6_lin_solver *InstancePtr, lab_6_lin_solver_Config *ConfigPtr);
#else
int lab_6_lin_solver_Initialize(lab_6_lin_solver *InstancePtr, const char* InstanceName);
int lab_6_lin_solver_Release(lab_6_lin_solver *InstancePtr);
#endif
/**
* Write to b_4 gateway of lab_6_lin_solver. Assignments are LSB-justified.
*
* @param	InstancePtr is the b_4 instance to operate on.
* @param	Data is value to be written to gateway b_4.
*
* @return	None.
*
* @note    .
*
*/
void lab_6_lin_solver_b_4_write(lab_6_lin_solver *InstancePtr, int Data);
/**
* Read from b_4 gateway of lab_6_lin_solver. Assignments are LSB-justified.
*
* @param	InstancePtr is the b_4 instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int lab_6_lin_solver_b_4_read(lab_6_lin_solver *InstancePtr);
/**
* Write to b_2 gateway of lab_6_lin_solver. Assignments are LSB-justified.
*
* @param	InstancePtr is the b_2 instance to operate on.
* @param	Data is value to be written to gateway b_2.
*
* @return	None.
*
* @note    .
*
*/
void lab_6_lin_solver_b_2_write(lab_6_lin_solver *InstancePtr, int Data);
/**
* Read from b_2 gateway of lab_6_lin_solver. Assignments are LSB-justified.
*
* @param	InstancePtr is the b_2 instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int lab_6_lin_solver_b_2_read(lab_6_lin_solver *InstancePtr);
/**
* Write to b_1 gateway of lab_6_lin_solver. Assignments are LSB-justified.
*
* @param	InstancePtr is the b_1 instance to operate on.
* @param	Data is value to be written to gateway b_1.
*
* @return	None.
*
* @note    .
*
*/
void lab_6_lin_solver_b_1_write(lab_6_lin_solver *InstancePtr, int Data);
/**
* Read from b_1 gateway of lab_6_lin_solver. Assignments are LSB-justified.
*
* @param	InstancePtr is the b_1 instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int lab_6_lin_solver_b_1_read(lab_6_lin_solver *InstancePtr);
/**
* Write to b_3 gateway of lab_6_lin_solver. Assignments are LSB-justified.
*
* @param	InstancePtr is the b_3 instance to operate on.
* @param	Data is value to be written to gateway b_3.
*
* @return	None.
*
* @note    .
*
*/
void lab_6_lin_solver_b_3_write(lab_6_lin_solver *InstancePtr, int Data);
/**
* Read from b_3 gateway of lab_6_lin_solver. Assignments are LSB-justified.
*
* @param	InstancePtr is the b_3 instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int lab_6_lin_solver_b_3_read(lab_6_lin_solver *InstancePtr);
/**
* Write to in_8 gateway of lab_6_lin_solver. Assignments are LSB-justified.
*
* @param	InstancePtr is the in_8 instance to operate on.
* @param	Data is value to be written to gateway in_8.
*
* @return	None.
*
* @note    .
*
*/
void lab_6_lin_solver_in_8_write(lab_6_lin_solver *InstancePtr, int Data);
/**
* Read from in_8 gateway of lab_6_lin_solver. Assignments are LSB-justified.
*
* @param	InstancePtr is the in_8 instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int lab_6_lin_solver_in_8_read(lab_6_lin_solver *InstancePtr);
/**
* Write to in_7 gateway of lab_6_lin_solver. Assignments are LSB-justified.
*
* @param	InstancePtr is the in_7 instance to operate on.
* @param	Data is value to be written to gateway in_7.
*
* @return	None.
*
* @note    .
*
*/
void lab_6_lin_solver_in_7_write(lab_6_lin_solver *InstancePtr, int Data);
/**
* Read from in_7 gateway of lab_6_lin_solver. Assignments are LSB-justified.
*
* @param	InstancePtr is the in_7 instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int lab_6_lin_solver_in_7_read(lab_6_lin_solver *InstancePtr);
/**
* Write to in_6 gateway of lab_6_lin_solver. Assignments are LSB-justified.
*
* @param	InstancePtr is the in_6 instance to operate on.
* @param	Data is value to be written to gateway in_6.
*
* @return	None.
*
* @note    .
*
*/
void lab_6_lin_solver_in_6_write(lab_6_lin_solver *InstancePtr, int Data);
/**
* Read from in_6 gateway of lab_6_lin_solver. Assignments are LSB-justified.
*
* @param	InstancePtr is the in_6 instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int lab_6_lin_solver_in_6_read(lab_6_lin_solver *InstancePtr);
/**
* Write to in_5 gateway of lab_6_lin_solver. Assignments are LSB-justified.
*
* @param	InstancePtr is the in_5 instance to operate on.
* @param	Data is value to be written to gateway in_5.
*
* @return	None.
*
* @note    .
*
*/
void lab_6_lin_solver_in_5_write(lab_6_lin_solver *InstancePtr, int Data);
/**
* Read from in_5 gateway of lab_6_lin_solver. Assignments are LSB-justified.
*
* @param	InstancePtr is the in_5 instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int lab_6_lin_solver_in_5_read(lab_6_lin_solver *InstancePtr);
/**
* Write to in_43 gateway of lab_6_lin_solver. Assignments are LSB-justified.
*
* @param	InstancePtr is the in_43 instance to operate on.
* @param	Data is value to be written to gateway in_43.
*
* @return	None.
*
* @note    .
*
*/
void lab_6_lin_solver_in_43_write(lab_6_lin_solver *InstancePtr, int Data);
/**
* Read from in_43 gateway of lab_6_lin_solver. Assignments are LSB-justified.
*
* @param	InstancePtr is the in_43 instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int lab_6_lin_solver_in_43_read(lab_6_lin_solver *InstancePtr);
/**
* Write to in_42 gateway of lab_6_lin_solver. Assignments are LSB-justified.
*
* @param	InstancePtr is the in_42 instance to operate on.
* @param	Data is value to be written to gateway in_42.
*
* @return	None.
*
* @note    .
*
*/
void lab_6_lin_solver_in_42_write(lab_6_lin_solver *InstancePtr, int Data);
/**
* Read from in_42 gateway of lab_6_lin_solver. Assignments are LSB-justified.
*
* @param	InstancePtr is the in_42 instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int lab_6_lin_solver_in_42_read(lab_6_lin_solver *InstancePtr);
/**
* Write to in_41 gateway of lab_6_lin_solver. Assignments are LSB-justified.
*
* @param	InstancePtr is the in_41 instance to operate on.
* @param	Data is value to be written to gateway in_41.
*
* @return	None.
*
* @note    .
*
*/
void lab_6_lin_solver_in_41_write(lab_6_lin_solver *InstancePtr, int Data);
/**
* Read from in_41 gateway of lab_6_lin_solver. Assignments are LSB-justified.
*
* @param	InstancePtr is the in_41 instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int lab_6_lin_solver_in_41_read(lab_6_lin_solver *InstancePtr);
/**
* Write to in_33 gateway of lab_6_lin_solver. Assignments are LSB-justified.
*
* @param	InstancePtr is the in_33 instance to operate on.
* @param	Data is value to be written to gateway in_33.
*
* @return	None.
*
* @note    .
*
*/
void lab_6_lin_solver_in_33_write(lab_6_lin_solver *InstancePtr, int Data);
/**
* Read from in_33 gateway of lab_6_lin_solver. Assignments are LSB-justified.
*
* @param	InstancePtr is the in_33 instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int lab_6_lin_solver_in_33_read(lab_6_lin_solver *InstancePtr);
/**
* Write to in_32 gateway of lab_6_lin_solver. Assignments are LSB-justified.
*
* @param	InstancePtr is the in_32 instance to operate on.
* @param	Data is value to be written to gateway in_32.
*
* @return	None.
*
* @note    .
*
*/
void lab_6_lin_solver_in_32_write(lab_6_lin_solver *InstancePtr, int Data);
/**
* Read from in_32 gateway of lab_6_lin_solver. Assignments are LSB-justified.
*
* @param	InstancePtr is the in_32 instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int lab_6_lin_solver_in_32_read(lab_6_lin_solver *InstancePtr);
/**
* Write to in_31 gateway of lab_6_lin_solver. Assignments are LSB-justified.
*
* @param	InstancePtr is the in_31 instance to operate on.
* @param	Data is value to be written to gateway in_31.
*
* @return	None.
*
* @note    .
*
*/
void lab_6_lin_solver_in_31_write(lab_6_lin_solver *InstancePtr, int Data);
/**
* Read from in_31 gateway of lab_6_lin_solver. Assignments are LSB-justified.
*
* @param	InstancePtr is the in_31 instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int lab_6_lin_solver_in_31_read(lab_6_lin_solver *InstancePtr);
/**
* Write to in_23 gateway of lab_6_lin_solver. Assignments are LSB-justified.
*
* @param	InstancePtr is the in_23 instance to operate on.
* @param	Data is value to be written to gateway in_23.
*
* @return	None.
*
* @note    .
*
*/
void lab_6_lin_solver_in_23_write(lab_6_lin_solver *InstancePtr, int Data);
/**
* Read from in_23 gateway of lab_6_lin_solver. Assignments are LSB-justified.
*
* @param	InstancePtr is the in_23 instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int lab_6_lin_solver_in_23_read(lab_6_lin_solver *InstancePtr);
/**
* Write to in_22 gateway of lab_6_lin_solver. Assignments are LSB-justified.
*
* @param	InstancePtr is the in_22 instance to operate on.
* @param	Data is value to be written to gateway in_22.
*
* @return	None.
*
* @note    .
*
*/
void lab_6_lin_solver_in_22_write(lab_6_lin_solver *InstancePtr, int Data);
/**
* Read from in_22 gateway of lab_6_lin_solver. Assignments are LSB-justified.
*
* @param	InstancePtr is the in_22 instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int lab_6_lin_solver_in_22_read(lab_6_lin_solver *InstancePtr);
/**
* Write to in_21 gateway of lab_6_lin_solver. Assignments are LSB-justified.
*
* @param	InstancePtr is the in_21 instance to operate on.
* @param	Data is value to be written to gateway in_21.
*
* @return	None.
*
* @note    .
*
*/
void lab_6_lin_solver_in_21_write(lab_6_lin_solver *InstancePtr, int Data);
/**
* Read from in_21 gateway of lab_6_lin_solver. Assignments are LSB-justified.
*
* @param	InstancePtr is the in_21 instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int lab_6_lin_solver_in_21_read(lab_6_lin_solver *InstancePtr);
/**
* Write to in_13 gateway of lab_6_lin_solver. Assignments are LSB-justified.
*
* @param	InstancePtr is the in_13 instance to operate on.
* @param	Data is value to be written to gateway in_13.
*
* @return	None.
*
* @note    .
*
*/
void lab_6_lin_solver_in_13_write(lab_6_lin_solver *InstancePtr, int Data);
/**
* Read from in_13 gateway of lab_6_lin_solver. Assignments are LSB-justified.
*
* @param	InstancePtr is the in_13 instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int lab_6_lin_solver_in_13_read(lab_6_lin_solver *InstancePtr);
/**
* Write to in_12 gateway of lab_6_lin_solver. Assignments are LSB-justified.
*
* @param	InstancePtr is the in_12 instance to operate on.
* @param	Data is value to be written to gateway in_12.
*
* @return	None.
*
* @note    .
*
*/
void lab_6_lin_solver_in_12_write(lab_6_lin_solver *InstancePtr, int Data);
/**
* Read from in_12 gateway of lab_6_lin_solver. Assignments are LSB-justified.
*
* @param	InstancePtr is the in_12 instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int lab_6_lin_solver_in_12_read(lab_6_lin_solver *InstancePtr);
/**
* Write to in_11 gateway of lab_6_lin_solver. Assignments are LSB-justified.
*
* @param	InstancePtr is the in_11 instance to operate on.
* @param	Data is value to be written to gateway in_11.
*
* @return	None.
*
* @note    .
*
*/
void lab_6_lin_solver_in_11_write(lab_6_lin_solver *InstancePtr, int Data);
/**
* Read from in_11 gateway of lab_6_lin_solver. Assignments are LSB-justified.
*
* @param	InstancePtr is the in_11 instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int lab_6_lin_solver_in_11_read(lab_6_lin_solver *InstancePtr);
/**
* Write to start_new gateway of lab_6_lin_solver. Assignments are LSB-justified.
*
* @param	InstancePtr is the start_new instance to operate on.
* @param	Data is value to be written to gateway start_new.
*
* @return	None.
*
* @note    .
*
*/
void lab_6_lin_solver_start_new_write(lab_6_lin_solver *InstancePtr, u32 Data);
/**
* Read from start_new gateway of lab_6_lin_solver. Assignments are LSB-justified.
*
* @param	InstancePtr is the start_new instance to operate on.
*
* @return	u32
*
* @note    .
*
*/
u32 lab_6_lin_solver_start_new_read(lab_6_lin_solver *InstancePtr);
/**
* Write to ap_rst gateway of lab_6_lin_solver. Assignments are LSB-justified.
*
* @param	InstancePtr is the ap_rst instance to operate on.
* @param	Data is value to be written to gateway ap_rst.
*
* @return	None.
*
* @note    .
*
*/
void lab_6_lin_solver_ap_rst_write(lab_6_lin_solver *InstancePtr, u32 Data);
/**
* Read from ap_rst gateway of lab_6_lin_solver. Assignments are LSB-justified.
*
* @param	InstancePtr is the ap_rst instance to operate on.
*
* @return	u32
*
* @note    .
*
*/
u32 lab_6_lin_solver_ap_rst_read(lab_6_lin_solver *InstancePtr);
/**
* Read from done_out gateway of lab_6_lin_solver. Assignments are LSB-justified.
*
* @param	InstancePtr is the done_out instance to operate on.
*
* @return	u32
*
* @note    .
*
*/
u32 lab_6_lin_solver_done_out_read(lab_6_lin_solver *InstancePtr);
/**
* Read from c_1 gateway of lab_6_lin_solver. Assignments are LSB-justified.
*
* @param	InstancePtr is the c_1 instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int lab_6_lin_solver_c_1_read(lab_6_lin_solver *InstancePtr);
/**
* Read from c_2 gateway of lab_6_lin_solver. Assignments are LSB-justified.
*
* @param	InstancePtr is the c_2 instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int lab_6_lin_solver_c_2_read(lab_6_lin_solver *InstancePtr);
/**
* Read from c_3 gateway of lab_6_lin_solver. Assignments are LSB-justified.
*
* @param	InstancePtr is the c_3 instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int lab_6_lin_solver_c_3_read(lab_6_lin_solver *InstancePtr);
/**
* Read from c_4 gateway of lab_6_lin_solver. Assignments are LSB-justified.
*
* @param	InstancePtr is the c_4 instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int lab_6_lin_solver_c_4_read(lab_6_lin_solver *InstancePtr);
/**
* Read from r_11 gateway of lab_6_lin_solver. Assignments are LSB-justified.
*
* @param	InstancePtr is the r_11 instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int lab_6_lin_solver_r_11_read(lab_6_lin_solver *InstancePtr);
/**
* Read from r_12 gateway of lab_6_lin_solver. Assignments are LSB-justified.
*
* @param	InstancePtr is the r_12 instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int lab_6_lin_solver_r_12_read(lab_6_lin_solver *InstancePtr);
/**
* Read from r_13 gateway of lab_6_lin_solver. Assignments are LSB-justified.
*
* @param	InstancePtr is the r_13 instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int lab_6_lin_solver_r_13_read(lab_6_lin_solver *InstancePtr);
/**
* Read from r_14 gateway of lab_6_lin_solver. Assignments are LSB-justified.
*
* @param	InstancePtr is the r_14 instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int lab_6_lin_solver_r_14_read(lab_6_lin_solver *InstancePtr);
/**
* Read from r_22 gateway of lab_6_lin_solver. Assignments are LSB-justified.
*
* @param	InstancePtr is the r_22 instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int lab_6_lin_solver_r_22_read(lab_6_lin_solver *InstancePtr);
/**
* Read from r_23 gateway of lab_6_lin_solver. Assignments are LSB-justified.
*
* @param	InstancePtr is the r_23 instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int lab_6_lin_solver_r_23_read(lab_6_lin_solver *InstancePtr);
/**
* Read from r_24 gateway of lab_6_lin_solver. Assignments are LSB-justified.
*
* @param	InstancePtr is the r_24 instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int lab_6_lin_solver_r_24_read(lab_6_lin_solver *InstancePtr);
/**
* Read from r_33 gateway of lab_6_lin_solver. Assignments are LSB-justified.
*
* @param	InstancePtr is the r_33 instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int lab_6_lin_solver_r_33_read(lab_6_lin_solver *InstancePtr);
/**
* Read from r_34 gateway of lab_6_lin_solver. Assignments are LSB-justified.
*
* @param	InstancePtr is the r_34 instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int lab_6_lin_solver_r_34_read(lab_6_lin_solver *InstancePtr);
/**
* Read from r_44 gateway of lab_6_lin_solver. Assignments are LSB-justified.
*
* @param	InstancePtr is the r_44 instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int lab_6_lin_solver_r_44_read(lab_6_lin_solver *InstancePtr);
#ifdef __cplusplus
}
#endif
#endif
