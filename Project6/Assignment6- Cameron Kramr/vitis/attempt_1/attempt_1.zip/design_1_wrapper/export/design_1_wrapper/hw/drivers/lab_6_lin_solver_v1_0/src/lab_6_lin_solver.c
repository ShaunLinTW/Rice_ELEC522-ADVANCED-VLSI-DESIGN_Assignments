#include "lab_6_lin_solver.h"
#ifndef __linux__
int lab_6_lin_solver_CfgInitialize(lab_6_lin_solver *InstancePtr, lab_6_lin_solver_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->lab_6_lin_solver_array_input_BaseAddress = ConfigPtr->lab_6_lin_solver_array_input_BaseAddress;
    InstancePtr->lab_6_lin_solver_control_BaseAddress = ConfigPtr->lab_6_lin_solver_control_BaseAddress;
    InstancePtr->lab_6_lin_solver_output_BaseAddress = ConfigPtr->lab_6_lin_solver_output_BaseAddress;

    InstancePtr->IsReady = 1;
    return XST_SUCCESS;
}
#endif
void lab_6_lin_solver_b_4_write(lab_6_lin_solver *InstancePtr, int Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    lab_6_lin_solver_WriteReg(InstancePtr->lab_6_lin_solver_array_input_BaseAddress, 0, Data);
}
int lab_6_lin_solver_b_4_read(lab_6_lin_solver *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = lab_6_lin_solver_ReadReg(InstancePtr->lab_6_lin_solver_array_input_BaseAddress, 0);
    return Data;
}
void lab_6_lin_solver_b_2_write(lab_6_lin_solver *InstancePtr, int Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    lab_6_lin_solver_WriteReg(InstancePtr->lab_6_lin_solver_array_input_BaseAddress, 4, Data);
}
int lab_6_lin_solver_b_2_read(lab_6_lin_solver *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = lab_6_lin_solver_ReadReg(InstancePtr->lab_6_lin_solver_array_input_BaseAddress, 4);
    return Data;
}
void lab_6_lin_solver_b_1_write(lab_6_lin_solver *InstancePtr, int Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    lab_6_lin_solver_WriteReg(InstancePtr->lab_6_lin_solver_array_input_BaseAddress, 8, Data);
}
int lab_6_lin_solver_b_1_read(lab_6_lin_solver *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = lab_6_lin_solver_ReadReg(InstancePtr->lab_6_lin_solver_array_input_BaseAddress, 8);
    return Data;
}
void lab_6_lin_solver_b_3_write(lab_6_lin_solver *InstancePtr, int Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    lab_6_lin_solver_WriteReg(InstancePtr->lab_6_lin_solver_array_input_BaseAddress, 12, Data);
}
int lab_6_lin_solver_b_3_read(lab_6_lin_solver *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = lab_6_lin_solver_ReadReg(InstancePtr->lab_6_lin_solver_array_input_BaseAddress, 12);
    return Data;
}
void lab_6_lin_solver_in_8_write(lab_6_lin_solver *InstancePtr, int Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    lab_6_lin_solver_WriteReg(InstancePtr->lab_6_lin_solver_array_input_BaseAddress, 16, Data);
}
int lab_6_lin_solver_in_8_read(lab_6_lin_solver *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = lab_6_lin_solver_ReadReg(InstancePtr->lab_6_lin_solver_array_input_BaseAddress, 16);
    return Data;
}
void lab_6_lin_solver_in_7_write(lab_6_lin_solver *InstancePtr, int Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    lab_6_lin_solver_WriteReg(InstancePtr->lab_6_lin_solver_array_input_BaseAddress, 20, Data);
}
int lab_6_lin_solver_in_7_read(lab_6_lin_solver *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = lab_6_lin_solver_ReadReg(InstancePtr->lab_6_lin_solver_array_input_BaseAddress, 20);
    return Data;
}
void lab_6_lin_solver_in_6_write(lab_6_lin_solver *InstancePtr, int Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    lab_6_lin_solver_WriteReg(InstancePtr->lab_6_lin_solver_array_input_BaseAddress, 24, Data);
}
int lab_6_lin_solver_in_6_read(lab_6_lin_solver *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = lab_6_lin_solver_ReadReg(InstancePtr->lab_6_lin_solver_array_input_BaseAddress, 24);
    return Data;
}
void lab_6_lin_solver_in_5_write(lab_6_lin_solver *InstancePtr, int Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    lab_6_lin_solver_WriteReg(InstancePtr->lab_6_lin_solver_array_input_BaseAddress, 28, Data);
}
int lab_6_lin_solver_in_5_read(lab_6_lin_solver *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = lab_6_lin_solver_ReadReg(InstancePtr->lab_6_lin_solver_array_input_BaseAddress, 28);
    return Data;
}
void lab_6_lin_solver_in_43_write(lab_6_lin_solver *InstancePtr, int Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    lab_6_lin_solver_WriteReg(InstancePtr->lab_6_lin_solver_array_input_BaseAddress, 32, Data);
}
int lab_6_lin_solver_in_43_read(lab_6_lin_solver *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = lab_6_lin_solver_ReadReg(InstancePtr->lab_6_lin_solver_array_input_BaseAddress, 32);
    return Data;
}
void lab_6_lin_solver_in_42_write(lab_6_lin_solver *InstancePtr, int Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    lab_6_lin_solver_WriteReg(InstancePtr->lab_6_lin_solver_array_input_BaseAddress, 36, Data);
}
int lab_6_lin_solver_in_42_read(lab_6_lin_solver *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = lab_6_lin_solver_ReadReg(InstancePtr->lab_6_lin_solver_array_input_BaseAddress, 36);
    return Data;
}
void lab_6_lin_solver_in_41_write(lab_6_lin_solver *InstancePtr, int Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    lab_6_lin_solver_WriteReg(InstancePtr->lab_6_lin_solver_array_input_BaseAddress, 40, Data);
}
int lab_6_lin_solver_in_41_read(lab_6_lin_solver *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = lab_6_lin_solver_ReadReg(InstancePtr->lab_6_lin_solver_array_input_BaseAddress, 40);
    return Data;
}
void lab_6_lin_solver_in_33_write(lab_6_lin_solver *InstancePtr, int Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    lab_6_lin_solver_WriteReg(InstancePtr->lab_6_lin_solver_array_input_BaseAddress, 44, Data);
}
int lab_6_lin_solver_in_33_read(lab_6_lin_solver *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = lab_6_lin_solver_ReadReg(InstancePtr->lab_6_lin_solver_array_input_BaseAddress, 44);
    return Data;
}
void lab_6_lin_solver_in_32_write(lab_6_lin_solver *InstancePtr, int Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    lab_6_lin_solver_WriteReg(InstancePtr->lab_6_lin_solver_array_input_BaseAddress, 48, Data);
}
int lab_6_lin_solver_in_32_read(lab_6_lin_solver *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = lab_6_lin_solver_ReadReg(InstancePtr->lab_6_lin_solver_array_input_BaseAddress, 48);
    return Data;
}
void lab_6_lin_solver_in_31_write(lab_6_lin_solver *InstancePtr, int Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    lab_6_lin_solver_WriteReg(InstancePtr->lab_6_lin_solver_array_input_BaseAddress, 52, Data);
}
int lab_6_lin_solver_in_31_read(lab_6_lin_solver *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = lab_6_lin_solver_ReadReg(InstancePtr->lab_6_lin_solver_array_input_BaseAddress, 52);
    return Data;
}
void lab_6_lin_solver_in_23_write(lab_6_lin_solver *InstancePtr, int Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    lab_6_lin_solver_WriteReg(InstancePtr->lab_6_lin_solver_array_input_BaseAddress, 56, Data);
}
int lab_6_lin_solver_in_23_read(lab_6_lin_solver *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = lab_6_lin_solver_ReadReg(InstancePtr->lab_6_lin_solver_array_input_BaseAddress, 56);
    return Data;
}
void lab_6_lin_solver_in_22_write(lab_6_lin_solver *InstancePtr, int Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    lab_6_lin_solver_WriteReg(InstancePtr->lab_6_lin_solver_array_input_BaseAddress, 60, Data);
}
int lab_6_lin_solver_in_22_read(lab_6_lin_solver *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = lab_6_lin_solver_ReadReg(InstancePtr->lab_6_lin_solver_array_input_BaseAddress, 60);
    return Data;
}
void lab_6_lin_solver_in_21_write(lab_6_lin_solver *InstancePtr, int Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    lab_6_lin_solver_WriteReg(InstancePtr->lab_6_lin_solver_array_input_BaseAddress, 64, Data);
}
int lab_6_lin_solver_in_21_read(lab_6_lin_solver *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = lab_6_lin_solver_ReadReg(InstancePtr->lab_6_lin_solver_array_input_BaseAddress, 64);
    return Data;
}
void lab_6_lin_solver_in_13_write(lab_6_lin_solver *InstancePtr, int Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    lab_6_lin_solver_WriteReg(InstancePtr->lab_6_lin_solver_array_input_BaseAddress, 68, Data);
}
int lab_6_lin_solver_in_13_read(lab_6_lin_solver *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = lab_6_lin_solver_ReadReg(InstancePtr->lab_6_lin_solver_array_input_BaseAddress, 68);
    return Data;
}
void lab_6_lin_solver_in_12_write(lab_6_lin_solver *InstancePtr, int Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    lab_6_lin_solver_WriteReg(InstancePtr->lab_6_lin_solver_array_input_BaseAddress, 72, Data);
}
int lab_6_lin_solver_in_12_read(lab_6_lin_solver *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = lab_6_lin_solver_ReadReg(InstancePtr->lab_6_lin_solver_array_input_BaseAddress, 72);
    return Data;
}
void lab_6_lin_solver_in_11_write(lab_6_lin_solver *InstancePtr, int Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    lab_6_lin_solver_WriteReg(InstancePtr->lab_6_lin_solver_array_input_BaseAddress, 76, Data);
}
int lab_6_lin_solver_in_11_read(lab_6_lin_solver *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = lab_6_lin_solver_ReadReg(InstancePtr->lab_6_lin_solver_array_input_BaseAddress, 76);
    return Data;
}
void lab_6_lin_solver_start_new_write(lab_6_lin_solver *InstancePtr, u32 Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    lab_6_lin_solver_WriteReg(InstancePtr->lab_6_lin_solver_control_BaseAddress, 0, Data);
}
u32 lab_6_lin_solver_start_new_read(lab_6_lin_solver *InstancePtr) {

    u32 Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = lab_6_lin_solver_ReadReg(InstancePtr->lab_6_lin_solver_control_BaseAddress, 0);
    return Data;
}
void lab_6_lin_solver_ap_rst_write(lab_6_lin_solver *InstancePtr, u32 Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    lab_6_lin_solver_WriteReg(InstancePtr->lab_6_lin_solver_control_BaseAddress, 4, Data);
}
u32 lab_6_lin_solver_ap_rst_read(lab_6_lin_solver *InstancePtr) {

    u32 Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = lab_6_lin_solver_ReadReg(InstancePtr->lab_6_lin_solver_control_BaseAddress, 4);
    return Data;
}
u32 lab_6_lin_solver_done_out_read(lab_6_lin_solver *InstancePtr) {

    u32 Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = lab_6_lin_solver_ReadReg(InstancePtr->lab_6_lin_solver_control_BaseAddress, 8);
    return Data;
}
int lab_6_lin_solver_c_1_read(lab_6_lin_solver *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = lab_6_lin_solver_ReadReg(InstancePtr->lab_6_lin_solver_output_BaseAddress, 0);
    return Data;
}
int lab_6_lin_solver_c_2_read(lab_6_lin_solver *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = lab_6_lin_solver_ReadReg(InstancePtr->lab_6_lin_solver_output_BaseAddress, 4);
    return Data;
}
int lab_6_lin_solver_c_3_read(lab_6_lin_solver *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = lab_6_lin_solver_ReadReg(InstancePtr->lab_6_lin_solver_output_BaseAddress, 8);
    return Data;
}
int lab_6_lin_solver_c_4_read(lab_6_lin_solver *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = lab_6_lin_solver_ReadReg(InstancePtr->lab_6_lin_solver_output_BaseAddress, 12);
    return Data;
}
int lab_6_lin_solver_r_11_read(lab_6_lin_solver *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = lab_6_lin_solver_ReadReg(InstancePtr->lab_6_lin_solver_output_BaseAddress, 16);
    return Data;
}
int lab_6_lin_solver_r_12_read(lab_6_lin_solver *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = lab_6_lin_solver_ReadReg(InstancePtr->lab_6_lin_solver_output_BaseAddress, 20);
    return Data;
}
int lab_6_lin_solver_r_13_read(lab_6_lin_solver *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = lab_6_lin_solver_ReadReg(InstancePtr->lab_6_lin_solver_output_BaseAddress, 24);
    return Data;
}
int lab_6_lin_solver_r_14_read(lab_6_lin_solver *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = lab_6_lin_solver_ReadReg(InstancePtr->lab_6_lin_solver_output_BaseAddress, 28);
    return Data;
}
int lab_6_lin_solver_r_22_read(lab_6_lin_solver *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = lab_6_lin_solver_ReadReg(InstancePtr->lab_6_lin_solver_output_BaseAddress, 32);
    return Data;
}
int lab_6_lin_solver_r_23_read(lab_6_lin_solver *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = lab_6_lin_solver_ReadReg(InstancePtr->lab_6_lin_solver_output_BaseAddress, 36);
    return Data;
}
int lab_6_lin_solver_r_24_read(lab_6_lin_solver *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = lab_6_lin_solver_ReadReg(InstancePtr->lab_6_lin_solver_output_BaseAddress, 40);
    return Data;
}
int lab_6_lin_solver_r_33_read(lab_6_lin_solver *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = lab_6_lin_solver_ReadReg(InstancePtr->lab_6_lin_solver_output_BaseAddress, 44);
    return Data;
}
int lab_6_lin_solver_r_34_read(lab_6_lin_solver *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = lab_6_lin_solver_ReadReg(InstancePtr->lab_6_lin_solver_output_BaseAddress, 48);
    return Data;
}
int lab_6_lin_solver_r_44_read(lab_6_lin_solver *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = lab_6_lin_solver_ReadReg(InstancePtr->lab_6_lin_solver_output_BaseAddress, 52);
    return Data;
}
