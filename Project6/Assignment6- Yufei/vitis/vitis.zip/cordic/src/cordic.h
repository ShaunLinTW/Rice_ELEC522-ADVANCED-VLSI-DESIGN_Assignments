//*****************************************************************************
//
//*****************************************************************************
//Device: All
//Design Name: cordic
//Purpose:
//    This is the header for the treeadd.cpp design.
//Reference:
//Revision History:
//*****************************************************************************

#ifndef __CORDIC_H__
#define __CORDIC_H__

#include <cmath>
#include "ap_fixed.h"
using namespace std;

// Uncomment this line to compare TB vs HW C-model and/or RTL
// #define HW_COSIM

// Prototype of top level function for C-synthesis
// Variable a through h are inputs. In C language format, a pointer to
// variable r is passed in so that r can be written in this function.

#define NUM_DEGREE 360

#endif // __CORDIC_H__ not defined
