// standard .h for c++ math and I/O
#include <cmath>
#include <iostream>

// .h file based on your original .hls design input
#include "cordic.h"
#include "xcordic.h"
#include "ap_fixed.h"

// IMPORTANT HLS Cordic HW instance - Needed pointer - see the cordic.h file
XCordic Cordic;

// The Board Support Package that Vitis builds when you start a project should have these files
#include "xparameters.h"
// The Xilinx time function file for measuring ARM core cycles
#include "xtime_l.h"
// Xilinx function for interrupt controller - may not be used in polling example.
#include "xscugic.h"

// Used by C++ for the print command cout
using namespace std;

// Define our fixed point type used here to match the PL accelerator
typedef ap_fixed<16,4, AP_RND, AP_SAT> FIXED_TYPE;

// The AXI interface sends only "raw bits" so we need to convert standard data types we use to
// match the ap_fixed data type in the PL accelerator.
// Using C++ functions per - RJ Cunningham
int get_int_reinterpret(FIXED_TYPE x) {
	return *(reinterpret_cast<short *>(&x));
}

FIXED_TYPE get_fixed_reinterpret(int x) {
	return *(reinterpret_cast<FIXED_TYPE *>(&x));
}


// actual MAIN control program running on ARM processor PS
int main()
{
	cout << "--- Start of the Program ---" << endl;

	// values for simulation and testing using C++ format with ap_fixed

	FIXED_TYPE theta_in;
	FIXED_TYPE x_in;
	FIXED_TYPE y_in;
	bool	   mode;
	FIXED_TYPE out_x;
	FIXED_TYPE out_y;

	// values for sending over AXI bus to programmable logic (PL)
	unsigned int theta_in_u32, x_in_u32, y_in_u32, mode_u32, out_x_u32, out_y_u32;

	// Variables for timing and counts used for application cycle counts and timing
	unsigned long long tt = 0;
	double tt_print;
	double tt_seconds, pl_time, ps_time, speedup;
	XTime start_time_co;
	XTime stop_time_co;

	// Perform the cosine&sine mode
	printf("******************************************************************************************************************\n");
	printf("perform the cosine&sine mode\n");
	printf("******************************************************************************************************************\n");

	for(int i = 0; i < NUM_DEGREE ;i++)
	{
		theta_in = i*M_PI/180;
		x_in 	= 1.0;
		y_in 	= 0.0;
		mode 	= 0;
		out_x 	= 0.0;
		out_y 	= 0.0;

		// Need to reinterpret the 16 bit ap_fixed values into raw unsigned 32 bit value for AXI transfer
		theta_in_u32 	= get_int_reinterpret(theta_in);
		x_in_u32 		= get_int_reinterpret(x_in);
		y_in_u32 		= get_int_reinterpret(y_in);
		mode_u32 		= mode;
		out_x_u32 		= get_int_reinterpret(out_x);
		out_y_u32 		= get_int_reinterpret(out_y);

		// Get the starting time in cycle counts
		XTime_GetTime(&start_time_co);

		// IMPORTANT PART OF PS-PL AXI COMMUNICATION
		// Need to initialize the PL accelerator. Use the pointer to the device instance, here &Cordic
		XCordic_Initialize(&Cordic, 0);

		// Real processing on PL accelerator starts here
		// Write all unsigned raw 32 bit values to PL accelerator, since a_u32 = a_int;
		XCordic_Set_theta_in(&Cordic, theta_in_u32);
		XCordic_Set_x_in(&Cordic, x_in_u32);
		XCordic_Set_y_in(&Cordic, y_in_u32);
		XCordic_Set_mode(&Cordic, mode_u32);

		// Trigger the accelerator to start
		XCordic_Start(&Cordic);

		// Polling loop to wait for PL to complete.
		// Note that r_out_u32 is the special ap_fixed raw data bits.
		// Note that done_out is a standard 32 bit integer and does not need reinterpretation.
		do {
		 out_x_u32 = XCordic_Get_out_x(&Cordic);
		 out_y_u32 = XCordic_Get_out_y(&Cordic);
		} while (!XCordic_IsReady(&Cordic));

		// Capture the stop time on the processor
		XTime_GetTime(&stop_time_co);
		tt += stop_time_co - start_time_co;

		// Convert unsigned 32 bit value from programmable logic back to fixed point
		out_x = get_fixed_reinterpret(out_x_u32);
		out_y = get_fixed_reinterpret(out_y_u32);
		// Print the results
		printf("input:[degree=%2.1f\tradian=%f\tinput_x=%f\tinput_y=%f]\toutput:[XcosT-YsinT=%f\tYcosT+XsinT=%f]\n",
			  (double)i,  (double)theta_in, (double)x_in, (double)y_in, (double)out_x, (double)out_y);
	}

	// Perform the  arctan&radius mode
	printf("******************************************************************************************************************\n");
	printf("perform the  arctan&radius mode\n");
	printf("******************************************************************************************************************\n");

	for(int i = 0; i < NUM_DEGREE ;i++)
	{
		theta_in = i*M_PI/180;
		x_in 	= cos((double)theta_in);
		y_in 	= sin((double)theta_in);
		mode 	= 1;
		out_x 	= 0.0;
		out_y 	= 0.0;

		// Need to reinterpret the 16 bit ap_fixed values into raw unsigned 32 bit value for AXI transfer
		theta_in_u32 	= get_int_reinterpret(theta_in);
		x_in_u32 		= get_int_reinterpret(x_in);
		y_in_u32 		= get_int_reinterpret(y_in);
		mode_u32 		= mode;
		out_x_u32 		= get_int_reinterpret(out_x);
		out_y_u32 		= get_int_reinterpret(out_y);

		// Get the starting time in cycle counts
		XTime_GetTime(&start_time_co);

		// IMPORTANT PART OF PS-PL AXI COMMUNICATION
		// Need to initialize the PL accelerator. Use the pointer to the device instance, here &Cordic
		XCordic_Initialize(&Cordic, 0);

		// Real processing on PL accelerator starts here
		// Write all unsigned raw 32 bit values to PL accelerator, since a_u32 = a_int;
		XCordic_Set_theta_in(&Cordic, theta_in_u32);
		XCordic_Set_x_in(&Cordic, x_in_u32);
		XCordic_Set_y_in(&Cordic, y_in_u32);
		XCordic_Set_mode(&Cordic, mode_u32);

		// Trigger the accelerator to start
		XCordic_Start(&Cordic);

		// Polling loop to wait for PL to complete.
		// Note that r_out_u32 is the special ap_fixed raw data bits.
		// Note that done_out is a standard 32 bit integer and does not need reinterpretation.
		do {
		 out_x_u32 = XCordic_Get_out_x(&Cordic);
		 out_y_u32 = XCordic_Get_out_y(&Cordic);
		} while (!XCordic_IsReady(&Cordic));

		// Capture the stop time on the processor
		XTime_GetTime(&stop_time_co);
		tt += stop_time_co - start_time_co;

		// Convert unsigned 32 bit value from programmable logic back to fixed point
		out_x = get_fixed_reinterpret(out_x_u32);
		out_y = get_fixed_reinterpret(out_y_u32);
		// Print the results
		printf("input:[degree=%2.1f\tradian=%f\tinput_x=%f\tinput_y=%f]\toutput:[raduis=%f\ttheta=%f]\n",
			  (double)i,  (double)theta_in, (double)x_in, (double)y_in, (double)out_x, (double)out_y);
	}

	// Compute timing on PL hardware using the accelerator.
	tt_print = (double)tt/(NUM_DEGREE*2);
	cout << "Done, Total time steps for I/O writes and I/O reads for PL = " << tt_print << endl;
	tt_seconds = COUNTS_PER_SECOND;
	cout << "Cycle counts per second for ARM A9 core for PL add = " << tt_seconds << endl;
	pl_time = (float) tt_print / tt_seconds;
	cout << "Time in seconds for PL hardware add = times steps / COUNTS_PER_SECOND = " << pl_time << endl;

	// ARM SOFTWARE ONLY PORTION OF PROGRAM
	// Generate the expected result on the ARM core using the built-in function
	volatile double val_theta, val_sine, val_cosine, val_modulo, val_actan_theta;
	double val_x = 1.0;
	double val_y = 0.0;
	tt = 0;
	// calculate the sine and cosine
    for(int i = 0; i < NUM_DEGREE ;i++)
    {
    	val_theta 	= i*M_PI/180;
    	XTime_GetTime(&start_time_co);
    	val_cosine 	= cos((double)val_theta)*val_x - sin((double)val_theta)*val_y;
		val_sine 	= cos((double)val_theta)*val_y + sin((double)val_theta)*val_x;
		XTime_GetTime(&stop_time_co);
		tt += stop_time_co - start_time_co;
    }
    // calculate the arctan and moludo
    for(int i = 0; i < NUM_DEGREE ;i++)
	{
    	val_theta 	= i*M_PI/180;
    	val_x 	= cos((double)val_theta);
    	val_y 	= sin((double)val_theta);
		XTime_GetTime(&start_time_co);
		val_actan_theta = atan(val_y/val_x);
		val_sine 	= sqrt(val_x*val_x+val_y*val_y);
		XTime_GetTime(&stop_time_co);
		tt += stop_time_co - start_time_co;
	}


    // Compute timing on ARM PS hardware
    tt_print = (double)tt/(NUM_DEGREE*2);;
    cout << "\nDone, Total time steps for PS internal (including ap_fixed emulation) = " << tt_print << endl;
    tt_seconds = COUNTS_PER_SECOND;
    cout << "Cycle counts per second for ARM A9 core for PS internal add = " << tt_seconds << endl;
    ps_time = (float) tt_print / tt_seconds;
    cout << "Time in seconds for PS ARM software internal add = times steps / COUNTS_PER_SECOND = " << ps_time << endl;


    // Compute Speedup when using the programmable logic accelerator
    speedup = ps_time / pl_time;
    cout << "Speedup of FPGA accelerator versus all software on ARM or PS/PL = " << speedup << endl;
    cout << "--- End of the Program ---" << endl;

	return 0;
}



