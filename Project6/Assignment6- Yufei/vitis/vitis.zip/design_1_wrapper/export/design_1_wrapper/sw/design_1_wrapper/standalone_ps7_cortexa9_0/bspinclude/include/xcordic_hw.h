// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2022.1 (64-bit)
// Tool Version Limit: 2022.04
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// ==============================================================
// HLS_CORDIC_PERIPH_BUS
// 0x00 : Control signals
//        bit 0  - ap_start (Read/Write/COH)
//        bit 1  - ap_done (Read/COR)
//        bit 2  - ap_idle (Read)
//        bit 3  - ap_ready (Read/COR)
//        bit 7  - auto_restart (Read/Write)
//        bit 9  - interrupt (Read)
//        others - reserved
// 0x04 : Global Interrupt Enable Register
//        bit 0  - Global Interrupt Enable (Read/Write)
//        others - reserved
// 0x08 : IP Interrupt Enable Register (Read/Write)
//        bit 0 - enable ap_done interrupt (Read/Write)
//        bit 1 - enable ap_ready interrupt (Read/Write)
//        others - reserved
// 0x0c : IP Interrupt Status Register (Read/COR)
//        bit 0 - ap_done (Read/COR)
//        bit 1 - ap_ready (Read/COR)
//        others - reserved
// 0x10 : Data signal of theta_in
//        bit 15~0 - theta_in[15:0] (Read/Write)
//        others   - reserved
// 0x14 : reserved
// 0x18 : Data signal of x_in
//        bit 15~0 - x_in[15:0] (Read/Write)
//        others   - reserved
// 0x1c : reserved
// 0x20 : Data signal of y_in
//        bit 15~0 - y_in[15:0] (Read/Write)
//        others   - reserved
// 0x24 : reserved
// 0x28 : Data signal of out_x
//        bit 15~0 - out_x[15:0] (Read)
//        others   - reserved
// 0x2c : Control signal of out_x
//        bit 0  - out_x_ap_vld (Read/COR)
//        others - reserved
// 0x38 : Data signal of out_y
//        bit 15~0 - out_y[15:0] (Read)
//        others   - reserved
// 0x3c : Control signal of out_y
//        bit 0  - out_y_ap_vld (Read/COR)
//        others - reserved
// 0x48 : Data signal of mode
//        bit 0  - mode[0] (Read/Write)
//        others - reserved
// 0x4c : reserved
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XCORDIC_HLS_CORDIC_PERIPH_BUS_ADDR_AP_CTRL       0x00
#define XCORDIC_HLS_CORDIC_PERIPH_BUS_ADDR_GIE           0x04
#define XCORDIC_HLS_CORDIC_PERIPH_BUS_ADDR_IER           0x08
#define XCORDIC_HLS_CORDIC_PERIPH_BUS_ADDR_ISR           0x0c
#define XCORDIC_HLS_CORDIC_PERIPH_BUS_ADDR_THETA_IN_DATA 0x10
#define XCORDIC_HLS_CORDIC_PERIPH_BUS_BITS_THETA_IN_DATA 16
#define XCORDIC_HLS_CORDIC_PERIPH_BUS_ADDR_X_IN_DATA     0x18
#define XCORDIC_HLS_CORDIC_PERIPH_BUS_BITS_X_IN_DATA     16
#define XCORDIC_HLS_CORDIC_PERIPH_BUS_ADDR_Y_IN_DATA     0x20
#define XCORDIC_HLS_CORDIC_PERIPH_BUS_BITS_Y_IN_DATA     16
#define XCORDIC_HLS_CORDIC_PERIPH_BUS_ADDR_OUT_X_DATA    0x28
#define XCORDIC_HLS_CORDIC_PERIPH_BUS_BITS_OUT_X_DATA    16
#define XCORDIC_HLS_CORDIC_PERIPH_BUS_ADDR_OUT_X_CTRL    0x2c
#define XCORDIC_HLS_CORDIC_PERIPH_BUS_ADDR_OUT_Y_DATA    0x38
#define XCORDIC_HLS_CORDIC_PERIPH_BUS_BITS_OUT_Y_DATA    16
#define XCORDIC_HLS_CORDIC_PERIPH_BUS_ADDR_OUT_Y_CTRL    0x3c
#define XCORDIC_HLS_CORDIC_PERIPH_BUS_ADDR_MODE_DATA     0x48
#define XCORDIC_HLS_CORDIC_PERIPH_BUS_BITS_MODE_DATA     1

