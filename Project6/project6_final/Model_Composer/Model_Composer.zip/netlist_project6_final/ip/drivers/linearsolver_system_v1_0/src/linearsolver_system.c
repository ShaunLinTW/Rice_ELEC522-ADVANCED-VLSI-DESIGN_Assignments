#include "linearsolver_system.h"
#ifndef __linux__
int linearsolver_system_CfgInitialize(linearsolver_system *InstancePtr, linearsolver_system_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->linearsolver_system_BaseAddress = ConfigPtr->linearsolver_system_BaseAddress;

    InstancePtr->IsReady = 1;
    return XST_SUCCESS;
}
#endif
void linearsolver_system_start_var_write(linearsolver_system *InstancePtr, u32 Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    linearsolver_system_WriteReg(InstancePtr->linearsolver_system_BaseAddress, 0, Data);
}
u32 linearsolver_system_start_var_read(linearsolver_system *InstancePtr) {

    u32 Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = linearsolver_system_ReadReg(InstancePtr->linearsolver_system_BaseAddress, 0);
    return Data;
}
void linearsolver_system_rst_var_write(linearsolver_system *InstancePtr, u32 Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    linearsolver_system_WriteReg(InstancePtr->linearsolver_system_BaseAddress, 4, Data);
}
u32 linearsolver_system_rst_var_read(linearsolver_system *InstancePtr) {

    u32 Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = linearsolver_system_ReadReg(InstancePtr->linearsolver_system_BaseAddress, 4);
    return Data;
}
void linearsolver_system_b_4_write(linearsolver_system *InstancePtr, int Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    linearsolver_system_WriteReg(InstancePtr->linearsolver_system_BaseAddress, 8, Data);
}
int linearsolver_system_b_4_read(linearsolver_system *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = linearsolver_system_ReadReg(InstancePtr->linearsolver_system_BaseAddress, 8);
    return Data;
}
void linearsolver_system_b_3_write(linearsolver_system *InstancePtr, int Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    linearsolver_system_WriteReg(InstancePtr->linearsolver_system_BaseAddress, 12, Data);
}
int linearsolver_system_b_3_read(linearsolver_system *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = linearsolver_system_ReadReg(InstancePtr->linearsolver_system_BaseAddress, 12);
    return Data;
}
void linearsolver_system_b_2_write(linearsolver_system *InstancePtr, int Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    linearsolver_system_WriteReg(InstancePtr->linearsolver_system_BaseAddress, 16, Data);
}
int linearsolver_system_b_2_read(linearsolver_system *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = linearsolver_system_ReadReg(InstancePtr->linearsolver_system_BaseAddress, 16);
    return Data;
}
void linearsolver_system_b_1_write(linearsolver_system *InstancePtr, int Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    linearsolver_system_WriteReg(InstancePtr->linearsolver_system_BaseAddress, 20, Data);
}
int linearsolver_system_b_1_read(linearsolver_system *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = linearsolver_system_ReadReg(InstancePtr->linearsolver_system_BaseAddress, 20);
    return Data;
}
void linearsolver_system_a44_var_write(linearsolver_system *InstancePtr, int Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    linearsolver_system_WriteReg(InstancePtr->linearsolver_system_BaseAddress, 24, Data);
}
int linearsolver_system_a44_var_read(linearsolver_system *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = linearsolver_system_ReadReg(InstancePtr->linearsolver_system_BaseAddress, 24);
    return Data;
}
void linearsolver_system_a43_var_write(linearsolver_system *InstancePtr, int Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    linearsolver_system_WriteReg(InstancePtr->linearsolver_system_BaseAddress, 28, Data);
}
int linearsolver_system_a43_var_read(linearsolver_system *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = linearsolver_system_ReadReg(InstancePtr->linearsolver_system_BaseAddress, 28);
    return Data;
}
void linearsolver_system_a42_var_write(linearsolver_system *InstancePtr, int Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    linearsolver_system_WriteReg(InstancePtr->linearsolver_system_BaseAddress, 32, Data);
}
int linearsolver_system_a42_var_read(linearsolver_system *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = linearsolver_system_ReadReg(InstancePtr->linearsolver_system_BaseAddress, 32);
    return Data;
}
void linearsolver_system_a41_var_write(linearsolver_system *InstancePtr, int Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    linearsolver_system_WriteReg(InstancePtr->linearsolver_system_BaseAddress, 36, Data);
}
int linearsolver_system_a41_var_read(linearsolver_system *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = linearsolver_system_ReadReg(InstancePtr->linearsolver_system_BaseAddress, 36);
    return Data;
}
void linearsolver_system_a34_var_write(linearsolver_system *InstancePtr, int Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    linearsolver_system_WriteReg(InstancePtr->linearsolver_system_BaseAddress, 40, Data);
}
int linearsolver_system_a34_var_read(linearsolver_system *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = linearsolver_system_ReadReg(InstancePtr->linearsolver_system_BaseAddress, 40);
    return Data;
}
void linearsolver_system_a33_var_write(linearsolver_system *InstancePtr, int Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    linearsolver_system_WriteReg(InstancePtr->linearsolver_system_BaseAddress, 44, Data);
}
int linearsolver_system_a33_var_read(linearsolver_system *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = linearsolver_system_ReadReg(InstancePtr->linearsolver_system_BaseAddress, 44);
    return Data;
}
void linearsolver_system_a32_var_write(linearsolver_system *InstancePtr, int Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    linearsolver_system_WriteReg(InstancePtr->linearsolver_system_BaseAddress, 48, Data);
}
int linearsolver_system_a32_var_read(linearsolver_system *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = linearsolver_system_ReadReg(InstancePtr->linearsolver_system_BaseAddress, 48);
    return Data;
}
void linearsolver_system_a31_var_write(linearsolver_system *InstancePtr, int Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    linearsolver_system_WriteReg(InstancePtr->linearsolver_system_BaseAddress, 52, Data);
}
int linearsolver_system_a31_var_read(linearsolver_system *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = linearsolver_system_ReadReg(InstancePtr->linearsolver_system_BaseAddress, 52);
    return Data;
}
void linearsolver_system_a24_var_write(linearsolver_system *InstancePtr, int Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    linearsolver_system_WriteReg(InstancePtr->linearsolver_system_BaseAddress, 56, Data);
}
int linearsolver_system_a24_var_read(linearsolver_system *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = linearsolver_system_ReadReg(InstancePtr->linearsolver_system_BaseAddress, 56);
    return Data;
}
void linearsolver_system_a23_var_write(linearsolver_system *InstancePtr, int Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    linearsolver_system_WriteReg(InstancePtr->linearsolver_system_BaseAddress, 60, Data);
}
int linearsolver_system_a23_var_read(linearsolver_system *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = linearsolver_system_ReadReg(InstancePtr->linearsolver_system_BaseAddress, 60);
    return Data;
}
void linearsolver_system_a22_var_write(linearsolver_system *InstancePtr, int Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    linearsolver_system_WriteReg(InstancePtr->linearsolver_system_BaseAddress, 64, Data);
}
int linearsolver_system_a22_var_read(linearsolver_system *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = linearsolver_system_ReadReg(InstancePtr->linearsolver_system_BaseAddress, 64);
    return Data;
}
void linearsolver_system_a21_var_write(linearsolver_system *InstancePtr, int Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    linearsolver_system_WriteReg(InstancePtr->linearsolver_system_BaseAddress, 68, Data);
}
int linearsolver_system_a21_var_read(linearsolver_system *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = linearsolver_system_ReadReg(InstancePtr->linearsolver_system_BaseAddress, 68);
    return Data;
}
void linearsolver_system_a14_var_write(linearsolver_system *InstancePtr, int Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    linearsolver_system_WriteReg(InstancePtr->linearsolver_system_BaseAddress, 72, Data);
}
int linearsolver_system_a14_var_read(linearsolver_system *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = linearsolver_system_ReadReg(InstancePtr->linearsolver_system_BaseAddress, 72);
    return Data;
}
void linearsolver_system_a13_var_write(linearsolver_system *InstancePtr, int Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    linearsolver_system_WriteReg(InstancePtr->linearsolver_system_BaseAddress, 76, Data);
}
int linearsolver_system_a13_var_read(linearsolver_system *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = linearsolver_system_ReadReg(InstancePtr->linearsolver_system_BaseAddress, 76);
    return Data;
}
void linearsolver_system_a12_var_write(linearsolver_system *InstancePtr, int Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    linearsolver_system_WriteReg(InstancePtr->linearsolver_system_BaseAddress, 80, Data);
}
int linearsolver_system_a12_var_read(linearsolver_system *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = linearsolver_system_ReadReg(InstancePtr->linearsolver_system_BaseAddress, 80);
    return Data;
}
void linearsolver_system_a11_var_write(linearsolver_system *InstancePtr, int Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    linearsolver_system_WriteReg(InstancePtr->linearsolver_system_BaseAddress, 84, Data);
}
int linearsolver_system_a11_var_read(linearsolver_system *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = linearsolver_system_ReadReg(InstancePtr->linearsolver_system_BaseAddress, 84);
    return Data;
}
int linearsolver_system_qout_1_read(linearsolver_system *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = linearsolver_system_ReadReg(InstancePtr->linearsolver_system_BaseAddress, 88);
    return Data;
}
int linearsolver_system_qout_11_read(linearsolver_system *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = linearsolver_system_ReadReg(InstancePtr->linearsolver_system_BaseAddress, 92);
    return Data;
}
int linearsolver_system_qout_12_read(linearsolver_system *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = linearsolver_system_ReadReg(InstancePtr->linearsolver_system_BaseAddress, 96);
    return Data;
}
int linearsolver_system_qout_13_read(linearsolver_system *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = linearsolver_system_ReadReg(InstancePtr->linearsolver_system_BaseAddress, 100);
    return Data;
}
int linearsolver_system_qout_14_read(linearsolver_system *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = linearsolver_system_ReadReg(InstancePtr->linearsolver_system_BaseAddress, 104);
    return Data;
}
int linearsolver_system_qout_2_read(linearsolver_system *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = linearsolver_system_ReadReg(InstancePtr->linearsolver_system_BaseAddress, 108);
    return Data;
}
int linearsolver_system_qout_21_read(linearsolver_system *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = linearsolver_system_ReadReg(InstancePtr->linearsolver_system_BaseAddress, 112);
    return Data;
}
int linearsolver_system_qout_22_read(linearsolver_system *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = linearsolver_system_ReadReg(InstancePtr->linearsolver_system_BaseAddress, 116);
    return Data;
}
int linearsolver_system_qout_23_read(linearsolver_system *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = linearsolver_system_ReadReg(InstancePtr->linearsolver_system_BaseAddress, 120);
    return Data;
}
int linearsolver_system_qout_24_read(linearsolver_system *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = linearsolver_system_ReadReg(InstancePtr->linearsolver_system_BaseAddress, 124);
    return Data;
}
u32 linearsolver_system_qout_3_read(linearsolver_system *InstancePtr) {

    u32 Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = linearsolver_system_ReadReg(InstancePtr->linearsolver_system_BaseAddress, 128);
    return Data;
}
int linearsolver_system_qout_31_read(linearsolver_system *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = linearsolver_system_ReadReg(InstancePtr->linearsolver_system_BaseAddress, 132);
    return Data;
}
int linearsolver_system_qout_32_read(linearsolver_system *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = linearsolver_system_ReadReg(InstancePtr->linearsolver_system_BaseAddress, 136);
    return Data;
}
int linearsolver_system_qout_33_read(linearsolver_system *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = linearsolver_system_ReadReg(InstancePtr->linearsolver_system_BaseAddress, 140);
    return Data;
}
int linearsolver_system_qout_34_read(linearsolver_system *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = linearsolver_system_ReadReg(InstancePtr->linearsolver_system_BaseAddress, 144);
    return Data;
}
int linearsolver_system_qout_4_read(linearsolver_system *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = linearsolver_system_ReadReg(InstancePtr->linearsolver_system_BaseAddress, 148);
    return Data;
}
int linearsolver_system_qout_41_read(linearsolver_system *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = linearsolver_system_ReadReg(InstancePtr->linearsolver_system_BaseAddress, 152);
    return Data;
}
int linearsolver_system_qout_42_read(linearsolver_system *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = linearsolver_system_ReadReg(InstancePtr->linearsolver_system_BaseAddress, 156);
    return Data;
}
int linearsolver_system_qout_43_read(linearsolver_system *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = linearsolver_system_ReadReg(InstancePtr->linearsolver_system_BaseAddress, 160);
    return Data;
}
int linearsolver_system_qout_44_read(linearsolver_system *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = linearsolver_system_ReadReg(InstancePtr->linearsolver_system_BaseAddress, 164);
    return Data;
}
int linearsolver_system_rout_11_read(linearsolver_system *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = linearsolver_system_ReadReg(InstancePtr->linearsolver_system_BaseAddress, 168);
    return Data;
}
int linearsolver_system_rout_21_read(linearsolver_system *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = linearsolver_system_ReadReg(InstancePtr->linearsolver_system_BaseAddress, 172);
    return Data;
}
int linearsolver_system_rout_22_read(linearsolver_system *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = linearsolver_system_ReadReg(InstancePtr->linearsolver_system_BaseAddress, 176);
    return Data;
}
int linearsolver_system_rout_31_read(linearsolver_system *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = linearsolver_system_ReadReg(InstancePtr->linearsolver_system_BaseAddress, 180);
    return Data;
}
int linearsolver_system_rout_32_read(linearsolver_system *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = linearsolver_system_ReadReg(InstancePtr->linearsolver_system_BaseAddress, 184);
    return Data;
}
int linearsolver_system_rout_33_read(linearsolver_system *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = linearsolver_system_ReadReg(InstancePtr->linearsolver_system_BaseAddress, 188);
    return Data;
}
int linearsolver_system_rout_41_read(linearsolver_system *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = linearsolver_system_ReadReg(InstancePtr->linearsolver_system_BaseAddress, 192);
    return Data;
}
int linearsolver_system_rout_42_read(linearsolver_system *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = linearsolver_system_ReadReg(InstancePtr->linearsolver_system_BaseAddress, 196);
    return Data;
}
int linearsolver_system_rout_43_read(linearsolver_system *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = linearsolver_system_ReadReg(InstancePtr->linearsolver_system_BaseAddress, 200);
    return Data;
}
int linearsolver_system_rout_44_read(linearsolver_system *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = linearsolver_system_ReadReg(InstancePtr->linearsolver_system_BaseAddress, 204);
    return Data;
}
