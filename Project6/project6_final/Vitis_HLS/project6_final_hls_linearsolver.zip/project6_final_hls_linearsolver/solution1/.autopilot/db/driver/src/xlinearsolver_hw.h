// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2022.1 (64-bit)
// Tool Version Limit: 2022.04
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// ==============================================================
// A_in
// 0x20 ~
// 0x3f : Memory 'A' (16 * 16b)
//        Word n : bit [15: 0] - A[2n]
//                 bit [31:16] - A[2n+1]
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XLINEARSOLVER_A_IN_ADDR_A_BASE 0x20
#define XLINEARSOLVER_A_IN_ADDR_A_HIGH 0x3f
#define XLINEARSOLVER_A_IN_WIDTH_A     16
#define XLINEARSOLVER_A_IN_DEPTH_A     16

// b_in
// 0x10 ~
// 0x17 : Memory 'b' (4 * 16b)
//        Word n : bit [15: 0] - b[2n]
//                 bit [31:16] - b[2n+1]
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XLINEARSOLVER_B_IN_ADDR_B_BASE 0x10
#define XLINEARSOLVER_B_IN_ADDR_B_HIGH 0x17
#define XLINEARSOLVER_B_IN_WIDTH_B     16
#define XLINEARSOLVER_B_IN_DEPTH_B     4

// x_out
// 0x10 ~
// 0x17 : Memory 'x' (4 * 16b)
//        Word n : bit [15: 0] - x[2n]
//                 bit [31:16] - x[2n+1]
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XLINEARSOLVER_X_OUT_ADDR_X_BASE 0x10
#define XLINEARSOLVER_X_OUT_ADDR_X_HIGH 0x17
#define XLINEARSOLVER_X_OUT_WIDTH_X     16
#define XLINEARSOLVER_X_OUT_DEPTH_X     4

