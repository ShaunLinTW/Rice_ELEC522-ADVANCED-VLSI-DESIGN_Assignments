// 0x10 ~
// 0x17 : Memory 'b' (4 * 16b)
//        Word n : bit [15: 0] - b[2n]
//                 bit [31:16] - b[2n+1]
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define B_IN_ADDR_B_BASE 0x10
#define B_IN_ADDR_B_HIGH 0x17
#define B_IN_WIDTH_B     16
#define B_IN_DEPTH_B     4
