// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2022.1 (64-bit)
// Tool Version Limit: 2022.04
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// ==============================================================
/***************************** Include Files *********************************/
#include "xlinearsolver.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XLinearsolver_CfgInitialize(XLinearsolver *InstancePtr, XLinearsolver_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->A_in_BaseAddress = ConfigPtr->A_in_BaseAddress;
    InstancePtr->B_in_BaseAddress = ConfigPtr->B_in_BaseAddress;
    InstancePtr->X_out_BaseAddress = ConfigPtr->X_out_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

u32 XLinearsolver_Get_A_BaseAddress(XLinearsolver *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->A_in_BaseAddress + XLINEARSOLVER_A_IN_ADDR_A_BASE);
}

u32 XLinearsolver_Get_A_HighAddress(XLinearsolver *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->A_in_BaseAddress + XLINEARSOLVER_A_IN_ADDR_A_HIGH);
}

u32 XLinearsolver_Get_A_TotalBytes(XLinearsolver *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XLINEARSOLVER_A_IN_ADDR_A_HIGH - XLINEARSOLVER_A_IN_ADDR_A_BASE + 1);
}

u32 XLinearsolver_Get_A_BitWidth(XLinearsolver *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XLINEARSOLVER_A_IN_WIDTH_A;
}

u32 XLinearsolver_Get_A_Depth(XLinearsolver *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XLINEARSOLVER_A_IN_DEPTH_A;
}

u32 XLinearsolver_Write_A_Words(XLinearsolver *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XLINEARSOLVER_A_IN_ADDR_A_HIGH - XLINEARSOLVER_A_IN_ADDR_A_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->A_in_BaseAddress + XLINEARSOLVER_A_IN_ADDR_A_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XLinearsolver_Read_A_Words(XLinearsolver *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XLINEARSOLVER_A_IN_ADDR_A_HIGH - XLINEARSOLVER_A_IN_ADDR_A_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->A_in_BaseAddress + XLINEARSOLVER_A_IN_ADDR_A_BASE + (offset + i)*4);
    }
    return length;
}

u32 XLinearsolver_Write_A_Bytes(XLinearsolver *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XLINEARSOLVER_A_IN_ADDR_A_HIGH - XLINEARSOLVER_A_IN_ADDR_A_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->A_in_BaseAddress + XLINEARSOLVER_A_IN_ADDR_A_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XLinearsolver_Read_A_Bytes(XLinearsolver *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XLINEARSOLVER_A_IN_ADDR_A_HIGH - XLINEARSOLVER_A_IN_ADDR_A_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->A_in_BaseAddress + XLINEARSOLVER_A_IN_ADDR_A_BASE + offset + i);
    }
    return length;
}

u32 XLinearsolver_Get_b_BaseAddress(XLinearsolver *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->B_in_BaseAddress + XLINEARSOLVER_B_IN_ADDR_B_BASE);
}

u32 XLinearsolver_Get_b_HighAddress(XLinearsolver *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->B_in_BaseAddress + XLINEARSOLVER_B_IN_ADDR_B_HIGH);
}

u32 XLinearsolver_Get_b_TotalBytes(XLinearsolver *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XLINEARSOLVER_B_IN_ADDR_B_HIGH - XLINEARSOLVER_B_IN_ADDR_B_BASE + 1);
}

u32 XLinearsolver_Get_b_BitWidth(XLinearsolver *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XLINEARSOLVER_B_IN_WIDTH_B;
}

u32 XLinearsolver_Get_b_Depth(XLinearsolver *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XLINEARSOLVER_B_IN_DEPTH_B;
}

u32 XLinearsolver_Write_b_Words(XLinearsolver *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XLINEARSOLVER_B_IN_ADDR_B_HIGH - XLINEARSOLVER_B_IN_ADDR_B_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->B_in_BaseAddress + XLINEARSOLVER_B_IN_ADDR_B_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XLinearsolver_Read_b_Words(XLinearsolver *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XLINEARSOLVER_B_IN_ADDR_B_HIGH - XLINEARSOLVER_B_IN_ADDR_B_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->B_in_BaseAddress + XLINEARSOLVER_B_IN_ADDR_B_BASE + (offset + i)*4);
    }
    return length;
}

u32 XLinearsolver_Write_b_Bytes(XLinearsolver *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XLINEARSOLVER_B_IN_ADDR_B_HIGH - XLINEARSOLVER_B_IN_ADDR_B_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->B_in_BaseAddress + XLINEARSOLVER_B_IN_ADDR_B_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XLinearsolver_Read_b_Bytes(XLinearsolver *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XLINEARSOLVER_B_IN_ADDR_B_HIGH - XLINEARSOLVER_B_IN_ADDR_B_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->B_in_BaseAddress + XLINEARSOLVER_B_IN_ADDR_B_BASE + offset + i);
    }
    return length;
}

u32 XLinearsolver_Get_x_BaseAddress(XLinearsolver *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->X_out_BaseAddress + XLINEARSOLVER_X_OUT_ADDR_X_BASE);
}

u32 XLinearsolver_Get_x_HighAddress(XLinearsolver *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->X_out_BaseAddress + XLINEARSOLVER_X_OUT_ADDR_X_HIGH);
}

u32 XLinearsolver_Get_x_TotalBytes(XLinearsolver *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XLINEARSOLVER_X_OUT_ADDR_X_HIGH - XLINEARSOLVER_X_OUT_ADDR_X_BASE + 1);
}

u32 XLinearsolver_Get_x_BitWidth(XLinearsolver *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XLINEARSOLVER_X_OUT_WIDTH_X;
}

u32 XLinearsolver_Get_x_Depth(XLinearsolver *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XLINEARSOLVER_X_OUT_DEPTH_X;
}

u32 XLinearsolver_Write_x_Words(XLinearsolver *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XLINEARSOLVER_X_OUT_ADDR_X_HIGH - XLINEARSOLVER_X_OUT_ADDR_X_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->X_out_BaseAddress + XLINEARSOLVER_X_OUT_ADDR_X_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XLinearsolver_Read_x_Words(XLinearsolver *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XLINEARSOLVER_X_OUT_ADDR_X_HIGH - XLINEARSOLVER_X_OUT_ADDR_X_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->X_out_BaseAddress + XLINEARSOLVER_X_OUT_ADDR_X_BASE + (offset + i)*4);
    }
    return length;
}

u32 XLinearsolver_Write_x_Bytes(XLinearsolver *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XLINEARSOLVER_X_OUT_ADDR_X_HIGH - XLINEARSOLVER_X_OUT_ADDR_X_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->X_out_BaseAddress + XLINEARSOLVER_X_OUT_ADDR_X_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XLinearsolver_Read_x_Bytes(XLinearsolver *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XLINEARSOLVER_X_OUT_ADDR_X_HIGH - XLINEARSOLVER_X_OUT_ADDR_X_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->X_out_BaseAddress + XLINEARSOLVER_X_OUT_ADDR_X_BASE + offset + i);
    }
    return length;
}

