// 0x20 ~
// 0x3f : Memory 'A' (16 * 16b)
//        Word n : bit [15: 0] - A[2n]
//                 bit [31:16] - A[2n+1]
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define A_IN_ADDR_A_BASE 0x20
#define A_IN_ADDR_A_HIGH 0x3f
#define A_IN_WIDTH_A     16
#define A_IN_DEPTH_A     16
