// 0x10 ~
// 0x17 : Memory 'x' (4 * 16b)
//        Word n : bit [15: 0] - x[2n]
//                 bit [31:16] - x[2n+1]
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define X_OUT_ADDR_X_BASE 0x10
#define X_OUT_ADDR_X_HIGH 0x17
#define X_OUT_WIDTH_X     16
#define X_OUT_DEPTH_X     4
