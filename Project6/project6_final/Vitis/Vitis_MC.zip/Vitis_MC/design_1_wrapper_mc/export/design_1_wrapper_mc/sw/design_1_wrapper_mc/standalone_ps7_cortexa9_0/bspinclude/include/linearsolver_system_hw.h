/**
*
* @file linearsolver_system_hw.h
*
* This header file contains identifiers and driver functions (or
* macros) that can be used to access the device.  The user should refer to the
* hardware device specification for more details of the device operation.
*/ 
#define LINEARSOLVER_SYSTEM_START_VAR 0x0/**< start_var */
#define LINEARSOLVER_SYSTEM_RST_VAR 0x4/**< rst_var */
#define LINEARSOLVER_SYSTEM_B_4 0x8/**< b_4 */
#define LINEARSOLVER_SYSTEM_B_3 0xc/**< b_3 */
#define LINEARSOLVER_SYSTEM_B_2 0x10/**< b_2 */
#define LINEARSOLVER_SYSTEM_B_1 0x14/**< b_1 */
#define LINEARSOLVER_SYSTEM_A44_VAR 0x18/**< a44_var */
#define LINEARSOLVER_SYSTEM_A43_VAR 0x1c/**< a43_var */
#define LINEARSOLVER_SYSTEM_A42_VAR 0x20/**< a42_var */
#define LINEARSOLVER_SYSTEM_A41_VAR 0x24/**< a41_var */
#define LINEARSOLVER_SYSTEM_A34_VAR 0x28/**< a34_var */
#define LINEARSOLVER_SYSTEM_A33_VAR 0x2c/**< a33_var */
#define LINEARSOLVER_SYSTEM_A32_VAR 0x30/**< a32_var */
#define LINEARSOLVER_SYSTEM_A31_VAR 0x34/**< a31_var */
#define LINEARSOLVER_SYSTEM_A24_VAR 0x38/**< a24_var */
#define LINEARSOLVER_SYSTEM_A23_VAR 0x3c/**< a23_var */
#define LINEARSOLVER_SYSTEM_A22_VAR 0x40/**< a22_var */
#define LINEARSOLVER_SYSTEM_A21_VAR 0x44/**< a21_var */
#define LINEARSOLVER_SYSTEM_A14_VAR 0x48/**< a14_var */
#define LINEARSOLVER_SYSTEM_A13_VAR 0x4c/**< a13_var */
#define LINEARSOLVER_SYSTEM_A12_VAR 0x50/**< a12_var */
#define LINEARSOLVER_SYSTEM_A11_VAR 0x54/**< a11_var */
#define LINEARSOLVER_SYSTEM_QOUT_1 0x58/**< qout_1 */
#define LINEARSOLVER_SYSTEM_QOUT_11 0x5c/**< qout_11 */
#define LINEARSOLVER_SYSTEM_QOUT_12 0x60/**< qout_12 */
#define LINEARSOLVER_SYSTEM_QOUT_13 0x64/**< qout_13 */
#define LINEARSOLVER_SYSTEM_QOUT_14 0x68/**< qout_14 */
#define LINEARSOLVER_SYSTEM_QOUT_2 0x6c/**< qout_2 */
#define LINEARSOLVER_SYSTEM_QOUT_21 0x70/**< qout_21 */
#define LINEARSOLVER_SYSTEM_QOUT_22 0x74/**< qout_22 */
#define LINEARSOLVER_SYSTEM_QOUT_23 0x78/**< qout_23 */
#define LINEARSOLVER_SYSTEM_QOUT_24 0x7c/**< qout_24 */
#define LINEARSOLVER_SYSTEM_QOUT_3 0x80/**< qout_3 */
#define LINEARSOLVER_SYSTEM_QOUT_31 0x84/**< qout_31 */
#define LINEARSOLVER_SYSTEM_QOUT_32 0x88/**< qout_32 */
#define LINEARSOLVER_SYSTEM_QOUT_33 0x8c/**< qout_33 */
#define LINEARSOLVER_SYSTEM_QOUT_34 0x90/**< qout_34 */
#define LINEARSOLVER_SYSTEM_QOUT_4 0x94/**< qout_4 */
#define LINEARSOLVER_SYSTEM_QOUT_41 0x98/**< qout_41 */
#define LINEARSOLVER_SYSTEM_QOUT_42 0x9c/**< qout_42 */
#define LINEARSOLVER_SYSTEM_QOUT_43 0xa0/**< qout_43 */
#define LINEARSOLVER_SYSTEM_QOUT_44 0xa4/**< qout_44 */
#define LINEARSOLVER_SYSTEM_ROUT_11 0xa8/**< rout_11 */
#define LINEARSOLVER_SYSTEM_ROUT_21 0xac/**< rout_21 */
#define LINEARSOLVER_SYSTEM_ROUT_22 0xb0/**< rout_22 */
#define LINEARSOLVER_SYSTEM_ROUT_31 0xb4/**< rout_31 */
#define LINEARSOLVER_SYSTEM_ROUT_32 0xb8/**< rout_32 */
#define LINEARSOLVER_SYSTEM_ROUT_33 0xbc/**< rout_33 */
#define LINEARSOLVER_SYSTEM_ROUT_41 0xc0/**< rout_41 */
#define LINEARSOLVER_SYSTEM_ROUT_42 0xc4/**< rout_42 */
#define LINEARSOLVER_SYSTEM_ROUT_43 0xc8/**< rout_43 */
#define LINEARSOLVER_SYSTEM_ROUT_44 0xcc/**< rout_44 */
