/**
* @file linearsolver_system_sinit.c
*
* The implementation of the linearsolver_system driver's static initialzation
* functionality.
*
* @note
*
* None
*
*/
#ifndef __linux__
#include "xstatus.h"
#include "xparameters.h"
#include "linearsolver_system.h"
extern linearsolver_system_Config linearsolver_system_ConfigTable[];
/**
* Lookup the device configuration based on the unique device ID.  The table
* ConfigTable contains the configuration info for each device in the system.
*
* @param DeviceId is the device identifier to lookup.
*
* @return
*     - A pointer of data type linearsolver_system_Config which
*    points to the device configuration if DeviceID is found.
*    - NULL if DeviceID is not found.
*
* @note    None.
*
*/
linearsolver_system_Config *linearsolver_system_LookupConfig(u16 DeviceId) {
    linearsolver_system_Config *ConfigPtr = NULL;
    int Index;
    for (Index = 0; Index < XPAR_LINEARSOLVER_SYSTEM_NUM_INSTANCES; Index++) {
        if (linearsolver_system_ConfigTable[Index].DeviceId == DeviceId) {
            ConfigPtr = &linearsolver_system_ConfigTable[Index];
            break;
        }
    }
    return ConfigPtr;
}
int linearsolver_system_Initialize(linearsolver_system *InstancePtr, u16 DeviceId) {
    linearsolver_system_Config *ConfigPtr;
    Xil_AssertNonvoid(InstancePtr != NULL);
    ConfigPtr = linearsolver_system_LookupConfig(DeviceId);
    if (ConfigPtr == NULL) {
        InstancePtr->IsReady = 0;
        return (XST_DEVICE_NOT_FOUND);
    }
    return linearsolver_system_CfgInitialize(InstancePtr, ConfigPtr);
}
#endif
