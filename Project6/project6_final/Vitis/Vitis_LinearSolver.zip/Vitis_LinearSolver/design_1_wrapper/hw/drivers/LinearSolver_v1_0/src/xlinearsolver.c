// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2022.1 (64-bit)
// Tool Version Limit: 2022.04
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// ==============================================================
/***************************** Include Files *********************************/
#include "xlinearsolver.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XLinearsolver_CfgInitialize(XLinearsolver *InstancePtr, XLinearsolver_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Hls_treeadd_periph_bus_BaseAddress = ConfigPtr->Hls_treeadd_periph_bus_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XLinearsolver_Start(XLinearsolver *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLinearsolver_ReadReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XLINEARSOLVER_HLS_TREEADD_PERIPH_BUS_ADDR_AP_CTRL) & 0x80;
    XLinearsolver_WriteReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XLINEARSOLVER_HLS_TREEADD_PERIPH_BUS_ADDR_AP_CTRL, Data | 0x01);
}

u32 XLinearsolver_IsDone(XLinearsolver *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLinearsolver_ReadReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XLINEARSOLVER_HLS_TREEADD_PERIPH_BUS_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XLinearsolver_IsIdle(XLinearsolver *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLinearsolver_ReadReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XLINEARSOLVER_HLS_TREEADD_PERIPH_BUS_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XLinearsolver_IsReady(XLinearsolver *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLinearsolver_ReadReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XLINEARSOLVER_HLS_TREEADD_PERIPH_BUS_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XLinearsolver_EnableAutoRestart(XLinearsolver *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XLinearsolver_WriteReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XLINEARSOLVER_HLS_TREEADD_PERIPH_BUS_ADDR_AP_CTRL, 0x80);
}

void XLinearsolver_DisableAutoRestart(XLinearsolver *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XLinearsolver_WriteReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XLINEARSOLVER_HLS_TREEADD_PERIPH_BUS_ADDR_AP_CTRL, 0);
}

void XLinearsolver_Set_a11(XLinearsolver *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XLinearsolver_WriteReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XLINEARSOLVER_HLS_TREEADD_PERIPH_BUS_ADDR_A11_DATA, Data);
}

u32 XLinearsolver_Get_a11(XLinearsolver *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLinearsolver_ReadReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XLINEARSOLVER_HLS_TREEADD_PERIPH_BUS_ADDR_A11_DATA);
    return Data;
}

void XLinearsolver_Set_a12(XLinearsolver *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XLinearsolver_WriteReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XLINEARSOLVER_HLS_TREEADD_PERIPH_BUS_ADDR_A12_DATA, Data);
}

u32 XLinearsolver_Get_a12(XLinearsolver *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLinearsolver_ReadReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XLINEARSOLVER_HLS_TREEADD_PERIPH_BUS_ADDR_A12_DATA);
    return Data;
}

void XLinearsolver_Set_a13(XLinearsolver *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XLinearsolver_WriteReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XLINEARSOLVER_HLS_TREEADD_PERIPH_BUS_ADDR_A13_DATA, Data);
}

u32 XLinearsolver_Get_a13(XLinearsolver *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLinearsolver_ReadReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XLINEARSOLVER_HLS_TREEADD_PERIPH_BUS_ADDR_A13_DATA);
    return Data;
}

void XLinearsolver_Set_a14(XLinearsolver *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XLinearsolver_WriteReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XLINEARSOLVER_HLS_TREEADD_PERIPH_BUS_ADDR_A14_DATA, Data);
}

u32 XLinearsolver_Get_a14(XLinearsolver *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLinearsolver_ReadReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XLINEARSOLVER_HLS_TREEADD_PERIPH_BUS_ADDR_A14_DATA);
    return Data;
}

void XLinearsolver_Set_a21(XLinearsolver *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XLinearsolver_WriteReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XLINEARSOLVER_HLS_TREEADD_PERIPH_BUS_ADDR_A21_DATA, Data);
}

u32 XLinearsolver_Get_a21(XLinearsolver *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLinearsolver_ReadReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XLINEARSOLVER_HLS_TREEADD_PERIPH_BUS_ADDR_A21_DATA);
    return Data;
}

void XLinearsolver_Set_a22(XLinearsolver *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XLinearsolver_WriteReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XLINEARSOLVER_HLS_TREEADD_PERIPH_BUS_ADDR_A22_DATA, Data);
}

u32 XLinearsolver_Get_a22(XLinearsolver *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLinearsolver_ReadReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XLINEARSOLVER_HLS_TREEADD_PERIPH_BUS_ADDR_A22_DATA);
    return Data;
}

void XLinearsolver_Set_a23(XLinearsolver *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XLinearsolver_WriteReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XLINEARSOLVER_HLS_TREEADD_PERIPH_BUS_ADDR_A23_DATA, Data);
}

u32 XLinearsolver_Get_a23(XLinearsolver *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLinearsolver_ReadReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XLINEARSOLVER_HLS_TREEADD_PERIPH_BUS_ADDR_A23_DATA);
    return Data;
}

void XLinearsolver_Set_a24(XLinearsolver *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XLinearsolver_WriteReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XLINEARSOLVER_HLS_TREEADD_PERIPH_BUS_ADDR_A24_DATA, Data);
}

u32 XLinearsolver_Get_a24(XLinearsolver *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLinearsolver_ReadReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XLINEARSOLVER_HLS_TREEADD_PERIPH_BUS_ADDR_A24_DATA);
    return Data;
}

void XLinearsolver_Set_a31(XLinearsolver *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XLinearsolver_WriteReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XLINEARSOLVER_HLS_TREEADD_PERIPH_BUS_ADDR_A31_DATA, Data);
}

u32 XLinearsolver_Get_a31(XLinearsolver *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLinearsolver_ReadReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XLINEARSOLVER_HLS_TREEADD_PERIPH_BUS_ADDR_A31_DATA);
    return Data;
}

void XLinearsolver_Set_a32(XLinearsolver *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XLinearsolver_WriteReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XLINEARSOLVER_HLS_TREEADD_PERIPH_BUS_ADDR_A32_DATA, Data);
}

u32 XLinearsolver_Get_a32(XLinearsolver *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLinearsolver_ReadReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XLINEARSOLVER_HLS_TREEADD_PERIPH_BUS_ADDR_A32_DATA);
    return Data;
}

void XLinearsolver_Set_a33(XLinearsolver *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XLinearsolver_WriteReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XLINEARSOLVER_HLS_TREEADD_PERIPH_BUS_ADDR_A33_DATA, Data);
}

u32 XLinearsolver_Get_a33(XLinearsolver *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLinearsolver_ReadReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XLINEARSOLVER_HLS_TREEADD_PERIPH_BUS_ADDR_A33_DATA);
    return Data;
}

void XLinearsolver_Set_a34(XLinearsolver *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XLinearsolver_WriteReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XLINEARSOLVER_HLS_TREEADD_PERIPH_BUS_ADDR_A34_DATA, Data);
}

u32 XLinearsolver_Get_a34(XLinearsolver *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLinearsolver_ReadReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XLINEARSOLVER_HLS_TREEADD_PERIPH_BUS_ADDR_A34_DATA);
    return Data;
}

void XLinearsolver_Set_a41(XLinearsolver *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XLinearsolver_WriteReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XLINEARSOLVER_HLS_TREEADD_PERIPH_BUS_ADDR_A41_DATA, Data);
}

u32 XLinearsolver_Get_a41(XLinearsolver *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLinearsolver_ReadReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XLINEARSOLVER_HLS_TREEADD_PERIPH_BUS_ADDR_A41_DATA);
    return Data;
}

void XLinearsolver_Set_a42(XLinearsolver *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XLinearsolver_WriteReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XLINEARSOLVER_HLS_TREEADD_PERIPH_BUS_ADDR_A42_DATA, Data);
}

u32 XLinearsolver_Get_a42(XLinearsolver *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLinearsolver_ReadReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XLINEARSOLVER_HLS_TREEADD_PERIPH_BUS_ADDR_A42_DATA);
    return Data;
}

void XLinearsolver_Set_a43(XLinearsolver *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XLinearsolver_WriteReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XLINEARSOLVER_HLS_TREEADD_PERIPH_BUS_ADDR_A43_DATA, Data);
}

u32 XLinearsolver_Get_a43(XLinearsolver *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLinearsolver_ReadReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XLINEARSOLVER_HLS_TREEADD_PERIPH_BUS_ADDR_A43_DATA);
    return Data;
}

void XLinearsolver_Set_a44(XLinearsolver *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XLinearsolver_WriteReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XLINEARSOLVER_HLS_TREEADD_PERIPH_BUS_ADDR_A44_DATA, Data);
}

u32 XLinearsolver_Get_a44(XLinearsolver *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLinearsolver_ReadReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XLINEARSOLVER_HLS_TREEADD_PERIPH_BUS_ADDR_A44_DATA);
    return Data;
}

void XLinearsolver_Set_b1(XLinearsolver *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XLinearsolver_WriteReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XLINEARSOLVER_HLS_TREEADD_PERIPH_BUS_ADDR_B1_DATA, Data);
}

u32 XLinearsolver_Get_b1(XLinearsolver *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLinearsolver_ReadReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XLINEARSOLVER_HLS_TREEADD_PERIPH_BUS_ADDR_B1_DATA);
    return Data;
}

void XLinearsolver_Set_b2(XLinearsolver *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XLinearsolver_WriteReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XLINEARSOLVER_HLS_TREEADD_PERIPH_BUS_ADDR_B2_DATA, Data);
}

u32 XLinearsolver_Get_b2(XLinearsolver *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLinearsolver_ReadReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XLINEARSOLVER_HLS_TREEADD_PERIPH_BUS_ADDR_B2_DATA);
    return Data;
}

void XLinearsolver_Set_b3(XLinearsolver *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XLinearsolver_WriteReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XLINEARSOLVER_HLS_TREEADD_PERIPH_BUS_ADDR_B3_DATA, Data);
}

u32 XLinearsolver_Get_b3(XLinearsolver *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLinearsolver_ReadReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XLINEARSOLVER_HLS_TREEADD_PERIPH_BUS_ADDR_B3_DATA);
    return Data;
}

void XLinearsolver_Set_b4(XLinearsolver *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XLinearsolver_WriteReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XLINEARSOLVER_HLS_TREEADD_PERIPH_BUS_ADDR_B4_DATA, Data);
}

u32 XLinearsolver_Get_b4(XLinearsolver *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLinearsolver_ReadReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XLINEARSOLVER_HLS_TREEADD_PERIPH_BUS_ADDR_B4_DATA);
    return Data;
}

u32 XLinearsolver_Get_x1(XLinearsolver *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLinearsolver_ReadReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XLINEARSOLVER_HLS_TREEADD_PERIPH_BUS_ADDR_X1_DATA);
    return Data;
}

u32 XLinearsolver_Get_x1_vld(XLinearsolver *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLinearsolver_ReadReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XLINEARSOLVER_HLS_TREEADD_PERIPH_BUS_ADDR_X1_CTRL);
    return Data & 0x1;
}

u32 XLinearsolver_Get_x2(XLinearsolver *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLinearsolver_ReadReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XLINEARSOLVER_HLS_TREEADD_PERIPH_BUS_ADDR_X2_DATA);
    return Data;
}

u32 XLinearsolver_Get_x2_vld(XLinearsolver *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLinearsolver_ReadReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XLINEARSOLVER_HLS_TREEADD_PERIPH_BUS_ADDR_X2_CTRL);
    return Data & 0x1;
}

u32 XLinearsolver_Get_x3(XLinearsolver *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLinearsolver_ReadReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XLINEARSOLVER_HLS_TREEADD_PERIPH_BUS_ADDR_X3_DATA);
    return Data;
}

u32 XLinearsolver_Get_x3_vld(XLinearsolver *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLinearsolver_ReadReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XLINEARSOLVER_HLS_TREEADD_PERIPH_BUS_ADDR_X3_CTRL);
    return Data & 0x1;
}

u32 XLinearsolver_Get_x4(XLinearsolver *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLinearsolver_ReadReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XLINEARSOLVER_HLS_TREEADD_PERIPH_BUS_ADDR_X4_DATA);
    return Data;
}

u32 XLinearsolver_Get_x4_vld(XLinearsolver *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLinearsolver_ReadReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XLINEARSOLVER_HLS_TREEADD_PERIPH_BUS_ADDR_X4_CTRL);
    return Data & 0x1;
}

void XLinearsolver_InterruptGlobalEnable(XLinearsolver *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XLinearsolver_WriteReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XLINEARSOLVER_HLS_TREEADD_PERIPH_BUS_ADDR_GIE, 1);
}

void XLinearsolver_InterruptGlobalDisable(XLinearsolver *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XLinearsolver_WriteReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XLINEARSOLVER_HLS_TREEADD_PERIPH_BUS_ADDR_GIE, 0);
}

void XLinearsolver_InterruptEnable(XLinearsolver *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XLinearsolver_ReadReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XLINEARSOLVER_HLS_TREEADD_PERIPH_BUS_ADDR_IER);
    XLinearsolver_WriteReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XLINEARSOLVER_HLS_TREEADD_PERIPH_BUS_ADDR_IER, Register | Mask);
}

void XLinearsolver_InterruptDisable(XLinearsolver *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XLinearsolver_ReadReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XLINEARSOLVER_HLS_TREEADD_PERIPH_BUS_ADDR_IER);
    XLinearsolver_WriteReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XLINEARSOLVER_HLS_TREEADD_PERIPH_BUS_ADDR_IER, Register & (~Mask));
}

void XLinearsolver_InterruptClear(XLinearsolver *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    //XLinearsolver_WriteReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XLINEARSOLVER_HLS_TREEADD_PERIPH_BUS_ADDR_ISR, Mask);
}

u32 XLinearsolver_InterruptGetEnabled(XLinearsolver *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XLinearsolver_ReadReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XLINEARSOLVER_HLS_TREEADD_PERIPH_BUS_ADDR_IER);
}

u32 XLinearsolver_InterruptGetStatus(XLinearsolver *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    // Current Interrupt Clear Behavior is Clear on Read(COR).
    return XLinearsolver_ReadReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XLINEARSOLVER_HLS_TREEADD_PERIPH_BUS_ADDR_ISR);
}

