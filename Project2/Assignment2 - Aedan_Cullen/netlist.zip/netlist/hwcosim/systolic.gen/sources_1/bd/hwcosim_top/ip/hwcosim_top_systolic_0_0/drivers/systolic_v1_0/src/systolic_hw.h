/**
*
* @file systolic_hw.h
*
* This header file contains identifiers and driver functions (or
* macros) that can be used to access the device.  The user should refer to the
* hardware device specification for more details of the device operation.
*/ 
#define SYSTOLIC_WRAP_IN 0x0/**< wrap_in */
#define SYSTOLIC_ROW4_IN 0x4/**< row4_in */
#define SYSTOLIC_ROW3_IN 0x8/**< row3_in */
#define SYSTOLIC_ROW2_IN 0xc/**< row2_in */
#define SYSTOLIC_ROW1_IN 0x10/**< row1_in */
#define SYSTOLIC_COL4_IN 0x14/**< col4_in */
#define SYSTOLIC_COL3_IN 0x18/**< col3_in */
#define SYSTOLIC_COL2_IN 0x1c/**< col2_in */
#define SYSTOLIC_COL1_IN 0x20/**< col1_in */
#define SYSTOLIC_ROW1_OUT 0x24/**< row1_out */
#define SYSTOLIC_ROW2_OUT 0x28/**< row2_out */
#define SYSTOLIC_ROW3_OUT 0x2c/**< row3_out */
#define SYSTOLIC_ROW4_OUT 0x30/**< row4_out */
