#ifndef SYSTOLIC__H
#define SYSTOLIC__H
#ifdef __cplusplus
extern "C" {
#endif
/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "systolic_hw.h"
/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
#else
typedef struct {
    u16 DeviceId;
    u32 systolic_BaseAddress;
} systolic_Config;
#endif
/**
* The systolic driver instance data. The user is required to
* allocate a variable of this type for every systolic device in the system.
* A pointer to a variable of this type is then passed to the driver
* API functions.
*/
typedef struct {
    u32 systolic_BaseAddress;
    u32 IsReady;
} systolic;
/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define systolic_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define systolic_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define systolic_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define systolic_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif
/************************** Function Prototypes *****************************/
#ifndef __linux__
int systolic_Initialize(systolic *InstancePtr, u16 DeviceId);
systolic_Config* systolic_LookupConfig(u16 DeviceId);
int systolic_CfgInitialize(systolic *InstancePtr, systolic_Config *ConfigPtr);
#else
int systolic_Initialize(systolic *InstancePtr, const char* InstanceName);
int systolic_Release(systolic *InstancePtr);
#endif
/**
* Write to wrap_in gateway of systolic. Assignments are LSB-justified.
*
* @param	InstancePtr is the wrap_in instance to operate on.
* @param	Data is value to be written to gateway wrap_in.
*
* @return	None.
*
* @note    .
*
*/
void systolic_wrap_in_write(systolic *InstancePtr, u8 Data);
/**
* Read from wrap_in gateway of systolic. Assignments are LSB-justified.
*
* @param	InstancePtr is the wrap_in instance to operate on.
*
* @return	u8
*
* @note    .
*
*/
u8 systolic_wrap_in_read(systolic *InstancePtr);
/**
* Write to row4_in gateway of systolic. Assignments are LSB-justified.
*
* @param	InstancePtr is the row4_in instance to operate on.
* @param	Data is value to be written to gateway row4_in.
*
* @return	None.
*
* @note    .
*
*/
void systolic_row4_in_write(systolic *InstancePtr, int Data);
/**
* Read from row4_in gateway of systolic. Assignments are LSB-justified.
*
* @param	InstancePtr is the row4_in instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int systolic_row4_in_read(systolic *InstancePtr);
/**
* Write to row3_in gateway of systolic. Assignments are LSB-justified.
*
* @param	InstancePtr is the row3_in instance to operate on.
* @param	Data is value to be written to gateway row3_in.
*
* @return	None.
*
* @note    .
*
*/
void systolic_row3_in_write(systolic *InstancePtr, int Data);
/**
* Read from row3_in gateway of systolic. Assignments are LSB-justified.
*
* @param	InstancePtr is the row3_in instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int systolic_row3_in_read(systolic *InstancePtr);
/**
* Write to row2_in gateway of systolic. Assignments are LSB-justified.
*
* @param	InstancePtr is the row2_in instance to operate on.
* @param	Data is value to be written to gateway row2_in.
*
* @return	None.
*
* @note    .
*
*/
void systolic_row2_in_write(systolic *InstancePtr, int Data);
/**
* Read from row2_in gateway of systolic. Assignments are LSB-justified.
*
* @param	InstancePtr is the row2_in instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int systolic_row2_in_read(systolic *InstancePtr);
/**
* Write to row1_in gateway of systolic. Assignments are LSB-justified.
*
* @param	InstancePtr is the row1_in instance to operate on.
* @param	Data is value to be written to gateway row1_in.
*
* @return	None.
*
* @note    .
*
*/
void systolic_row1_in_write(systolic *InstancePtr, int Data);
/**
* Read from row1_in gateway of systolic. Assignments are LSB-justified.
*
* @param	InstancePtr is the row1_in instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int systolic_row1_in_read(systolic *InstancePtr);
/**
* Write to col4_in gateway of systolic. Assignments are LSB-justified.
*
* @param	InstancePtr is the col4_in instance to operate on.
* @param	Data is value to be written to gateway col4_in.
*
* @return	None.
*
* @note    .
*
*/
void systolic_col4_in_write(systolic *InstancePtr, int Data);
/**
* Read from col4_in gateway of systolic. Assignments are LSB-justified.
*
* @param	InstancePtr is the col4_in instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int systolic_col4_in_read(systolic *InstancePtr);
/**
* Write to col3_in gateway of systolic. Assignments are LSB-justified.
*
* @param	InstancePtr is the col3_in instance to operate on.
* @param	Data is value to be written to gateway col3_in.
*
* @return	None.
*
* @note    .
*
*/
void systolic_col3_in_write(systolic *InstancePtr, int Data);
/**
* Read from col3_in gateway of systolic. Assignments are LSB-justified.
*
* @param	InstancePtr is the col3_in instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int systolic_col3_in_read(systolic *InstancePtr);
/**
* Write to col2_in gateway of systolic. Assignments are LSB-justified.
*
* @param	InstancePtr is the col2_in instance to operate on.
* @param	Data is value to be written to gateway col2_in.
*
* @return	None.
*
* @note    .
*
*/
void systolic_col2_in_write(systolic *InstancePtr, int Data);
/**
* Read from col2_in gateway of systolic. Assignments are LSB-justified.
*
* @param	InstancePtr is the col2_in instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int systolic_col2_in_read(systolic *InstancePtr);
/**
* Write to col1_in gateway of systolic. Assignments are LSB-justified.
*
* @param	InstancePtr is the col1_in instance to operate on.
* @param	Data is value to be written to gateway col1_in.
*
* @return	None.
*
* @note    .
*
*/
void systolic_col1_in_write(systolic *InstancePtr, int Data);
/**
* Read from col1_in gateway of systolic. Assignments are LSB-justified.
*
* @param	InstancePtr is the col1_in instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int systolic_col1_in_read(systolic *InstancePtr);
/**
* Read from row1_out gateway of systolic. Assignments are LSB-justified.
*
* @param	InstancePtr is the row1_out instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int systolic_row1_out_read(systolic *InstancePtr);
/**
* Read from row2_out gateway of systolic. Assignments are LSB-justified.
*
* @param	InstancePtr is the row2_out instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int systolic_row2_out_read(systolic *InstancePtr);
/**
* Read from row3_out gateway of systolic. Assignments are LSB-justified.
*
* @param	InstancePtr is the row3_out instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int systolic_row3_out_read(systolic *InstancePtr);
/**
* Read from row4_out gateway of systolic. Assignments are LSB-justified.
*
* @param	InstancePtr is the row4_out instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int systolic_row4_out_read(systolic *InstancePtr);
#ifdef __cplusplus
}
#endif
#endif
