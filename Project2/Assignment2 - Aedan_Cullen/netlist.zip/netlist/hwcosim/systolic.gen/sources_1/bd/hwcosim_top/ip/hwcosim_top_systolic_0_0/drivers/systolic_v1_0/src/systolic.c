#include "systolic.h"
#ifndef __linux__
int systolic_CfgInitialize(systolic *InstancePtr, systolic_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->systolic_BaseAddress = ConfigPtr->systolic_BaseAddress;

    InstancePtr->IsReady = 1;
    return XST_SUCCESS;
}
#endif
void systolic_wrap_in_write(systolic *InstancePtr, u8 Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    systolic_WriteReg(InstancePtr->systolic_BaseAddress, 0, Data);
}
u8 systolic_wrap_in_read(systolic *InstancePtr) {

    u8 Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = systolic_ReadReg(InstancePtr->systolic_BaseAddress, 0);
    return Data;
}
void systolic_row4_in_write(systolic *InstancePtr, int Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    systolic_WriteReg(InstancePtr->systolic_BaseAddress, 4, Data);
}
int systolic_row4_in_read(systolic *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = systolic_ReadReg(InstancePtr->systolic_BaseAddress, 4);
    return Data;
}
void systolic_row3_in_write(systolic *InstancePtr, int Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    systolic_WriteReg(InstancePtr->systolic_BaseAddress, 8, Data);
}
int systolic_row3_in_read(systolic *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = systolic_ReadReg(InstancePtr->systolic_BaseAddress, 8);
    return Data;
}
void systolic_row2_in_write(systolic *InstancePtr, int Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    systolic_WriteReg(InstancePtr->systolic_BaseAddress, 12, Data);
}
int systolic_row2_in_read(systolic *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = systolic_ReadReg(InstancePtr->systolic_BaseAddress, 12);
    return Data;
}
void systolic_row1_in_write(systolic *InstancePtr, int Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    systolic_WriteReg(InstancePtr->systolic_BaseAddress, 16, Data);
}
int systolic_row1_in_read(systolic *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = systolic_ReadReg(InstancePtr->systolic_BaseAddress, 16);
    return Data;
}
void systolic_col4_in_write(systolic *InstancePtr, int Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    systolic_WriteReg(InstancePtr->systolic_BaseAddress, 20, Data);
}
int systolic_col4_in_read(systolic *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = systolic_ReadReg(InstancePtr->systolic_BaseAddress, 20);
    return Data;
}
void systolic_col3_in_write(systolic *InstancePtr, int Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    systolic_WriteReg(InstancePtr->systolic_BaseAddress, 24, Data);
}
int systolic_col3_in_read(systolic *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = systolic_ReadReg(InstancePtr->systolic_BaseAddress, 24);
    return Data;
}
void systolic_col2_in_write(systolic *InstancePtr, int Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    systolic_WriteReg(InstancePtr->systolic_BaseAddress, 28, Data);
}
int systolic_col2_in_read(systolic *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = systolic_ReadReg(InstancePtr->systolic_BaseAddress, 28);
    return Data;
}
void systolic_col1_in_write(systolic *InstancePtr, int Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    systolic_WriteReg(InstancePtr->systolic_BaseAddress, 32, Data);
}
int systolic_col1_in_read(systolic *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = systolic_ReadReg(InstancePtr->systolic_BaseAddress, 32);
    return Data;
}
int systolic_row1_out_read(systolic *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = systolic_ReadReg(InstancePtr->systolic_BaseAddress, 36);
    return Data;
}
int systolic_row2_out_read(systolic *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = systolic_ReadReg(InstancePtr->systolic_BaseAddress, 40);
    return Data;
}
int systolic_row3_out_read(systolic *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = systolic_ReadReg(InstancePtr->systolic_BaseAddress, 44);
    return Data;
}
int systolic_row4_out_read(systolic *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = systolic_ReadReg(InstancePtr->systolic_BaseAddress, 48);
    return Data;
}
