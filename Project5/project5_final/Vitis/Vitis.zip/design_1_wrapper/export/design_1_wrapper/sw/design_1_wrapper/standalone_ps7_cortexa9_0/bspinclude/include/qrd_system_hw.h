/**
*
* @file qrd_system_hw.h
*
* This header file contains identifiers and driver functions (or
* macros) that can be used to access the device.  The user should refer to the
* hardware device specification for more details of the device operation.
*/ 
#define QRD_SYSTEM_I_COL4_IN 0x0/**< i_col4_in */
#define QRD_SYSTEM_I_COL3_IN 0x4/**< i_col3_in */
#define QRD_SYSTEM_I_COL2_IN 0x8/**< i_col2_in */
#define QRD_SYSTEM_I_COL1_IN 0xc/**< i_col1_in */
#define QRD_SYSTEM_A_COL4_IN 0x10/**< a_col4_in */
#define QRD_SYSTEM_A_COL3_IN 0x14/**< a_col3_in */
#define QRD_SYSTEM_A_COL2_IN 0x18/**< a_col2_in */
#define QRD_SYSTEM_A_COL1_IN 0x1c/**< a_col1_in */
#define QRD_SYSTEM_Q_COL1_OUT 0x0/**< q_col1_out */
#define QRD_SYSTEM_Q_COL2_OUT 0x4/**< q_col2_out */
#define QRD_SYSTEM_Q_COL3_OUT 0x8/**< q_col3_out */
#define QRD_SYSTEM_Q_COL4_OUT 0xc/**< q_col4_out */
#define QRD_SYSTEM_R_ROW1_OUT 0x10/**< r_row1_out */
#define QRD_SYSTEM_R_ROW2_OUT 0x14/**< r_row2_out */
#define QRD_SYSTEM_R_ROW3_OUT 0x18/**< r_row3_out */
#define QRD_SYSTEM_R_ROW4_OUT 0x1c/**< r_row4_out */
#define QRD_SYSTEM_RST_IN 0x0/**< rst_in */
