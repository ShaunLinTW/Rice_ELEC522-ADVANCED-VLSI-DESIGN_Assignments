#ifndef QRD_SYSTEM__H
#define QRD_SYSTEM__H
#ifdef __cplusplus
extern "C" {
#endif
/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "qrd_system_hw.h"
/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
#else
typedef struct {
    u16 DeviceId;
    u32 qrd_system_a_input_BaseAddress;
    u32 qrd_system_qr_output_BaseAddress;
    u32 qrd_system_signal_control_BaseAddress;
} qrd_system_Config;
#endif
/**
* The qrd_system driver instance data. The user is required to
* allocate a variable of this type for every qrd_system device in the system.
* A pointer to a variable of this type is then passed to the driver
* API functions.
*/
typedef struct {
    u32 qrd_system_a_input_BaseAddress;
    u32 qrd_system_qr_output_BaseAddress;
    u32 qrd_system_signal_control_BaseAddress;
    u32 IsReady;
} qrd_system;
/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define qrd_system_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define qrd_system_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define qrd_system_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define qrd_system_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif
/************************** Function Prototypes *****************************/
#ifndef __linux__
int qrd_system_Initialize(qrd_system *InstancePtr, u16 DeviceId);
qrd_system_Config* qrd_system_LookupConfig(u16 DeviceId);
int qrd_system_CfgInitialize(qrd_system *InstancePtr, qrd_system_Config *ConfigPtr);
#else
int qrd_system_Initialize(qrd_system *InstancePtr, const char* InstanceName);
int qrd_system_Release(qrd_system *InstancePtr);
#endif
/**
* Write to i_col4_in gateway of qrd_system. Assignments are LSB-justified.
*
* @param	InstancePtr is the i_col4_in instance to operate on.
* @param	Data is value to be written to gateway i_col4_in.
*
* @return	None.
*
* @note    .
*
*/
void qrd_system_i_col4_in_write(qrd_system *InstancePtr, int Data);
/**
* Read from i_col4_in gateway of qrd_system. Assignments are LSB-justified.
*
* @param	InstancePtr is the i_col4_in instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int qrd_system_i_col4_in_read(qrd_system *InstancePtr);
/**
* Write to i_col3_in gateway of qrd_system. Assignments are LSB-justified.
*
* @param	InstancePtr is the i_col3_in instance to operate on.
* @param	Data is value to be written to gateway i_col3_in.
*
* @return	None.
*
* @note    .
*
*/
void qrd_system_i_col3_in_write(qrd_system *InstancePtr, int Data);
/**
* Read from i_col3_in gateway of qrd_system. Assignments are LSB-justified.
*
* @param	InstancePtr is the i_col3_in instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int qrd_system_i_col3_in_read(qrd_system *InstancePtr);
/**
* Write to i_col2_in gateway of qrd_system. Assignments are LSB-justified.
*
* @param	InstancePtr is the i_col2_in instance to operate on.
* @param	Data is value to be written to gateway i_col2_in.
*
* @return	None.
*
* @note    .
*
*/
void qrd_system_i_col2_in_write(qrd_system *InstancePtr, int Data);
/**
* Read from i_col2_in gateway of qrd_system. Assignments are LSB-justified.
*
* @param	InstancePtr is the i_col2_in instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int qrd_system_i_col2_in_read(qrd_system *InstancePtr);
/**
* Write to i_col1_in gateway of qrd_system. Assignments are LSB-justified.
*
* @param	InstancePtr is the i_col1_in instance to operate on.
* @param	Data is value to be written to gateway i_col1_in.
*
* @return	None.
*
* @note    .
*
*/
void qrd_system_i_col1_in_write(qrd_system *InstancePtr, int Data);
/**
* Read from i_col1_in gateway of qrd_system. Assignments are LSB-justified.
*
* @param	InstancePtr is the i_col1_in instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int qrd_system_i_col1_in_read(qrd_system *InstancePtr);
/**
* Write to a_col4_in gateway of qrd_system. Assignments are LSB-justified.
*
* @param	InstancePtr is the a_col4_in instance to operate on.
* @param	Data is value to be written to gateway a_col4_in.
*
* @return	None.
*
* @note    .
*
*/
void qrd_system_a_col4_in_write(qrd_system *InstancePtr, int Data);
/**
* Read from a_col4_in gateway of qrd_system. Assignments are LSB-justified.
*
* @param	InstancePtr is the a_col4_in instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int qrd_system_a_col4_in_read(qrd_system *InstancePtr);
/**
* Write to a_col3_in gateway of qrd_system. Assignments are LSB-justified.
*
* @param	InstancePtr is the a_col3_in instance to operate on.
* @param	Data is value to be written to gateway a_col3_in.
*
* @return	None.
*
* @note    .
*
*/
void qrd_system_a_col3_in_write(qrd_system *InstancePtr, int Data);
/**
* Read from a_col3_in gateway of qrd_system. Assignments are LSB-justified.
*
* @param	InstancePtr is the a_col3_in instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int qrd_system_a_col3_in_read(qrd_system *InstancePtr);
/**
* Write to a_col2_in gateway of qrd_system. Assignments are LSB-justified.
*
* @param	InstancePtr is the a_col2_in instance to operate on.
* @param	Data is value to be written to gateway a_col2_in.
*
* @return	None.
*
* @note    .
*
*/
void qrd_system_a_col2_in_write(qrd_system *InstancePtr, int Data);
/**
* Read from a_col2_in gateway of qrd_system. Assignments are LSB-justified.
*
* @param	InstancePtr is the a_col2_in instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int qrd_system_a_col2_in_read(qrd_system *InstancePtr);
/**
* Write to a_col1_in gateway of qrd_system. Assignments are LSB-justified.
*
* @param	InstancePtr is the a_col1_in instance to operate on.
* @param	Data is value to be written to gateway a_col1_in.
*
* @return	None.
*
* @note    .
*
*/
void qrd_system_a_col1_in_write(qrd_system *InstancePtr, int Data);
/**
* Read from a_col1_in gateway of qrd_system. Assignments are LSB-justified.
*
* @param	InstancePtr is the a_col1_in instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int qrd_system_a_col1_in_read(qrd_system *InstancePtr);
/**
* Read from q_col1_out gateway of qrd_system. Assignments are LSB-justified.
*
* @param	InstancePtr is the q_col1_out instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int qrd_system_q_col1_out_read(qrd_system *InstancePtr);
/**
* Read from q_col2_out gateway of qrd_system. Assignments are LSB-justified.
*
* @param	InstancePtr is the q_col2_out instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int qrd_system_q_col2_out_read(qrd_system *InstancePtr);
/**
* Read from q_col3_out gateway of qrd_system. Assignments are LSB-justified.
*
* @param	InstancePtr is the q_col3_out instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int qrd_system_q_col3_out_read(qrd_system *InstancePtr);
/**
* Read from q_col4_out gateway of qrd_system. Assignments are LSB-justified.
*
* @param	InstancePtr is the q_col4_out instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int qrd_system_q_col4_out_read(qrd_system *InstancePtr);
/**
* Read from r_row1_out gateway of qrd_system. Assignments are LSB-justified.
*
* @param	InstancePtr is the r_row1_out instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int qrd_system_r_row1_out_read(qrd_system *InstancePtr);
/**
* Read from r_row2_out gateway of qrd_system. Assignments are LSB-justified.
*
* @param	InstancePtr is the r_row2_out instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int qrd_system_r_row2_out_read(qrd_system *InstancePtr);
/**
* Read from r_row3_out gateway of qrd_system. Assignments are LSB-justified.
*
* @param	InstancePtr is the r_row3_out instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int qrd_system_r_row3_out_read(qrd_system *InstancePtr);
/**
* Read from r_row4_out gateway of qrd_system. Assignments are LSB-justified.
*
* @param	InstancePtr is the r_row4_out instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int qrd_system_r_row4_out_read(qrd_system *InstancePtr);
/**
* Write to rst_in gateway of qrd_system. Assignments are LSB-justified.
*
* @param	InstancePtr is the rst_in instance to operate on.
* @param	Data is value to be written to gateway rst_in.
*
* @return	None.
*
* @note    .
*
*/
void qrd_system_rst_in_write(qrd_system *InstancePtr, u32 Data);
/**
* Read from rst_in gateway of qrd_system. Assignments are LSB-justified.
*
* @param	InstancePtr is the rst_in instance to operate on.
*
* @return	u32
*
* @note    .
*
*/
u32 qrd_system_rst_in_read(qrd_system *InstancePtr);
#ifdef __cplusplus
}
#endif
#endif
