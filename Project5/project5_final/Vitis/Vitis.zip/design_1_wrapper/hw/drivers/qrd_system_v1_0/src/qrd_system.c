#include "qrd_system.h"
#ifndef __linux__
int qrd_system_CfgInitialize(qrd_system *InstancePtr, qrd_system_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->qrd_system_a_input_BaseAddress = ConfigPtr->qrd_system_a_input_BaseAddress;
    InstancePtr->qrd_system_qr_output_BaseAddress = ConfigPtr->qrd_system_qr_output_BaseAddress;
    InstancePtr->qrd_system_signal_control_BaseAddress = ConfigPtr->qrd_system_signal_control_BaseAddress;

    InstancePtr->IsReady = 1;
    return XST_SUCCESS;
}
#endif
void qrd_system_i_col4_in_write(qrd_system *InstancePtr, int Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    qrd_system_WriteReg(InstancePtr->qrd_system_a_input_BaseAddress, 0, Data);
}
int qrd_system_i_col4_in_read(qrd_system *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = qrd_system_ReadReg(InstancePtr->qrd_system_a_input_BaseAddress, 0);
    return Data;
}
void qrd_system_i_col3_in_write(qrd_system *InstancePtr, int Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    qrd_system_WriteReg(InstancePtr->qrd_system_a_input_BaseAddress, 4, Data);
}
int qrd_system_i_col3_in_read(qrd_system *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = qrd_system_ReadReg(InstancePtr->qrd_system_a_input_BaseAddress, 4);
    return Data;
}
void qrd_system_i_col2_in_write(qrd_system *InstancePtr, int Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    qrd_system_WriteReg(InstancePtr->qrd_system_a_input_BaseAddress, 8, Data);
}
int qrd_system_i_col2_in_read(qrd_system *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = qrd_system_ReadReg(InstancePtr->qrd_system_a_input_BaseAddress, 8);
    return Data;
}
void qrd_system_i_col1_in_write(qrd_system *InstancePtr, int Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    qrd_system_WriteReg(InstancePtr->qrd_system_a_input_BaseAddress, 12, Data);
}
int qrd_system_i_col1_in_read(qrd_system *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = qrd_system_ReadReg(InstancePtr->qrd_system_a_input_BaseAddress, 12);
    return Data;
}
void qrd_system_a_col4_in_write(qrd_system *InstancePtr, int Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    qrd_system_WriteReg(InstancePtr->qrd_system_a_input_BaseAddress, 16, Data);
}
int qrd_system_a_col4_in_read(qrd_system *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = qrd_system_ReadReg(InstancePtr->qrd_system_a_input_BaseAddress, 16);
    return Data;
}
void qrd_system_a_col3_in_write(qrd_system *InstancePtr, int Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    qrd_system_WriteReg(InstancePtr->qrd_system_a_input_BaseAddress, 20, Data);
}
int qrd_system_a_col3_in_read(qrd_system *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = qrd_system_ReadReg(InstancePtr->qrd_system_a_input_BaseAddress, 20);
    return Data;
}
void qrd_system_a_col2_in_write(qrd_system *InstancePtr, int Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    qrd_system_WriteReg(InstancePtr->qrd_system_a_input_BaseAddress, 24, Data);
}
int qrd_system_a_col2_in_read(qrd_system *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = qrd_system_ReadReg(InstancePtr->qrd_system_a_input_BaseAddress, 24);
    return Data;
}
void qrd_system_a_col1_in_write(qrd_system *InstancePtr, int Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    qrd_system_WriteReg(InstancePtr->qrd_system_a_input_BaseAddress, 28, Data);
}
int qrd_system_a_col1_in_read(qrd_system *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = qrd_system_ReadReg(InstancePtr->qrd_system_a_input_BaseAddress, 28);
    return Data;
}
int qrd_system_q_col1_out_read(qrd_system *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = qrd_system_ReadReg(InstancePtr->qrd_system_qr_output_BaseAddress, 0);
    return Data;
}
int qrd_system_q_col2_out_read(qrd_system *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = qrd_system_ReadReg(InstancePtr->qrd_system_qr_output_BaseAddress, 4);
    return Data;
}
int qrd_system_q_col3_out_read(qrd_system *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = qrd_system_ReadReg(InstancePtr->qrd_system_qr_output_BaseAddress, 8);
    return Data;
}
int qrd_system_q_col4_out_read(qrd_system *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = qrd_system_ReadReg(InstancePtr->qrd_system_qr_output_BaseAddress, 12);
    return Data;
}
int qrd_system_r_row1_out_read(qrd_system *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = qrd_system_ReadReg(InstancePtr->qrd_system_qr_output_BaseAddress, 16);
    return Data;
}
int qrd_system_r_row2_out_read(qrd_system *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = qrd_system_ReadReg(InstancePtr->qrd_system_qr_output_BaseAddress, 20);
    return Data;
}
int qrd_system_r_row3_out_read(qrd_system *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = qrd_system_ReadReg(InstancePtr->qrd_system_qr_output_BaseAddress, 24);
    return Data;
}
int qrd_system_r_row4_out_read(qrd_system *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = qrd_system_ReadReg(InstancePtr->qrd_system_qr_output_BaseAddress, 28);
    return Data;
}
void qrd_system_rst_in_write(qrd_system *InstancePtr, u32 Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    qrd_system_WriteReg(InstancePtr->qrd_system_signal_control_BaseAddress, 0, Data);
}
u32 qrd_system_rst_in_read(qrd_system *InstancePtr) {

    u32 Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = qrd_system_ReadReg(InstancePtr->qrd_system_signal_control_BaseAddress, 0);
    return Data;
}
