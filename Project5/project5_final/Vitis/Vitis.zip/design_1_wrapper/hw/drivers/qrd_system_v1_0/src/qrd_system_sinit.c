/**
* @file qrd_system_sinit.c
*
* The implementation of the qrd_system driver's static initialzation
* functionality.
*
* @note
*
* None
*
*/
#ifndef __linux__
#include "xstatus.h"
#include "xparameters.h"
#include "qrd_system.h"
extern qrd_system_Config qrd_system_ConfigTable[];
/**
* Lookup the device configuration based on the unique device ID.  The table
* ConfigTable contains the configuration info for each device in the system.
*
* @param DeviceId is the device identifier to lookup.
*
* @return
*     - A pointer of data type qrd_system_Config which
*    points to the device configuration if DeviceID is found.
*    - NULL if DeviceID is not found.
*
* @note    None.
*
*/
qrd_system_Config *qrd_system_LookupConfig(u16 DeviceId) {
    qrd_system_Config *ConfigPtr = NULL;
    int Index;
    for (Index = 0; Index < XPAR_QRD_SYSTEM_NUM_INSTANCES; Index++) {
        if (qrd_system_ConfigTable[Index].DeviceId == DeviceId) {
            ConfigPtr = &qrd_system_ConfigTable[Index];
            break;
        }
    }
    return ConfigPtr;
}
int qrd_system_Initialize(qrd_system *InstancePtr, u16 DeviceId) {
    qrd_system_Config *ConfigPtr;
    Xil_AssertNonvoid(InstancePtr != NULL);
    ConfigPtr = qrd_system_LookupConfig(DeviceId);
    if (ConfigPtr == NULL) {
        InstancePtr->IsReady = 0;
        return (XST_DEVICE_NOT_FOUND);
    }
    return qrd_system_CfgInitialize(InstancePtr, ConfigPtr);
}
#endif
