// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2022.1 (64-bit)
// Tool Version Limit: 2022.04
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// ==============================================================
// HLS_TREEADD_PERIPH_BUS
// 0x000 : Control signals
//         bit 0  - ap_start (Read/Write/COH)
//         bit 1  - ap_done (Read/COR)
//         bit 2  - ap_idle (Read)
//         bit 3  - ap_ready (Read/COR)
//         bit 7  - auto_restart (Read/Write)
//         bit 9  - interrupt (Read)
//         others - reserved
// 0x004 : Global Interrupt Enable Register
//         bit 0  - Global Interrupt Enable (Read/Write)
//         others - reserved
// 0x008 : IP Interrupt Enable Register (Read/Write)
//         bit 0 - enable ap_done interrupt (Read/Write)
//         bit 1 - enable ap_ready interrupt (Read/Write)
//         others - reserved
// 0x00c : IP Interrupt Status Register (Read/COR)
//         bit 0 - ap_done (Read/COR)
//         bit 1 - ap_ready (Read/COR)
//         others - reserved
// 0x010 : Data signal of a11
//         bit 23~0 - a11[23:0] (Read/Write)
//         others   - reserved
// 0x014 : reserved
// 0x018 : Data signal of a12
//         bit 23~0 - a12[23:0] (Read/Write)
//         others   - reserved
// 0x01c : reserved
// 0x020 : Data signal of a13
//         bit 23~0 - a13[23:0] (Read/Write)
//         others   - reserved
// 0x024 : reserved
// 0x028 : Data signal of a14
//         bit 23~0 - a14[23:0] (Read/Write)
//         others   - reserved
// 0x02c : reserved
// 0x030 : Data signal of a21
//         bit 23~0 - a21[23:0] (Read/Write)
//         others   - reserved
// 0x034 : reserved
// 0x038 : Data signal of a22
//         bit 23~0 - a22[23:0] (Read/Write)
//         others   - reserved
// 0x03c : reserved
// 0x040 : Data signal of a23
//         bit 23~0 - a23[23:0] (Read/Write)
//         others   - reserved
// 0x044 : reserved
// 0x048 : Data signal of a24
//         bit 23~0 - a24[23:0] (Read/Write)
//         others   - reserved
// 0x04c : reserved
// 0x050 : Data signal of a31
//         bit 23~0 - a31[23:0] (Read/Write)
//         others   - reserved
// 0x054 : reserved
// 0x058 : Data signal of a32
//         bit 23~0 - a32[23:0] (Read/Write)
//         others   - reserved
// 0x05c : reserved
// 0x060 : Data signal of a33
//         bit 23~0 - a33[23:0] (Read/Write)
//         others   - reserved
// 0x064 : reserved
// 0x068 : Data signal of a34
//         bit 23~0 - a34[23:0] (Read/Write)
//         others   - reserved
// 0x06c : reserved
// 0x070 : Data signal of a41
//         bit 23~0 - a41[23:0] (Read/Write)
//         others   - reserved
// 0x074 : reserved
// 0x078 : Data signal of a42
//         bit 23~0 - a42[23:0] (Read/Write)
//         others   - reserved
// 0x07c : reserved
// 0x080 : Data signal of a43
//         bit 23~0 - a43[23:0] (Read/Write)
//         others   - reserved
// 0x084 : reserved
// 0x088 : Data signal of a44
//         bit 23~0 - a44[23:0] (Read/Write)
//         others   - reserved
// 0x08c : reserved
// 0x090 : Data signal of q11
//         bit 23~0 - q11[23:0] (Read)
//         others   - reserved
// 0x094 : Control signal of q11
//         bit 0  - q11_ap_vld (Read/COR)
//         others - reserved
// 0x0a0 : Data signal of q12
//         bit 23~0 - q12[23:0] (Read)
//         others   - reserved
// 0x0a4 : Control signal of q12
//         bit 0  - q12_ap_vld (Read/COR)
//         others - reserved
// 0x0b0 : Data signal of q13
//         bit 23~0 - q13[23:0] (Read)
//         others   - reserved
// 0x0b4 : Control signal of q13
//         bit 0  - q13_ap_vld (Read/COR)
//         others - reserved
// 0x0c0 : Data signal of q14
//         bit 23~0 - q14[23:0] (Read)
//         others   - reserved
// 0x0c4 : Control signal of q14
//         bit 0  - q14_ap_vld (Read/COR)
//         others - reserved
// 0x0d0 : Data signal of q21
//         bit 23~0 - q21[23:0] (Read)
//         others   - reserved
// 0x0d4 : Control signal of q21
//         bit 0  - q21_ap_vld (Read/COR)
//         others - reserved
// 0x0e0 : Data signal of q22
//         bit 23~0 - q22[23:0] (Read)
//         others   - reserved
// 0x0e4 : Control signal of q22
//         bit 0  - q22_ap_vld (Read/COR)
//         others - reserved
// 0x0f0 : Data signal of q23
//         bit 23~0 - q23[23:0] (Read)
//         others   - reserved
// 0x0f4 : Control signal of q23
//         bit 0  - q23_ap_vld (Read/COR)
//         others - reserved
// 0x100 : Data signal of q24
//         bit 23~0 - q24[23:0] (Read)
//         others   - reserved
// 0x104 : Control signal of q24
//         bit 0  - q24_ap_vld (Read/COR)
//         others - reserved
// 0x110 : Data signal of q31
//         bit 23~0 - q31[23:0] (Read)
//         others   - reserved
// 0x114 : Control signal of q31
//         bit 0  - q31_ap_vld (Read/COR)
//         others - reserved
// 0x120 : Data signal of q32
//         bit 23~0 - q32[23:0] (Read)
//         others   - reserved
// 0x124 : Control signal of q32
//         bit 0  - q32_ap_vld (Read/COR)
//         others - reserved
// 0x130 : Data signal of q33
//         bit 23~0 - q33[23:0] (Read)
//         others   - reserved
// 0x134 : Control signal of q33
//         bit 0  - q33_ap_vld (Read/COR)
//         others - reserved
// 0x140 : Data signal of q34
//         bit 23~0 - q34[23:0] (Read)
//         others   - reserved
// 0x144 : Control signal of q34
//         bit 0  - q34_ap_vld (Read/COR)
//         others - reserved
// 0x150 : Data signal of q41
//         bit 23~0 - q41[23:0] (Read)
//         others   - reserved
// 0x154 : Control signal of q41
//         bit 0  - q41_ap_vld (Read/COR)
//         others - reserved
// 0x160 : Data signal of q42
//         bit 23~0 - q42[23:0] (Read)
//         others   - reserved
// 0x164 : Control signal of q42
//         bit 0  - q42_ap_vld (Read/COR)
//         others - reserved
// 0x170 : Data signal of q43
//         bit 23~0 - q43[23:0] (Read)
//         others   - reserved
// 0x174 : Control signal of q43
//         bit 0  - q43_ap_vld (Read/COR)
//         others - reserved
// 0x180 : Data signal of q44
//         bit 23~0 - q44[23:0] (Read)
//         others   - reserved
// 0x184 : Control signal of q44
//         bit 0  - q44_ap_vld (Read/COR)
//         others - reserved
// 0x190 : Data signal of r11
//         bit 23~0 - r11[23:0] (Read)
//         others   - reserved
// 0x194 : Control signal of r11
//         bit 0  - r11_ap_vld (Read/COR)
//         others - reserved
// 0x1a0 : Data signal of r12
//         bit 23~0 - r12[23:0] (Read)
//         others   - reserved
// 0x1a4 : Control signal of r12
//         bit 0  - r12_ap_vld (Read/COR)
//         others - reserved
// 0x1b0 : Data signal of r13
//         bit 23~0 - r13[23:0] (Read)
//         others   - reserved
// 0x1b4 : Control signal of r13
//         bit 0  - r13_ap_vld (Read/COR)
//         others - reserved
// 0x1c0 : Data signal of r14
//         bit 23~0 - r14[23:0] (Read)
//         others   - reserved
// 0x1c4 : Control signal of r14
//         bit 0  - r14_ap_vld (Read/COR)
//         others - reserved
// 0x1d0 : Data signal of r22
//         bit 23~0 - r22[23:0] (Read)
//         others   - reserved
// 0x1d4 : Control signal of r22
//         bit 0  - r22_ap_vld (Read/COR)
//         others - reserved
// 0x1e0 : Data signal of r23
//         bit 23~0 - r23[23:0] (Read)
//         others   - reserved
// 0x1e4 : Control signal of r23
//         bit 0  - r23_ap_vld (Read/COR)
//         others - reserved
// 0x1f0 : Data signal of r24
//         bit 23~0 - r24[23:0] (Read)
//         others   - reserved
// 0x1f4 : Control signal of r24
//         bit 0  - r24_ap_vld (Read/COR)
//         others - reserved
// 0x200 : Data signal of r33
//         bit 23~0 - r33[23:0] (Read)
//         others   - reserved
// 0x204 : Control signal of r33
//         bit 0  - r33_ap_vld (Read/COR)
//         others - reserved
// 0x210 : Data signal of r34
//         bit 23~0 - r34[23:0] (Read)
//         others   - reserved
// 0x214 : Control signal of r34
//         bit 0  - r34_ap_vld (Read/COR)
//         others - reserved
// 0x220 : Data signal of r44
//         bit 23~0 - r44[23:0] (Read)
//         others   - reserved
// 0x224 : Control signal of r44
//         bit 0  - r44_ap_vld (Read/COR)
//         others - reserved
// 0x230 : Data signal of din
//         bit 23~0 - din[23:0] (Read/Write)
//         others   - reserved
// 0x234 : reserved
// 0x238 : Data signal of done
//         bit 23~0 - done[23:0] (Read)
//         others   - reserved
// 0x23c : Control signal of done
//         bit 0  - done_ap_vld (Read/COR)
//         others - reserved
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XQR_HLS_TREEADD_PERIPH_BUS_ADDR_AP_CTRL   0x000
#define XQR_HLS_TREEADD_PERIPH_BUS_ADDR_GIE       0x004
#define XQR_HLS_TREEADD_PERIPH_BUS_ADDR_IER       0x008
#define XQR_HLS_TREEADD_PERIPH_BUS_ADDR_ISR       0x00c
#define XQR_HLS_TREEADD_PERIPH_BUS_ADDR_A11_DATA  0x010
#define XQR_HLS_TREEADD_PERIPH_BUS_BITS_A11_DATA  24
#define XQR_HLS_TREEADD_PERIPH_BUS_ADDR_A12_DATA  0x018
#define XQR_HLS_TREEADD_PERIPH_BUS_BITS_A12_DATA  24
#define XQR_HLS_TREEADD_PERIPH_BUS_ADDR_A13_DATA  0x020
#define XQR_HLS_TREEADD_PERIPH_BUS_BITS_A13_DATA  24
#define XQR_HLS_TREEADD_PERIPH_BUS_ADDR_A14_DATA  0x028
#define XQR_HLS_TREEADD_PERIPH_BUS_BITS_A14_DATA  24
#define XQR_HLS_TREEADD_PERIPH_BUS_ADDR_A21_DATA  0x030
#define XQR_HLS_TREEADD_PERIPH_BUS_BITS_A21_DATA  24
#define XQR_HLS_TREEADD_PERIPH_BUS_ADDR_A22_DATA  0x038
#define XQR_HLS_TREEADD_PERIPH_BUS_BITS_A22_DATA  24
#define XQR_HLS_TREEADD_PERIPH_BUS_ADDR_A23_DATA  0x040
#define XQR_HLS_TREEADD_PERIPH_BUS_BITS_A23_DATA  24
#define XQR_HLS_TREEADD_PERIPH_BUS_ADDR_A24_DATA  0x048
#define XQR_HLS_TREEADD_PERIPH_BUS_BITS_A24_DATA  24
#define XQR_HLS_TREEADD_PERIPH_BUS_ADDR_A31_DATA  0x050
#define XQR_HLS_TREEADD_PERIPH_BUS_BITS_A31_DATA  24
#define XQR_HLS_TREEADD_PERIPH_BUS_ADDR_A32_DATA  0x058
#define XQR_HLS_TREEADD_PERIPH_BUS_BITS_A32_DATA  24
#define XQR_HLS_TREEADD_PERIPH_BUS_ADDR_A33_DATA  0x060
#define XQR_HLS_TREEADD_PERIPH_BUS_BITS_A33_DATA  24
#define XQR_HLS_TREEADD_PERIPH_BUS_ADDR_A34_DATA  0x068
#define XQR_HLS_TREEADD_PERIPH_BUS_BITS_A34_DATA  24
#define XQR_HLS_TREEADD_PERIPH_BUS_ADDR_A41_DATA  0x070
#define XQR_HLS_TREEADD_PERIPH_BUS_BITS_A41_DATA  24
#define XQR_HLS_TREEADD_PERIPH_BUS_ADDR_A42_DATA  0x078
#define XQR_HLS_TREEADD_PERIPH_BUS_BITS_A42_DATA  24
#define XQR_HLS_TREEADD_PERIPH_BUS_ADDR_A43_DATA  0x080
#define XQR_HLS_TREEADD_PERIPH_BUS_BITS_A43_DATA  24
#define XQR_HLS_TREEADD_PERIPH_BUS_ADDR_A44_DATA  0x088
#define XQR_HLS_TREEADD_PERIPH_BUS_BITS_A44_DATA  24
#define XQR_HLS_TREEADD_PERIPH_BUS_ADDR_Q11_DATA  0x090
#define XQR_HLS_TREEADD_PERIPH_BUS_BITS_Q11_DATA  24
#define XQR_HLS_TREEADD_PERIPH_BUS_ADDR_Q11_CTRL  0x094
#define XQR_HLS_TREEADD_PERIPH_BUS_ADDR_Q12_DATA  0x0a0
#define XQR_HLS_TREEADD_PERIPH_BUS_BITS_Q12_DATA  24
#define XQR_HLS_TREEADD_PERIPH_BUS_ADDR_Q12_CTRL  0x0a4
#define XQR_HLS_TREEADD_PERIPH_BUS_ADDR_Q13_DATA  0x0b0
#define XQR_HLS_TREEADD_PERIPH_BUS_BITS_Q13_DATA  24
#define XQR_HLS_TREEADD_PERIPH_BUS_ADDR_Q13_CTRL  0x0b4
#define XQR_HLS_TREEADD_PERIPH_BUS_ADDR_Q14_DATA  0x0c0
#define XQR_HLS_TREEADD_PERIPH_BUS_BITS_Q14_DATA  24
#define XQR_HLS_TREEADD_PERIPH_BUS_ADDR_Q14_CTRL  0x0c4
#define XQR_HLS_TREEADD_PERIPH_BUS_ADDR_Q21_DATA  0x0d0
#define XQR_HLS_TREEADD_PERIPH_BUS_BITS_Q21_DATA  24
#define XQR_HLS_TREEADD_PERIPH_BUS_ADDR_Q21_CTRL  0x0d4
#define XQR_HLS_TREEADD_PERIPH_BUS_ADDR_Q22_DATA  0x0e0
#define XQR_HLS_TREEADD_PERIPH_BUS_BITS_Q22_DATA  24
#define XQR_HLS_TREEADD_PERIPH_BUS_ADDR_Q22_CTRL  0x0e4
#define XQR_HLS_TREEADD_PERIPH_BUS_ADDR_Q23_DATA  0x0f0
#define XQR_HLS_TREEADD_PERIPH_BUS_BITS_Q23_DATA  24
#define XQR_HLS_TREEADD_PERIPH_BUS_ADDR_Q23_CTRL  0x0f4
#define XQR_HLS_TREEADD_PERIPH_BUS_ADDR_Q24_DATA  0x100
#define XQR_HLS_TREEADD_PERIPH_BUS_BITS_Q24_DATA  24
#define XQR_HLS_TREEADD_PERIPH_BUS_ADDR_Q24_CTRL  0x104
#define XQR_HLS_TREEADD_PERIPH_BUS_ADDR_Q31_DATA  0x110
#define XQR_HLS_TREEADD_PERIPH_BUS_BITS_Q31_DATA  24
#define XQR_HLS_TREEADD_PERIPH_BUS_ADDR_Q31_CTRL  0x114
#define XQR_HLS_TREEADD_PERIPH_BUS_ADDR_Q32_DATA  0x120
#define XQR_HLS_TREEADD_PERIPH_BUS_BITS_Q32_DATA  24
#define XQR_HLS_TREEADD_PERIPH_BUS_ADDR_Q32_CTRL  0x124
#define XQR_HLS_TREEADD_PERIPH_BUS_ADDR_Q33_DATA  0x130
#define XQR_HLS_TREEADD_PERIPH_BUS_BITS_Q33_DATA  24
#define XQR_HLS_TREEADD_PERIPH_BUS_ADDR_Q33_CTRL  0x134
#define XQR_HLS_TREEADD_PERIPH_BUS_ADDR_Q34_DATA  0x140
#define XQR_HLS_TREEADD_PERIPH_BUS_BITS_Q34_DATA  24
#define XQR_HLS_TREEADD_PERIPH_BUS_ADDR_Q34_CTRL  0x144
#define XQR_HLS_TREEADD_PERIPH_BUS_ADDR_Q41_DATA  0x150
#define XQR_HLS_TREEADD_PERIPH_BUS_BITS_Q41_DATA  24
#define XQR_HLS_TREEADD_PERIPH_BUS_ADDR_Q41_CTRL  0x154
#define XQR_HLS_TREEADD_PERIPH_BUS_ADDR_Q42_DATA  0x160
#define XQR_HLS_TREEADD_PERIPH_BUS_BITS_Q42_DATA  24
#define XQR_HLS_TREEADD_PERIPH_BUS_ADDR_Q42_CTRL  0x164
#define XQR_HLS_TREEADD_PERIPH_BUS_ADDR_Q43_DATA  0x170
#define XQR_HLS_TREEADD_PERIPH_BUS_BITS_Q43_DATA  24
#define XQR_HLS_TREEADD_PERIPH_BUS_ADDR_Q43_CTRL  0x174
#define XQR_HLS_TREEADD_PERIPH_BUS_ADDR_Q44_DATA  0x180
#define XQR_HLS_TREEADD_PERIPH_BUS_BITS_Q44_DATA  24
#define XQR_HLS_TREEADD_PERIPH_BUS_ADDR_Q44_CTRL  0x184
#define XQR_HLS_TREEADD_PERIPH_BUS_ADDR_R11_DATA  0x190
#define XQR_HLS_TREEADD_PERIPH_BUS_BITS_R11_DATA  24
#define XQR_HLS_TREEADD_PERIPH_BUS_ADDR_R11_CTRL  0x194
#define XQR_HLS_TREEADD_PERIPH_BUS_ADDR_R12_DATA  0x1a0
#define XQR_HLS_TREEADD_PERIPH_BUS_BITS_R12_DATA  24
#define XQR_HLS_TREEADD_PERIPH_BUS_ADDR_R12_CTRL  0x1a4
#define XQR_HLS_TREEADD_PERIPH_BUS_ADDR_R13_DATA  0x1b0
#define XQR_HLS_TREEADD_PERIPH_BUS_BITS_R13_DATA  24
#define XQR_HLS_TREEADD_PERIPH_BUS_ADDR_R13_CTRL  0x1b4
#define XQR_HLS_TREEADD_PERIPH_BUS_ADDR_R14_DATA  0x1c0
#define XQR_HLS_TREEADD_PERIPH_BUS_BITS_R14_DATA  24
#define XQR_HLS_TREEADD_PERIPH_BUS_ADDR_R14_CTRL  0x1c4
#define XQR_HLS_TREEADD_PERIPH_BUS_ADDR_R22_DATA  0x1d0
#define XQR_HLS_TREEADD_PERIPH_BUS_BITS_R22_DATA  24
#define XQR_HLS_TREEADD_PERIPH_BUS_ADDR_R22_CTRL  0x1d4
#define XQR_HLS_TREEADD_PERIPH_BUS_ADDR_R23_DATA  0x1e0
#define XQR_HLS_TREEADD_PERIPH_BUS_BITS_R23_DATA  24
#define XQR_HLS_TREEADD_PERIPH_BUS_ADDR_R23_CTRL  0x1e4
#define XQR_HLS_TREEADD_PERIPH_BUS_ADDR_R24_DATA  0x1f0
#define XQR_HLS_TREEADD_PERIPH_BUS_BITS_R24_DATA  24
#define XQR_HLS_TREEADD_PERIPH_BUS_ADDR_R24_CTRL  0x1f4
#define XQR_HLS_TREEADD_PERIPH_BUS_ADDR_R33_DATA  0x200
#define XQR_HLS_TREEADD_PERIPH_BUS_BITS_R33_DATA  24
#define XQR_HLS_TREEADD_PERIPH_BUS_ADDR_R33_CTRL  0x204
#define XQR_HLS_TREEADD_PERIPH_BUS_ADDR_R34_DATA  0x210
#define XQR_HLS_TREEADD_PERIPH_BUS_BITS_R34_DATA  24
#define XQR_HLS_TREEADD_PERIPH_BUS_ADDR_R34_CTRL  0x214
#define XQR_HLS_TREEADD_PERIPH_BUS_ADDR_R44_DATA  0x220
#define XQR_HLS_TREEADD_PERIPH_BUS_BITS_R44_DATA  24
#define XQR_HLS_TREEADD_PERIPH_BUS_ADDR_R44_CTRL  0x224
#define XQR_HLS_TREEADD_PERIPH_BUS_ADDR_DIN_DATA  0x230
#define XQR_HLS_TREEADD_PERIPH_BUS_BITS_DIN_DATA  24
#define XQR_HLS_TREEADD_PERIPH_BUS_ADDR_DONE_DATA 0x238
#define XQR_HLS_TREEADD_PERIPH_BUS_BITS_DONE_DATA 24
#define XQR_HLS_TREEADD_PERIPH_BUS_ADDR_DONE_CTRL 0x23c

