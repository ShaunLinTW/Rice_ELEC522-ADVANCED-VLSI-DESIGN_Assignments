// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2022.1 (64-bit)
// Tool Version Limit: 2022.04
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#include "xparameters.h"
#include "xqr.h"

extern XQr_Config XQr_ConfigTable[];

XQr_Config *XQr_LookupConfig(u16 DeviceId) {
	XQr_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XQR_NUM_INSTANCES; Index++) {
		if (XQr_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XQr_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XQr_Initialize(XQr *InstancePtr, u16 DeviceId) {
	XQr_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XQr_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XQr_CfgInitialize(InstancePtr, ConfigPtr);
}

#endif

