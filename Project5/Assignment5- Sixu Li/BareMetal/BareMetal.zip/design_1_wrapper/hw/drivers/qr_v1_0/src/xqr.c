// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2022.1 (64-bit)
// Tool Version Limit: 2022.04
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// ==============================================================
/***************************** Include Files *********************************/
#include "xqr.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XQr_CfgInitialize(XQr *InstancePtr, XQr_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Hls_treeadd_periph_bus_BaseAddress = ConfigPtr->Hls_treeadd_periph_bus_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XQr_Start(XQr *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XQr_ReadReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XQR_HLS_TREEADD_PERIPH_BUS_ADDR_AP_CTRL) & 0x80;
    XQr_WriteReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XQR_HLS_TREEADD_PERIPH_BUS_ADDR_AP_CTRL, Data | 0x01);
}

u32 XQr_IsDone(XQr *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XQr_ReadReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XQR_HLS_TREEADD_PERIPH_BUS_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XQr_IsIdle(XQr *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XQr_ReadReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XQR_HLS_TREEADD_PERIPH_BUS_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XQr_IsReady(XQr *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XQr_ReadReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XQR_HLS_TREEADD_PERIPH_BUS_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XQr_EnableAutoRestart(XQr *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XQr_WriteReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XQR_HLS_TREEADD_PERIPH_BUS_ADDR_AP_CTRL, 0x80);
}

void XQr_DisableAutoRestart(XQr *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XQr_WriteReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XQR_HLS_TREEADD_PERIPH_BUS_ADDR_AP_CTRL, 0);
}

void XQr_Set_a11(XQr *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XQr_WriteReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XQR_HLS_TREEADD_PERIPH_BUS_ADDR_A11_DATA, Data);
}

u32 XQr_Get_a11(XQr *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XQr_ReadReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XQR_HLS_TREEADD_PERIPH_BUS_ADDR_A11_DATA);
    return Data;
}

void XQr_Set_a12(XQr *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XQr_WriteReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XQR_HLS_TREEADD_PERIPH_BUS_ADDR_A12_DATA, Data);
}

u32 XQr_Get_a12(XQr *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XQr_ReadReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XQR_HLS_TREEADD_PERIPH_BUS_ADDR_A12_DATA);
    return Data;
}

void XQr_Set_a13(XQr *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XQr_WriteReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XQR_HLS_TREEADD_PERIPH_BUS_ADDR_A13_DATA, Data);
}

u32 XQr_Get_a13(XQr *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XQr_ReadReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XQR_HLS_TREEADD_PERIPH_BUS_ADDR_A13_DATA);
    return Data;
}

void XQr_Set_a14(XQr *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XQr_WriteReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XQR_HLS_TREEADD_PERIPH_BUS_ADDR_A14_DATA, Data);
}

u32 XQr_Get_a14(XQr *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XQr_ReadReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XQR_HLS_TREEADD_PERIPH_BUS_ADDR_A14_DATA);
    return Data;
}

void XQr_Set_a21(XQr *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XQr_WriteReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XQR_HLS_TREEADD_PERIPH_BUS_ADDR_A21_DATA, Data);
}

u32 XQr_Get_a21(XQr *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XQr_ReadReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XQR_HLS_TREEADD_PERIPH_BUS_ADDR_A21_DATA);
    return Data;
}

void XQr_Set_a22(XQr *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XQr_WriteReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XQR_HLS_TREEADD_PERIPH_BUS_ADDR_A22_DATA, Data);
}

u32 XQr_Get_a22(XQr *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XQr_ReadReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XQR_HLS_TREEADD_PERIPH_BUS_ADDR_A22_DATA);
    return Data;
}

void XQr_Set_a23(XQr *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XQr_WriteReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XQR_HLS_TREEADD_PERIPH_BUS_ADDR_A23_DATA, Data);
}

u32 XQr_Get_a23(XQr *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XQr_ReadReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XQR_HLS_TREEADD_PERIPH_BUS_ADDR_A23_DATA);
    return Data;
}

void XQr_Set_a24(XQr *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XQr_WriteReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XQR_HLS_TREEADD_PERIPH_BUS_ADDR_A24_DATA, Data);
}

u32 XQr_Get_a24(XQr *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XQr_ReadReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XQR_HLS_TREEADD_PERIPH_BUS_ADDR_A24_DATA);
    return Data;
}

void XQr_Set_a31(XQr *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XQr_WriteReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XQR_HLS_TREEADD_PERIPH_BUS_ADDR_A31_DATA, Data);
}

u32 XQr_Get_a31(XQr *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XQr_ReadReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XQR_HLS_TREEADD_PERIPH_BUS_ADDR_A31_DATA);
    return Data;
}

void XQr_Set_a32(XQr *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XQr_WriteReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XQR_HLS_TREEADD_PERIPH_BUS_ADDR_A32_DATA, Data);
}

u32 XQr_Get_a32(XQr *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XQr_ReadReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XQR_HLS_TREEADD_PERIPH_BUS_ADDR_A32_DATA);
    return Data;
}

void XQr_Set_a33(XQr *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XQr_WriteReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XQR_HLS_TREEADD_PERIPH_BUS_ADDR_A33_DATA, Data);
}

u32 XQr_Get_a33(XQr *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XQr_ReadReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XQR_HLS_TREEADD_PERIPH_BUS_ADDR_A33_DATA);
    return Data;
}

void XQr_Set_a34(XQr *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XQr_WriteReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XQR_HLS_TREEADD_PERIPH_BUS_ADDR_A34_DATA, Data);
}

u32 XQr_Get_a34(XQr *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XQr_ReadReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XQR_HLS_TREEADD_PERIPH_BUS_ADDR_A34_DATA);
    return Data;
}

void XQr_Set_a41(XQr *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XQr_WriteReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XQR_HLS_TREEADD_PERIPH_BUS_ADDR_A41_DATA, Data);
}

u32 XQr_Get_a41(XQr *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XQr_ReadReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XQR_HLS_TREEADD_PERIPH_BUS_ADDR_A41_DATA);
    return Data;
}

void XQr_Set_a42(XQr *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XQr_WriteReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XQR_HLS_TREEADD_PERIPH_BUS_ADDR_A42_DATA, Data);
}

u32 XQr_Get_a42(XQr *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XQr_ReadReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XQR_HLS_TREEADD_PERIPH_BUS_ADDR_A42_DATA);
    return Data;
}

void XQr_Set_a43(XQr *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XQr_WriteReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XQR_HLS_TREEADD_PERIPH_BUS_ADDR_A43_DATA, Data);
}

u32 XQr_Get_a43(XQr *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XQr_ReadReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XQR_HLS_TREEADD_PERIPH_BUS_ADDR_A43_DATA);
    return Data;
}

void XQr_Set_a44(XQr *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XQr_WriteReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XQR_HLS_TREEADD_PERIPH_BUS_ADDR_A44_DATA, Data);
}

u32 XQr_Get_a44(XQr *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XQr_ReadReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XQR_HLS_TREEADD_PERIPH_BUS_ADDR_A44_DATA);
    return Data;
}

u32 XQr_Get_q11(XQr *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XQr_ReadReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XQR_HLS_TREEADD_PERIPH_BUS_ADDR_Q11_DATA);
    return Data;
}

u32 XQr_Get_q11_vld(XQr *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XQr_ReadReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XQR_HLS_TREEADD_PERIPH_BUS_ADDR_Q11_CTRL);
    return Data & 0x1;
}

u32 XQr_Get_q12(XQr *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XQr_ReadReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XQR_HLS_TREEADD_PERIPH_BUS_ADDR_Q12_DATA);
    return Data;
}

u32 XQr_Get_q12_vld(XQr *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XQr_ReadReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XQR_HLS_TREEADD_PERIPH_BUS_ADDR_Q12_CTRL);
    return Data & 0x1;
}

u32 XQr_Get_q13(XQr *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XQr_ReadReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XQR_HLS_TREEADD_PERIPH_BUS_ADDR_Q13_DATA);
    return Data;
}

u32 XQr_Get_q13_vld(XQr *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XQr_ReadReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XQR_HLS_TREEADD_PERIPH_BUS_ADDR_Q13_CTRL);
    return Data & 0x1;
}

u32 XQr_Get_q14(XQr *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XQr_ReadReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XQR_HLS_TREEADD_PERIPH_BUS_ADDR_Q14_DATA);
    return Data;
}

u32 XQr_Get_q14_vld(XQr *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XQr_ReadReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XQR_HLS_TREEADD_PERIPH_BUS_ADDR_Q14_CTRL);
    return Data & 0x1;
}

u32 XQr_Get_q21(XQr *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XQr_ReadReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XQR_HLS_TREEADD_PERIPH_BUS_ADDR_Q21_DATA);
    return Data;
}

u32 XQr_Get_q21_vld(XQr *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XQr_ReadReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XQR_HLS_TREEADD_PERIPH_BUS_ADDR_Q21_CTRL);
    return Data & 0x1;
}

u32 XQr_Get_q22(XQr *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XQr_ReadReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XQR_HLS_TREEADD_PERIPH_BUS_ADDR_Q22_DATA);
    return Data;
}

u32 XQr_Get_q22_vld(XQr *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XQr_ReadReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XQR_HLS_TREEADD_PERIPH_BUS_ADDR_Q22_CTRL);
    return Data & 0x1;
}

u32 XQr_Get_q23(XQr *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XQr_ReadReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XQR_HLS_TREEADD_PERIPH_BUS_ADDR_Q23_DATA);
    return Data;
}

u32 XQr_Get_q23_vld(XQr *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XQr_ReadReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XQR_HLS_TREEADD_PERIPH_BUS_ADDR_Q23_CTRL);
    return Data & 0x1;
}

u32 XQr_Get_q24(XQr *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XQr_ReadReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XQR_HLS_TREEADD_PERIPH_BUS_ADDR_Q24_DATA);
    return Data;
}

u32 XQr_Get_q24_vld(XQr *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XQr_ReadReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XQR_HLS_TREEADD_PERIPH_BUS_ADDR_Q24_CTRL);
    return Data & 0x1;
}

u32 XQr_Get_q31(XQr *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XQr_ReadReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XQR_HLS_TREEADD_PERIPH_BUS_ADDR_Q31_DATA);
    return Data;
}

u32 XQr_Get_q31_vld(XQr *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XQr_ReadReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XQR_HLS_TREEADD_PERIPH_BUS_ADDR_Q31_CTRL);
    return Data & 0x1;
}

u32 XQr_Get_q32(XQr *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XQr_ReadReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XQR_HLS_TREEADD_PERIPH_BUS_ADDR_Q32_DATA);
    return Data;
}

u32 XQr_Get_q32_vld(XQr *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XQr_ReadReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XQR_HLS_TREEADD_PERIPH_BUS_ADDR_Q32_CTRL);
    return Data & 0x1;
}

u32 XQr_Get_q33(XQr *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XQr_ReadReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XQR_HLS_TREEADD_PERIPH_BUS_ADDR_Q33_DATA);
    return Data;
}

u32 XQr_Get_q33_vld(XQr *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XQr_ReadReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XQR_HLS_TREEADD_PERIPH_BUS_ADDR_Q33_CTRL);
    return Data & 0x1;
}

u32 XQr_Get_q34(XQr *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XQr_ReadReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XQR_HLS_TREEADD_PERIPH_BUS_ADDR_Q34_DATA);
    return Data;
}

u32 XQr_Get_q34_vld(XQr *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XQr_ReadReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XQR_HLS_TREEADD_PERIPH_BUS_ADDR_Q34_CTRL);
    return Data & 0x1;
}

u32 XQr_Get_q41(XQr *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XQr_ReadReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XQR_HLS_TREEADD_PERIPH_BUS_ADDR_Q41_DATA);
    return Data;
}

u32 XQr_Get_q41_vld(XQr *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XQr_ReadReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XQR_HLS_TREEADD_PERIPH_BUS_ADDR_Q41_CTRL);
    return Data & 0x1;
}

u32 XQr_Get_q42(XQr *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XQr_ReadReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XQR_HLS_TREEADD_PERIPH_BUS_ADDR_Q42_DATA);
    return Data;
}

u32 XQr_Get_q42_vld(XQr *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XQr_ReadReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XQR_HLS_TREEADD_PERIPH_BUS_ADDR_Q42_CTRL);
    return Data & 0x1;
}

u32 XQr_Get_q43(XQr *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XQr_ReadReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XQR_HLS_TREEADD_PERIPH_BUS_ADDR_Q43_DATA);
    return Data;
}

u32 XQr_Get_q43_vld(XQr *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XQr_ReadReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XQR_HLS_TREEADD_PERIPH_BUS_ADDR_Q43_CTRL);
    return Data & 0x1;
}

u32 XQr_Get_q44(XQr *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XQr_ReadReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XQR_HLS_TREEADD_PERIPH_BUS_ADDR_Q44_DATA);
    return Data;
}

u32 XQr_Get_q44_vld(XQr *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XQr_ReadReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XQR_HLS_TREEADD_PERIPH_BUS_ADDR_Q44_CTRL);
    return Data & 0x1;
}

u32 XQr_Get_r11(XQr *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XQr_ReadReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XQR_HLS_TREEADD_PERIPH_BUS_ADDR_R11_DATA);
    return Data;
}

u32 XQr_Get_r11_vld(XQr *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XQr_ReadReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XQR_HLS_TREEADD_PERIPH_BUS_ADDR_R11_CTRL);
    return Data & 0x1;
}

u32 XQr_Get_r12(XQr *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XQr_ReadReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XQR_HLS_TREEADD_PERIPH_BUS_ADDR_R12_DATA);
    return Data;
}

u32 XQr_Get_r12_vld(XQr *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XQr_ReadReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XQR_HLS_TREEADD_PERIPH_BUS_ADDR_R12_CTRL);
    return Data & 0x1;
}

u32 XQr_Get_r13(XQr *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XQr_ReadReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XQR_HLS_TREEADD_PERIPH_BUS_ADDR_R13_DATA);
    return Data;
}

u32 XQr_Get_r13_vld(XQr *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XQr_ReadReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XQR_HLS_TREEADD_PERIPH_BUS_ADDR_R13_CTRL);
    return Data & 0x1;
}

u32 XQr_Get_r14(XQr *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XQr_ReadReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XQR_HLS_TREEADD_PERIPH_BUS_ADDR_R14_DATA);
    return Data;
}

u32 XQr_Get_r14_vld(XQr *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XQr_ReadReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XQR_HLS_TREEADD_PERIPH_BUS_ADDR_R14_CTRL);
    return Data & 0x1;
}

u32 XQr_Get_r22(XQr *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XQr_ReadReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XQR_HLS_TREEADD_PERIPH_BUS_ADDR_R22_DATA);
    return Data;
}

u32 XQr_Get_r22_vld(XQr *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XQr_ReadReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XQR_HLS_TREEADD_PERIPH_BUS_ADDR_R22_CTRL);
    return Data & 0x1;
}

u32 XQr_Get_r23(XQr *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XQr_ReadReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XQR_HLS_TREEADD_PERIPH_BUS_ADDR_R23_DATA);
    return Data;
}

u32 XQr_Get_r23_vld(XQr *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XQr_ReadReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XQR_HLS_TREEADD_PERIPH_BUS_ADDR_R23_CTRL);
    return Data & 0x1;
}

u32 XQr_Get_r24(XQr *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XQr_ReadReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XQR_HLS_TREEADD_PERIPH_BUS_ADDR_R24_DATA);
    return Data;
}

u32 XQr_Get_r24_vld(XQr *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XQr_ReadReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XQR_HLS_TREEADD_PERIPH_BUS_ADDR_R24_CTRL);
    return Data & 0x1;
}

u32 XQr_Get_r33(XQr *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XQr_ReadReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XQR_HLS_TREEADD_PERIPH_BUS_ADDR_R33_DATA);
    return Data;
}

u32 XQr_Get_r33_vld(XQr *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XQr_ReadReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XQR_HLS_TREEADD_PERIPH_BUS_ADDR_R33_CTRL);
    return Data & 0x1;
}

u32 XQr_Get_r34(XQr *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XQr_ReadReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XQR_HLS_TREEADD_PERIPH_BUS_ADDR_R34_DATA);
    return Data;
}

u32 XQr_Get_r34_vld(XQr *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XQr_ReadReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XQR_HLS_TREEADD_PERIPH_BUS_ADDR_R34_CTRL);
    return Data & 0x1;
}

u32 XQr_Get_r44(XQr *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XQr_ReadReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XQR_HLS_TREEADD_PERIPH_BUS_ADDR_R44_DATA);
    return Data;
}

u32 XQr_Get_r44_vld(XQr *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XQr_ReadReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XQR_HLS_TREEADD_PERIPH_BUS_ADDR_R44_CTRL);
    return Data & 0x1;
}

void XQr_Set_din(XQr *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XQr_WriteReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XQR_HLS_TREEADD_PERIPH_BUS_ADDR_DIN_DATA, Data);
}

u32 XQr_Get_din(XQr *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XQr_ReadReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XQR_HLS_TREEADD_PERIPH_BUS_ADDR_DIN_DATA);
    return Data;
}

u32 XQr_Get_done(XQr *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XQr_ReadReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XQR_HLS_TREEADD_PERIPH_BUS_ADDR_DONE_DATA);
    return Data;
}

u32 XQr_Get_done_vld(XQr *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XQr_ReadReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XQR_HLS_TREEADD_PERIPH_BUS_ADDR_DONE_CTRL);
    return Data & 0x1;
}

void XQr_InterruptGlobalEnable(XQr *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XQr_WriteReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XQR_HLS_TREEADD_PERIPH_BUS_ADDR_GIE, 1);
}

void XQr_InterruptGlobalDisable(XQr *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XQr_WriteReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XQR_HLS_TREEADD_PERIPH_BUS_ADDR_GIE, 0);
}

void XQr_InterruptEnable(XQr *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XQr_ReadReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XQR_HLS_TREEADD_PERIPH_BUS_ADDR_IER);
    XQr_WriteReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XQR_HLS_TREEADD_PERIPH_BUS_ADDR_IER, Register | Mask);
}

void XQr_InterruptDisable(XQr *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XQr_ReadReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XQR_HLS_TREEADD_PERIPH_BUS_ADDR_IER);
    XQr_WriteReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XQR_HLS_TREEADD_PERIPH_BUS_ADDR_IER, Register & (~Mask));
}

void XQr_InterruptClear(XQr *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    //XQr_WriteReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XQR_HLS_TREEADD_PERIPH_BUS_ADDR_ISR, Mask);
}

u32 XQr_InterruptGetEnabled(XQr *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XQr_ReadReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XQR_HLS_TREEADD_PERIPH_BUS_ADDR_IER);
}

u32 XQr_InterruptGetStatus(XQr *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    // Current Interrupt Clear Behavior is Clear on Read(COR).
    return XQr_ReadReg(InstancePtr->Hls_treeadd_periph_bus_BaseAddress, XQR_HLS_TREEADD_PERIPH_BUS_ADDR_ISR);
}

