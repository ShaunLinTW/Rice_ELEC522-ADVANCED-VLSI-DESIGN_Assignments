#include <systemc>
#include <iostream>
#include <cstdlib>
#include <cstddef>
#include <stdint.h>
#include "SysCFileHandler.h"
#include "ap_int.h"
#include "ap_fixed.h"
#include <complex>
#include <stdbool.h>
#include "autopilot_cbe.h"
#include "hls_stream.h"
#include "hls_half.h"
#include "hls_signal_handler.h"

using namespace std;
using namespace sc_core;
using namespace sc_dt;

// wrapc file define:
#define AUTOTB_TVIN_a11 "../tv/cdatafile/c.qr.autotvin_a11.dat"
#define AUTOTB_TVOUT_a11 "../tv/cdatafile/c.qr.autotvout_a11.dat"
#define AUTOTB_TVIN_a12 "../tv/cdatafile/c.qr.autotvin_a12.dat"
#define AUTOTB_TVOUT_a12 "../tv/cdatafile/c.qr.autotvout_a12.dat"
#define AUTOTB_TVIN_a13 "../tv/cdatafile/c.qr.autotvin_a13.dat"
#define AUTOTB_TVOUT_a13 "../tv/cdatafile/c.qr.autotvout_a13.dat"
#define AUTOTB_TVIN_a14 "../tv/cdatafile/c.qr.autotvin_a14.dat"
#define AUTOTB_TVOUT_a14 "../tv/cdatafile/c.qr.autotvout_a14.dat"
#define AUTOTB_TVIN_a21 "../tv/cdatafile/c.qr.autotvin_a21.dat"
#define AUTOTB_TVOUT_a21 "../tv/cdatafile/c.qr.autotvout_a21.dat"
#define AUTOTB_TVIN_a22 "../tv/cdatafile/c.qr.autotvin_a22.dat"
#define AUTOTB_TVOUT_a22 "../tv/cdatafile/c.qr.autotvout_a22.dat"
#define AUTOTB_TVIN_a23 "../tv/cdatafile/c.qr.autotvin_a23.dat"
#define AUTOTB_TVOUT_a23 "../tv/cdatafile/c.qr.autotvout_a23.dat"
#define AUTOTB_TVIN_a24 "../tv/cdatafile/c.qr.autotvin_a24.dat"
#define AUTOTB_TVOUT_a24 "../tv/cdatafile/c.qr.autotvout_a24.dat"
#define AUTOTB_TVIN_a31 "../tv/cdatafile/c.qr.autotvin_a31.dat"
#define AUTOTB_TVOUT_a31 "../tv/cdatafile/c.qr.autotvout_a31.dat"
#define AUTOTB_TVIN_a32 "../tv/cdatafile/c.qr.autotvin_a32.dat"
#define AUTOTB_TVOUT_a32 "../tv/cdatafile/c.qr.autotvout_a32.dat"
#define AUTOTB_TVIN_a33 "../tv/cdatafile/c.qr.autotvin_a33.dat"
#define AUTOTB_TVOUT_a33 "../tv/cdatafile/c.qr.autotvout_a33.dat"
#define AUTOTB_TVIN_a34 "../tv/cdatafile/c.qr.autotvin_a34.dat"
#define AUTOTB_TVOUT_a34 "../tv/cdatafile/c.qr.autotvout_a34.dat"
#define AUTOTB_TVIN_a41 "../tv/cdatafile/c.qr.autotvin_a41.dat"
#define AUTOTB_TVOUT_a41 "../tv/cdatafile/c.qr.autotvout_a41.dat"
#define AUTOTB_TVIN_a42 "../tv/cdatafile/c.qr.autotvin_a42.dat"
#define AUTOTB_TVOUT_a42 "../tv/cdatafile/c.qr.autotvout_a42.dat"
#define AUTOTB_TVIN_a43 "../tv/cdatafile/c.qr.autotvin_a43.dat"
#define AUTOTB_TVOUT_a43 "../tv/cdatafile/c.qr.autotvout_a43.dat"
#define AUTOTB_TVIN_a44 "../tv/cdatafile/c.qr.autotvin_a44.dat"
#define AUTOTB_TVOUT_a44 "../tv/cdatafile/c.qr.autotvout_a44.dat"
#define AUTOTB_TVIN_q11 "../tv/cdatafile/c.qr.autotvin_q11.dat"
#define AUTOTB_TVOUT_q11 "../tv/cdatafile/c.qr.autotvout_q11.dat"
#define AUTOTB_TVIN_q12 "../tv/cdatafile/c.qr.autotvin_q12.dat"
#define AUTOTB_TVOUT_q12 "../tv/cdatafile/c.qr.autotvout_q12.dat"
#define AUTOTB_TVIN_q13 "../tv/cdatafile/c.qr.autotvin_q13.dat"
#define AUTOTB_TVOUT_q13 "../tv/cdatafile/c.qr.autotvout_q13.dat"
#define AUTOTB_TVIN_q14 "../tv/cdatafile/c.qr.autotvin_q14.dat"
#define AUTOTB_TVOUT_q14 "../tv/cdatafile/c.qr.autotvout_q14.dat"
#define AUTOTB_TVIN_q21 "../tv/cdatafile/c.qr.autotvin_q21.dat"
#define AUTOTB_TVOUT_q21 "../tv/cdatafile/c.qr.autotvout_q21.dat"
#define AUTOTB_TVIN_q22 "../tv/cdatafile/c.qr.autotvin_q22.dat"
#define AUTOTB_TVOUT_q22 "../tv/cdatafile/c.qr.autotvout_q22.dat"
#define AUTOTB_TVIN_q23 "../tv/cdatafile/c.qr.autotvin_q23.dat"
#define AUTOTB_TVOUT_q23 "../tv/cdatafile/c.qr.autotvout_q23.dat"
#define AUTOTB_TVIN_q24 "../tv/cdatafile/c.qr.autotvin_q24.dat"
#define AUTOTB_TVOUT_q24 "../tv/cdatafile/c.qr.autotvout_q24.dat"
#define AUTOTB_TVIN_q31 "../tv/cdatafile/c.qr.autotvin_q31.dat"
#define AUTOTB_TVOUT_q31 "../tv/cdatafile/c.qr.autotvout_q31.dat"
#define AUTOTB_TVIN_q32 "../tv/cdatafile/c.qr.autotvin_q32.dat"
#define AUTOTB_TVOUT_q32 "../tv/cdatafile/c.qr.autotvout_q32.dat"
#define AUTOTB_TVIN_q33 "../tv/cdatafile/c.qr.autotvin_q33.dat"
#define AUTOTB_TVOUT_q33 "../tv/cdatafile/c.qr.autotvout_q33.dat"
#define AUTOTB_TVIN_q34 "../tv/cdatafile/c.qr.autotvin_q34.dat"
#define AUTOTB_TVOUT_q34 "../tv/cdatafile/c.qr.autotvout_q34.dat"
#define AUTOTB_TVIN_q41 "../tv/cdatafile/c.qr.autotvin_q41.dat"
#define AUTOTB_TVOUT_q41 "../tv/cdatafile/c.qr.autotvout_q41.dat"
#define AUTOTB_TVIN_q42 "../tv/cdatafile/c.qr.autotvin_q42.dat"
#define AUTOTB_TVOUT_q42 "../tv/cdatafile/c.qr.autotvout_q42.dat"
#define AUTOTB_TVIN_q43 "../tv/cdatafile/c.qr.autotvin_q43.dat"
#define AUTOTB_TVOUT_q43 "../tv/cdatafile/c.qr.autotvout_q43.dat"
#define AUTOTB_TVIN_q44 "../tv/cdatafile/c.qr.autotvin_q44.dat"
#define AUTOTB_TVOUT_q44 "../tv/cdatafile/c.qr.autotvout_q44.dat"
#define AUTOTB_TVIN_r11 "../tv/cdatafile/c.qr.autotvin_r11.dat"
#define AUTOTB_TVOUT_r11 "../tv/cdatafile/c.qr.autotvout_r11.dat"
#define AUTOTB_TVIN_r12 "../tv/cdatafile/c.qr.autotvin_r12.dat"
#define AUTOTB_TVOUT_r12 "../tv/cdatafile/c.qr.autotvout_r12.dat"
#define AUTOTB_TVIN_r13 "../tv/cdatafile/c.qr.autotvin_r13.dat"
#define AUTOTB_TVOUT_r13 "../tv/cdatafile/c.qr.autotvout_r13.dat"
#define AUTOTB_TVIN_r14 "../tv/cdatafile/c.qr.autotvin_r14.dat"
#define AUTOTB_TVOUT_r14 "../tv/cdatafile/c.qr.autotvout_r14.dat"
#define AUTOTB_TVIN_r22 "../tv/cdatafile/c.qr.autotvin_r22.dat"
#define AUTOTB_TVOUT_r22 "../tv/cdatafile/c.qr.autotvout_r22.dat"
#define AUTOTB_TVIN_r23 "../tv/cdatafile/c.qr.autotvin_r23.dat"
#define AUTOTB_TVOUT_r23 "../tv/cdatafile/c.qr.autotvout_r23.dat"
#define AUTOTB_TVIN_r24 "../tv/cdatafile/c.qr.autotvin_r24.dat"
#define AUTOTB_TVOUT_r24 "../tv/cdatafile/c.qr.autotvout_r24.dat"
#define AUTOTB_TVIN_r33 "../tv/cdatafile/c.qr.autotvin_r33.dat"
#define AUTOTB_TVOUT_r33 "../tv/cdatafile/c.qr.autotvout_r33.dat"
#define AUTOTB_TVIN_r34 "../tv/cdatafile/c.qr.autotvin_r34.dat"
#define AUTOTB_TVOUT_r34 "../tv/cdatafile/c.qr.autotvout_r34.dat"
#define AUTOTB_TVIN_r44 "../tv/cdatafile/c.qr.autotvin_r44.dat"
#define AUTOTB_TVOUT_r44 "../tv/cdatafile/c.qr.autotvout_r44.dat"
#define AUTOTB_TVIN_din "../tv/cdatafile/c.qr.autotvin_din.dat"
#define AUTOTB_TVOUT_din "../tv/cdatafile/c.qr.autotvout_din.dat"
#define AUTOTB_TVIN_done "../tv/cdatafile/c.qr.autotvin_done.dat"
#define AUTOTB_TVOUT_done "../tv/cdatafile/c.qr.autotvout_done.dat"

#define INTER_TCL "../tv/cdatafile/ref.tcl"

// tvout file define:
#define AUTOTB_TVOUT_PC_a11 "../tv/rtldatafile/rtl.qr.autotvout_a11.dat"
#define AUTOTB_TVOUT_PC_a12 "../tv/rtldatafile/rtl.qr.autotvout_a12.dat"
#define AUTOTB_TVOUT_PC_a13 "../tv/rtldatafile/rtl.qr.autotvout_a13.dat"
#define AUTOTB_TVOUT_PC_a14 "../tv/rtldatafile/rtl.qr.autotvout_a14.dat"
#define AUTOTB_TVOUT_PC_a21 "../tv/rtldatafile/rtl.qr.autotvout_a21.dat"
#define AUTOTB_TVOUT_PC_a22 "../tv/rtldatafile/rtl.qr.autotvout_a22.dat"
#define AUTOTB_TVOUT_PC_a23 "../tv/rtldatafile/rtl.qr.autotvout_a23.dat"
#define AUTOTB_TVOUT_PC_a24 "../tv/rtldatafile/rtl.qr.autotvout_a24.dat"
#define AUTOTB_TVOUT_PC_a31 "../tv/rtldatafile/rtl.qr.autotvout_a31.dat"
#define AUTOTB_TVOUT_PC_a32 "../tv/rtldatafile/rtl.qr.autotvout_a32.dat"
#define AUTOTB_TVOUT_PC_a33 "../tv/rtldatafile/rtl.qr.autotvout_a33.dat"
#define AUTOTB_TVOUT_PC_a34 "../tv/rtldatafile/rtl.qr.autotvout_a34.dat"
#define AUTOTB_TVOUT_PC_a41 "../tv/rtldatafile/rtl.qr.autotvout_a41.dat"
#define AUTOTB_TVOUT_PC_a42 "../tv/rtldatafile/rtl.qr.autotvout_a42.dat"
#define AUTOTB_TVOUT_PC_a43 "../tv/rtldatafile/rtl.qr.autotvout_a43.dat"
#define AUTOTB_TVOUT_PC_a44 "../tv/rtldatafile/rtl.qr.autotvout_a44.dat"
#define AUTOTB_TVOUT_PC_q11 "../tv/rtldatafile/rtl.qr.autotvout_q11.dat"
#define AUTOTB_TVOUT_PC_q12 "../tv/rtldatafile/rtl.qr.autotvout_q12.dat"
#define AUTOTB_TVOUT_PC_q13 "../tv/rtldatafile/rtl.qr.autotvout_q13.dat"
#define AUTOTB_TVOUT_PC_q14 "../tv/rtldatafile/rtl.qr.autotvout_q14.dat"
#define AUTOTB_TVOUT_PC_q21 "../tv/rtldatafile/rtl.qr.autotvout_q21.dat"
#define AUTOTB_TVOUT_PC_q22 "../tv/rtldatafile/rtl.qr.autotvout_q22.dat"
#define AUTOTB_TVOUT_PC_q23 "../tv/rtldatafile/rtl.qr.autotvout_q23.dat"
#define AUTOTB_TVOUT_PC_q24 "../tv/rtldatafile/rtl.qr.autotvout_q24.dat"
#define AUTOTB_TVOUT_PC_q31 "../tv/rtldatafile/rtl.qr.autotvout_q31.dat"
#define AUTOTB_TVOUT_PC_q32 "../tv/rtldatafile/rtl.qr.autotvout_q32.dat"
#define AUTOTB_TVOUT_PC_q33 "../tv/rtldatafile/rtl.qr.autotvout_q33.dat"
#define AUTOTB_TVOUT_PC_q34 "../tv/rtldatafile/rtl.qr.autotvout_q34.dat"
#define AUTOTB_TVOUT_PC_q41 "../tv/rtldatafile/rtl.qr.autotvout_q41.dat"
#define AUTOTB_TVOUT_PC_q42 "../tv/rtldatafile/rtl.qr.autotvout_q42.dat"
#define AUTOTB_TVOUT_PC_q43 "../tv/rtldatafile/rtl.qr.autotvout_q43.dat"
#define AUTOTB_TVOUT_PC_q44 "../tv/rtldatafile/rtl.qr.autotvout_q44.dat"
#define AUTOTB_TVOUT_PC_r11 "../tv/rtldatafile/rtl.qr.autotvout_r11.dat"
#define AUTOTB_TVOUT_PC_r12 "../tv/rtldatafile/rtl.qr.autotvout_r12.dat"
#define AUTOTB_TVOUT_PC_r13 "../tv/rtldatafile/rtl.qr.autotvout_r13.dat"
#define AUTOTB_TVOUT_PC_r14 "../tv/rtldatafile/rtl.qr.autotvout_r14.dat"
#define AUTOTB_TVOUT_PC_r22 "../tv/rtldatafile/rtl.qr.autotvout_r22.dat"
#define AUTOTB_TVOUT_PC_r23 "../tv/rtldatafile/rtl.qr.autotvout_r23.dat"
#define AUTOTB_TVOUT_PC_r24 "../tv/rtldatafile/rtl.qr.autotvout_r24.dat"
#define AUTOTB_TVOUT_PC_r33 "../tv/rtldatafile/rtl.qr.autotvout_r33.dat"
#define AUTOTB_TVOUT_PC_r34 "../tv/rtldatafile/rtl.qr.autotvout_r34.dat"
#define AUTOTB_TVOUT_PC_r44 "../tv/rtldatafile/rtl.qr.autotvout_r44.dat"
#define AUTOTB_TVOUT_PC_din "../tv/rtldatafile/rtl.qr.autotvout_din.dat"
#define AUTOTB_TVOUT_PC_done "../tv/rtldatafile/rtl.qr.autotvout_done.dat"


static const bool little_endian()
{
  int a = 1;
  return *(char*)&a == 1;
}

inline static void rev_endian(char* p, size_t nbytes)
{
  std::reverse(p, p+nbytes);
}

template<size_t bit_width>
struct transaction {
  typedef uint64_t depth_t;
  static const size_t wbytes = (bit_width+7)>>3;
  static const size_t dbytes = sizeof(depth_t);
  const depth_t depth;
  const size_t vbytes;
  const size_t tbytes;
  char * const p;
  typedef char (*p_dat)[wbytes];
  p_dat vp;

  transaction(depth_t depth)
    : depth(depth), vbytes(wbytes*depth), tbytes(dbytes+vbytes),
      p(new char[tbytes]) {
    *(depth_t*)p = depth;
    rev_endian(p, dbytes);
    vp = (p_dat) (p+dbytes);
  }

  void reorder() {
    rev_endian(p, dbytes);
    p_dat vp = (p_dat) (p+dbytes);
    for (depth_t i = 0; i < depth; ++i) {
      rev_endian(vp[i], wbytes);
    }
  }

  template<size_t psize>
  void import(char* param, depth_t num, int64_t offset) {
    param -= offset*psize;
    for (depth_t i = 0; i < num; ++i) {
      memcpy(vp[i], param, wbytes);
      param += psize;
      if (little_endian()) {
        rev_endian(vp[i], wbytes);
      }
    }
    vp += num;
  }

  template<size_t psize>
  void send(char* param, depth_t num) {
    for (depth_t i = 0; i < num; ++i) {
      memcpy(param, vp[i], wbytes);
      param += psize;
    }
    vp += num;
  }

  template<size_t psize>
  void send(char* param, depth_t num, int64_t skip) {
    for (depth_t i = 0; i < num; ++i) {
      memcpy(param, vp[skip+i], wbytes);
      param += psize;
    }
  }

  ~transaction() { if (p) { delete[] p; } }
};


inline static const std::string begin_str(int num)
{
  return std::string("[[transaction]]           ")
         .append(std::to_string(num))
         .append("\n");
}

inline static const std::string end_str()
{
  return std::string("[[/transaction]]\n");
}

const std::string formatData(unsigned char *pos, size_t wbits)
{
  bool LE = little_endian();
  size_t wbytes = (wbits+7)>>3;
  size_t i = LE ? wbytes-1 : 0;
  auto next = [&] () {
    auto c = pos[i];
    LE ? --i : ++i;
    return c;
  };
  std::ostringstream ss;
  ss << "0x";
  if (int t = (wbits & 0x7)) {
    if (t <= 4) {
      unsigned char mask = (1<<t)-1;
      ss << std::hex << std::setfill('0') << std::setw(1)
         << (int) (next() & mask);
      wbytes -= 1;
    }
  }
  for (size_t i = 0; i < wbytes; ++i) {
    ss << std::hex << std::setfill('0') << std::setw(2) << (int)next();
  }
  ss.put('\n');
  return ss.str();
}

static bool RTLOutputCheckAndReplacement(std::string &data)
{
  bool changed = false;
  for (size_t i = 2; i < data.size(); ++i) {
    if (data[i] == 'X' || data[i] == 'x') {
      data[i] = '0';
      changed = true;
    }
  }
  return changed;
}

struct SimException : public std::exception {
  const char *msg;
  const size_t line;
  SimException(const char *msg, const size_t line)
    : msg(msg), line(line)
  {
  }
};

template<size_t bit_width>
class PostCheck
{
  static const char *bad;
  static const char *err;
  std::fstream stream;
  std::string s;

  void send(char *p, ap_uint<bit_width> &data, size_t l, size_t rest)
  {
    if (rest == 0) {
      if (!little_endian()) {
        const size_t wbytes = (bit_width+7)>>3;
        rev_endian(p-wbytes, wbytes);
      }
    } else if (rest < 8) {
      *p = data.range(l+rest-1, l).to_uint();
      send(p+1, data, l+rest, 0);
    } else {
      *p = data.range(l+8-1, l).to_uint();
      send(p+1, data, l+8, rest-8);
    }
  }

  void readline()
  {
    std::getline(stream, s);
    if (stream.eof()) {
      throw SimException(bad, __LINE__);
    }
  }

public:
  char *param;
  size_t psize;
  size_t depth;

  PostCheck(const char *file)
  {
    stream.open(file);
    if (stream.fail()) {
      throw SimException(err, __LINE__);
    } else {
      readline();
      if (s != "[[[runtime]]]") {
        throw SimException(bad, __LINE__);
      }
    }
  }

  ~PostCheck() noexcept(false)
  {
    stream.close();
  }

  void run(size_t AESL_transaction_pc, size_t skip)
  {
    if (stream.peek() == '[') {
      readline();
    }

    for (size_t i = 0; i < skip; ++i) {
      readline();
    }

    bool foundX = false;
    for (size_t i = 0; i < depth; ++i) {
      readline();
      foundX |= RTLOutputCheckAndReplacement(s);
      ap_uint<bit_width> data(s.c_str(), 16);
      send(param+i*psize, data, 0, bit_width);
    }
    if (foundX) {
      std::cerr << "WARNING: [SIM 212-201] RTL produces unknown value "
                << "'x' or 'X' on some port, possible cause: "
                << "There are uninitialized variables in the design.\n";
    }

    if (stream.peek() == '[') {
      readline();
    }
  }
};

template<size_t bit_width>
const char* PostCheck<bit_width>::bad = "Bad TV file";

template<size_t bit_width>
const char* PostCheck<bit_width>::err = "Error on TV file";
      
class INTER_TCL_FILE {
  public:
INTER_TCL_FILE(const char* name) {
  mName = name; 
  a11_depth = 0;
  a12_depth = 0;
  a13_depth = 0;
  a14_depth = 0;
  a21_depth = 0;
  a22_depth = 0;
  a23_depth = 0;
  a24_depth = 0;
  a31_depth = 0;
  a32_depth = 0;
  a33_depth = 0;
  a34_depth = 0;
  a41_depth = 0;
  a42_depth = 0;
  a43_depth = 0;
  a44_depth = 0;
  q11_depth = 0;
  q12_depth = 0;
  q13_depth = 0;
  q14_depth = 0;
  q21_depth = 0;
  q22_depth = 0;
  q23_depth = 0;
  q24_depth = 0;
  q31_depth = 0;
  q32_depth = 0;
  q33_depth = 0;
  q34_depth = 0;
  q41_depth = 0;
  q42_depth = 0;
  q43_depth = 0;
  q44_depth = 0;
  r11_depth = 0;
  r12_depth = 0;
  r13_depth = 0;
  r14_depth = 0;
  r22_depth = 0;
  r23_depth = 0;
  r24_depth = 0;
  r33_depth = 0;
  r34_depth = 0;
  r44_depth = 0;
  din_depth = 0;
  done_depth = 0;
  trans_num =0;
}
~INTER_TCL_FILE() {
  mFile.open(mName);
  if (!mFile.good()) {
    cout << "Failed to open file ref.tcl" << endl;
    exit (1); 
  }
  string total_list = get_depth_list();
  mFile << "set depth_list {\n";
  mFile << total_list;
  mFile << "}\n";
  mFile << "set trans_num "<<trans_num<<endl;
  mFile.close();
}
string get_depth_list () {
  stringstream total_list;
  total_list << "{a11 " << a11_depth << "}\n";
  total_list << "{a12 " << a12_depth << "}\n";
  total_list << "{a13 " << a13_depth << "}\n";
  total_list << "{a14 " << a14_depth << "}\n";
  total_list << "{a21 " << a21_depth << "}\n";
  total_list << "{a22 " << a22_depth << "}\n";
  total_list << "{a23 " << a23_depth << "}\n";
  total_list << "{a24 " << a24_depth << "}\n";
  total_list << "{a31 " << a31_depth << "}\n";
  total_list << "{a32 " << a32_depth << "}\n";
  total_list << "{a33 " << a33_depth << "}\n";
  total_list << "{a34 " << a34_depth << "}\n";
  total_list << "{a41 " << a41_depth << "}\n";
  total_list << "{a42 " << a42_depth << "}\n";
  total_list << "{a43 " << a43_depth << "}\n";
  total_list << "{a44 " << a44_depth << "}\n";
  total_list << "{q11 " << q11_depth << "}\n";
  total_list << "{q12 " << q12_depth << "}\n";
  total_list << "{q13 " << q13_depth << "}\n";
  total_list << "{q14 " << q14_depth << "}\n";
  total_list << "{q21 " << q21_depth << "}\n";
  total_list << "{q22 " << q22_depth << "}\n";
  total_list << "{q23 " << q23_depth << "}\n";
  total_list << "{q24 " << q24_depth << "}\n";
  total_list << "{q31 " << q31_depth << "}\n";
  total_list << "{q32 " << q32_depth << "}\n";
  total_list << "{q33 " << q33_depth << "}\n";
  total_list << "{q34 " << q34_depth << "}\n";
  total_list << "{q41 " << q41_depth << "}\n";
  total_list << "{q42 " << q42_depth << "}\n";
  total_list << "{q43 " << q43_depth << "}\n";
  total_list << "{q44 " << q44_depth << "}\n";
  total_list << "{r11 " << r11_depth << "}\n";
  total_list << "{r12 " << r12_depth << "}\n";
  total_list << "{r13 " << r13_depth << "}\n";
  total_list << "{r14 " << r14_depth << "}\n";
  total_list << "{r22 " << r22_depth << "}\n";
  total_list << "{r23 " << r23_depth << "}\n";
  total_list << "{r24 " << r24_depth << "}\n";
  total_list << "{r33 " << r33_depth << "}\n";
  total_list << "{r34 " << r34_depth << "}\n";
  total_list << "{r44 " << r44_depth << "}\n";
  total_list << "{din " << din_depth << "}\n";
  total_list << "{done " << done_depth << "}\n";
  return total_list.str();
}
void set_num (int num , int* class_num) {
  (*class_num) = (*class_num) > num ? (*class_num) : num;
}
void set_string(std::string list, std::string* class_list) {
  (*class_list) = list;
}
  public:
    int a11_depth;
    int a12_depth;
    int a13_depth;
    int a14_depth;
    int a21_depth;
    int a22_depth;
    int a23_depth;
    int a24_depth;
    int a31_depth;
    int a32_depth;
    int a33_depth;
    int a34_depth;
    int a41_depth;
    int a42_depth;
    int a43_depth;
    int a44_depth;
    int q11_depth;
    int q12_depth;
    int q13_depth;
    int q14_depth;
    int q21_depth;
    int q22_depth;
    int q23_depth;
    int q24_depth;
    int q31_depth;
    int q32_depth;
    int q33_depth;
    int q34_depth;
    int q41_depth;
    int q42_depth;
    int q43_depth;
    int q44_depth;
    int r11_depth;
    int r12_depth;
    int r13_depth;
    int r14_depth;
    int r22_depth;
    int r23_depth;
    int r24_depth;
    int r33_depth;
    int r34_depth;
    int r44_depth;
    int din_depth;
    int done_depth;
    int trans_num;
  private:
    ofstream mFile;
    const char* mName;
};


struct __cosim_s4__ { char data[4]; };
extern "C" void qr_hw_stub_wrapper(__cosim_s4__*, __cosim_s4__*, __cosim_s4__*, __cosim_s4__*, __cosim_s4__*, __cosim_s4__*, __cosim_s4__*, __cosim_s4__*, __cosim_s4__*, __cosim_s4__*, __cosim_s4__*, __cosim_s4__*, __cosim_s4__*, __cosim_s4__*, __cosim_s4__*, __cosim_s4__*, volatile void *, volatile void *, volatile void *, volatile void *, volatile void *, volatile void *, volatile void *, volatile void *, volatile void *, volatile void *, volatile void *, volatile void *, volatile void *, volatile void *, volatile void *, volatile void *, volatile void *, volatile void *, volatile void *, volatile void *, volatile void *, volatile void *, volatile void *, volatile void *, volatile void *, volatile void *, __cosim_s4__*, volatile void *);

extern "C" void apatb_qr_hw(__cosim_s4__* __xlx_apatb_param_a11, __cosim_s4__* __xlx_apatb_param_a12, __cosim_s4__* __xlx_apatb_param_a13, __cosim_s4__* __xlx_apatb_param_a14, __cosim_s4__* __xlx_apatb_param_a21, __cosim_s4__* __xlx_apatb_param_a22, __cosim_s4__* __xlx_apatb_param_a23, __cosim_s4__* __xlx_apatb_param_a24, __cosim_s4__* __xlx_apatb_param_a31, __cosim_s4__* __xlx_apatb_param_a32, __cosim_s4__* __xlx_apatb_param_a33, __cosim_s4__* __xlx_apatb_param_a34, __cosim_s4__* __xlx_apatb_param_a41, __cosim_s4__* __xlx_apatb_param_a42, __cosim_s4__* __xlx_apatb_param_a43, __cosim_s4__* __xlx_apatb_param_a44, volatile void * __xlx_apatb_param_q11, volatile void * __xlx_apatb_param_q12, volatile void * __xlx_apatb_param_q13, volatile void * __xlx_apatb_param_q14, volatile void * __xlx_apatb_param_q21, volatile void * __xlx_apatb_param_q22, volatile void * __xlx_apatb_param_q23, volatile void * __xlx_apatb_param_q24, volatile void * __xlx_apatb_param_q31, volatile void * __xlx_apatb_param_q32, volatile void * __xlx_apatb_param_q33, volatile void * __xlx_apatb_param_q34, volatile void * __xlx_apatb_param_q41, volatile void * __xlx_apatb_param_q42, volatile void * __xlx_apatb_param_q43, volatile void * __xlx_apatb_param_q44, volatile void * __xlx_apatb_param_r11, volatile void * __xlx_apatb_param_r12, volatile void * __xlx_apatb_param_r13, volatile void * __xlx_apatb_param_r14, volatile void * __xlx_apatb_param_r22, volatile void * __xlx_apatb_param_r23, volatile void * __xlx_apatb_param_r24, volatile void * __xlx_apatb_param_r33, volatile void * __xlx_apatb_param_r34, volatile void * __xlx_apatb_param_r44, __cosim_s4__* __xlx_apatb_param_din, volatile void * __xlx_apatb_param_done) {
  refine_signal_handler();
  fstream wrapc_switch_file_token;
  wrapc_switch_file_token.open(".hls_cosim_wrapc_switch.log");
static AESL_FILE_HANDLER aesl_fh;
  int AESL_i;
  if (wrapc_switch_file_token.good())
  {

    CodeState = ENTER_WRAPC_PC;
    static unsigned AESL_transaction_pc = 0;
    string AESL_token;
    string AESL_num;
{
      static ifstream rtl_tv_out_file;
      if (!rtl_tv_out_file.is_open()) {
        rtl_tv_out_file.open(AUTOTB_TVOUT_PC_q11);
        if (rtl_tv_out_file.good()) {
          rtl_tv_out_file >> AESL_token;
          if (AESL_token != "[[[runtime]]]")
            exit(1);
        }
      }
  
      if (rtl_tv_out_file.good()) {
        rtl_tv_out_file >> AESL_token; 
        rtl_tv_out_file >> AESL_num;  // transaction number
        if (AESL_token != "[[transaction]]") {
          cerr << "Unexpected token: " << AESL_token << endl;
          exit(1);
        }
        if (atoi(AESL_num.c_str()) == AESL_transaction_pc) {
          std::vector<sc_bv<24> > q11_pc_buffer(1);
          int i = 0;
          bool has_unknown_value = false;
          rtl_tv_out_file >> AESL_token; //data
          while (AESL_token != "[[/transaction]]"){

            has_unknown_value |= RTLOutputCheckAndReplacement(AESL_token);
  
            // push token into output port buffer
            if (AESL_token != "") {
              q11_pc_buffer[i] = AESL_token.c_str();;
              i++;
            }
  
            rtl_tv_out_file >> AESL_token; //data or [[/transaction]]
            if (AESL_token == "[[[/runtime]]]" || rtl_tv_out_file.eof())
              exit(1);
          }
          if (has_unknown_value) {
            cerr << "WARNING: [SIM 212-201] RTL produces unknown value 'x' or 'X' on port " 
                 << "q11" << ", possible cause: There are uninitialized variables in the C design."
                 << endl; 
          }
  
          if (i > 0) {((char*)__xlx_apatb_param_q11)[0*3+0] = q11_pc_buffer[0].range(7, 0).to_int64();
((char*)__xlx_apatb_param_q11)[0*3+1] = q11_pc_buffer[0].range(15, 8).to_int64();
((char*)__xlx_apatb_param_q11)[0*3+2] = q11_pc_buffer[0].range(23, 16).to_int64();
}
        } // end transaction
      } // end file is good
    } // end post check logic bolck
  {
      static ifstream rtl_tv_out_file;
      if (!rtl_tv_out_file.is_open()) {
        rtl_tv_out_file.open(AUTOTB_TVOUT_PC_q12);
        if (rtl_tv_out_file.good()) {
          rtl_tv_out_file >> AESL_token;
          if (AESL_token != "[[[runtime]]]")
            exit(1);
        }
      }
  
      if (rtl_tv_out_file.good()) {
        rtl_tv_out_file >> AESL_token; 
        rtl_tv_out_file >> AESL_num;  // transaction number
        if (AESL_token != "[[transaction]]") {
          cerr << "Unexpected token: " << AESL_token << endl;
          exit(1);
        }
        if (atoi(AESL_num.c_str()) == AESL_transaction_pc) {
          std::vector<sc_bv<24> > q12_pc_buffer(1);
          int i = 0;
          bool has_unknown_value = false;
          rtl_tv_out_file >> AESL_token; //data
          while (AESL_token != "[[/transaction]]"){

            has_unknown_value |= RTLOutputCheckAndReplacement(AESL_token);
  
            // push token into output port buffer
            if (AESL_token != "") {
              q12_pc_buffer[i] = AESL_token.c_str();;
              i++;
            }
  
            rtl_tv_out_file >> AESL_token; //data or [[/transaction]]
            if (AESL_token == "[[[/runtime]]]" || rtl_tv_out_file.eof())
              exit(1);
          }
          if (has_unknown_value) {
            cerr << "WARNING: [SIM 212-201] RTL produces unknown value 'x' or 'X' on port " 
                 << "q12" << ", possible cause: There are uninitialized variables in the C design."
                 << endl; 
          }
  
          if (i > 0) {((char*)__xlx_apatb_param_q12)[0*3+0] = q12_pc_buffer[0].range(7, 0).to_int64();
((char*)__xlx_apatb_param_q12)[0*3+1] = q12_pc_buffer[0].range(15, 8).to_int64();
((char*)__xlx_apatb_param_q12)[0*3+2] = q12_pc_buffer[0].range(23, 16).to_int64();
}
        } // end transaction
      } // end file is good
    } // end post check logic bolck
  {
      static ifstream rtl_tv_out_file;
      if (!rtl_tv_out_file.is_open()) {
        rtl_tv_out_file.open(AUTOTB_TVOUT_PC_q13);
        if (rtl_tv_out_file.good()) {
          rtl_tv_out_file >> AESL_token;
          if (AESL_token != "[[[runtime]]]")
            exit(1);
        }
      }
  
      if (rtl_tv_out_file.good()) {
        rtl_tv_out_file >> AESL_token; 
        rtl_tv_out_file >> AESL_num;  // transaction number
        if (AESL_token != "[[transaction]]") {
          cerr << "Unexpected token: " << AESL_token << endl;
          exit(1);
        }
        if (atoi(AESL_num.c_str()) == AESL_transaction_pc) {
          std::vector<sc_bv<24> > q13_pc_buffer(1);
          int i = 0;
          bool has_unknown_value = false;
          rtl_tv_out_file >> AESL_token; //data
          while (AESL_token != "[[/transaction]]"){

            has_unknown_value |= RTLOutputCheckAndReplacement(AESL_token);
  
            // push token into output port buffer
            if (AESL_token != "") {
              q13_pc_buffer[i] = AESL_token.c_str();;
              i++;
            }
  
            rtl_tv_out_file >> AESL_token; //data or [[/transaction]]
            if (AESL_token == "[[[/runtime]]]" || rtl_tv_out_file.eof())
              exit(1);
          }
          if (has_unknown_value) {
            cerr << "WARNING: [SIM 212-201] RTL produces unknown value 'x' or 'X' on port " 
                 << "q13" << ", possible cause: There are uninitialized variables in the C design."
                 << endl; 
          }
  
          if (i > 0) {((char*)__xlx_apatb_param_q13)[0*3+0] = q13_pc_buffer[0].range(7, 0).to_int64();
((char*)__xlx_apatb_param_q13)[0*3+1] = q13_pc_buffer[0].range(15, 8).to_int64();
((char*)__xlx_apatb_param_q13)[0*3+2] = q13_pc_buffer[0].range(23, 16).to_int64();
}
        } // end transaction
      } // end file is good
    } // end post check logic bolck
  {
      static ifstream rtl_tv_out_file;
      if (!rtl_tv_out_file.is_open()) {
        rtl_tv_out_file.open(AUTOTB_TVOUT_PC_q14);
        if (rtl_tv_out_file.good()) {
          rtl_tv_out_file >> AESL_token;
          if (AESL_token != "[[[runtime]]]")
            exit(1);
        }
      }
  
      if (rtl_tv_out_file.good()) {
        rtl_tv_out_file >> AESL_token; 
        rtl_tv_out_file >> AESL_num;  // transaction number
        if (AESL_token != "[[transaction]]") {
          cerr << "Unexpected token: " << AESL_token << endl;
          exit(1);
        }
        if (atoi(AESL_num.c_str()) == AESL_transaction_pc) {
          std::vector<sc_bv<24> > q14_pc_buffer(1);
          int i = 0;
          bool has_unknown_value = false;
          rtl_tv_out_file >> AESL_token; //data
          while (AESL_token != "[[/transaction]]"){

            has_unknown_value |= RTLOutputCheckAndReplacement(AESL_token);
  
            // push token into output port buffer
            if (AESL_token != "") {
              q14_pc_buffer[i] = AESL_token.c_str();;
              i++;
            }
  
            rtl_tv_out_file >> AESL_token; //data or [[/transaction]]
            if (AESL_token == "[[[/runtime]]]" || rtl_tv_out_file.eof())
              exit(1);
          }
          if (has_unknown_value) {
            cerr << "WARNING: [SIM 212-201] RTL produces unknown value 'x' or 'X' on port " 
                 << "q14" << ", possible cause: There are uninitialized variables in the C design."
                 << endl; 
          }
  
          if (i > 0) {((char*)__xlx_apatb_param_q14)[0*3+0] = q14_pc_buffer[0].range(7, 0).to_int64();
((char*)__xlx_apatb_param_q14)[0*3+1] = q14_pc_buffer[0].range(15, 8).to_int64();
((char*)__xlx_apatb_param_q14)[0*3+2] = q14_pc_buffer[0].range(23, 16).to_int64();
}
        } // end transaction
      } // end file is good
    } // end post check logic bolck
  {
      static ifstream rtl_tv_out_file;
      if (!rtl_tv_out_file.is_open()) {
        rtl_tv_out_file.open(AUTOTB_TVOUT_PC_q21);
        if (rtl_tv_out_file.good()) {
          rtl_tv_out_file >> AESL_token;
          if (AESL_token != "[[[runtime]]]")
            exit(1);
        }
      }
  
      if (rtl_tv_out_file.good()) {
        rtl_tv_out_file >> AESL_token; 
        rtl_tv_out_file >> AESL_num;  // transaction number
        if (AESL_token != "[[transaction]]") {
          cerr << "Unexpected token: " << AESL_token << endl;
          exit(1);
        }
        if (atoi(AESL_num.c_str()) == AESL_transaction_pc) {
          std::vector<sc_bv<24> > q21_pc_buffer(1);
          int i = 0;
          bool has_unknown_value = false;
          rtl_tv_out_file >> AESL_token; //data
          while (AESL_token != "[[/transaction]]"){

            has_unknown_value |= RTLOutputCheckAndReplacement(AESL_token);
  
            // push token into output port buffer
            if (AESL_token != "") {
              q21_pc_buffer[i] = AESL_token.c_str();;
              i++;
            }
  
            rtl_tv_out_file >> AESL_token; //data or [[/transaction]]
            if (AESL_token == "[[[/runtime]]]" || rtl_tv_out_file.eof())
              exit(1);
          }
          if (has_unknown_value) {
            cerr << "WARNING: [SIM 212-201] RTL produces unknown value 'x' or 'X' on port " 
                 << "q21" << ", possible cause: There are uninitialized variables in the C design."
                 << endl; 
          }
  
          if (i > 0) {((char*)__xlx_apatb_param_q21)[0*3+0] = q21_pc_buffer[0].range(7, 0).to_int64();
((char*)__xlx_apatb_param_q21)[0*3+1] = q21_pc_buffer[0].range(15, 8).to_int64();
((char*)__xlx_apatb_param_q21)[0*3+2] = q21_pc_buffer[0].range(23, 16).to_int64();
}
        } // end transaction
      } // end file is good
    } // end post check logic bolck
  {
      static ifstream rtl_tv_out_file;
      if (!rtl_tv_out_file.is_open()) {
        rtl_tv_out_file.open(AUTOTB_TVOUT_PC_q22);
        if (rtl_tv_out_file.good()) {
          rtl_tv_out_file >> AESL_token;
          if (AESL_token != "[[[runtime]]]")
            exit(1);
        }
      }
  
      if (rtl_tv_out_file.good()) {
        rtl_tv_out_file >> AESL_token; 
        rtl_tv_out_file >> AESL_num;  // transaction number
        if (AESL_token != "[[transaction]]") {
          cerr << "Unexpected token: " << AESL_token << endl;
          exit(1);
        }
        if (atoi(AESL_num.c_str()) == AESL_transaction_pc) {
          std::vector<sc_bv<24> > q22_pc_buffer(1);
          int i = 0;
          bool has_unknown_value = false;
          rtl_tv_out_file >> AESL_token; //data
          while (AESL_token != "[[/transaction]]"){

            has_unknown_value |= RTLOutputCheckAndReplacement(AESL_token);
  
            // push token into output port buffer
            if (AESL_token != "") {
              q22_pc_buffer[i] = AESL_token.c_str();;
              i++;
            }
  
            rtl_tv_out_file >> AESL_token; //data or [[/transaction]]
            if (AESL_token == "[[[/runtime]]]" || rtl_tv_out_file.eof())
              exit(1);
          }
          if (has_unknown_value) {
            cerr << "WARNING: [SIM 212-201] RTL produces unknown value 'x' or 'X' on port " 
                 << "q22" << ", possible cause: There are uninitialized variables in the C design."
                 << endl; 
          }
  
          if (i > 0) {((char*)__xlx_apatb_param_q22)[0*3+0] = q22_pc_buffer[0].range(7, 0).to_int64();
((char*)__xlx_apatb_param_q22)[0*3+1] = q22_pc_buffer[0].range(15, 8).to_int64();
((char*)__xlx_apatb_param_q22)[0*3+2] = q22_pc_buffer[0].range(23, 16).to_int64();
}
        } // end transaction
      } // end file is good
    } // end post check logic bolck
  {
      static ifstream rtl_tv_out_file;
      if (!rtl_tv_out_file.is_open()) {
        rtl_tv_out_file.open(AUTOTB_TVOUT_PC_q23);
        if (rtl_tv_out_file.good()) {
          rtl_tv_out_file >> AESL_token;
          if (AESL_token != "[[[runtime]]]")
            exit(1);
        }
      }
  
      if (rtl_tv_out_file.good()) {
        rtl_tv_out_file >> AESL_token; 
        rtl_tv_out_file >> AESL_num;  // transaction number
        if (AESL_token != "[[transaction]]") {
          cerr << "Unexpected token: " << AESL_token << endl;
          exit(1);
        }
        if (atoi(AESL_num.c_str()) == AESL_transaction_pc) {
          std::vector<sc_bv<24> > q23_pc_buffer(1);
          int i = 0;
          bool has_unknown_value = false;
          rtl_tv_out_file >> AESL_token; //data
          while (AESL_token != "[[/transaction]]"){

            has_unknown_value |= RTLOutputCheckAndReplacement(AESL_token);
  
            // push token into output port buffer
            if (AESL_token != "") {
              q23_pc_buffer[i] = AESL_token.c_str();;
              i++;
            }
  
            rtl_tv_out_file >> AESL_token; //data or [[/transaction]]
            if (AESL_token == "[[[/runtime]]]" || rtl_tv_out_file.eof())
              exit(1);
          }
          if (has_unknown_value) {
            cerr << "WARNING: [SIM 212-201] RTL produces unknown value 'x' or 'X' on port " 
                 << "q23" << ", possible cause: There are uninitialized variables in the C design."
                 << endl; 
          }
  
          if (i > 0) {((char*)__xlx_apatb_param_q23)[0*3+0] = q23_pc_buffer[0].range(7, 0).to_int64();
((char*)__xlx_apatb_param_q23)[0*3+1] = q23_pc_buffer[0].range(15, 8).to_int64();
((char*)__xlx_apatb_param_q23)[0*3+2] = q23_pc_buffer[0].range(23, 16).to_int64();
}
        } // end transaction
      } // end file is good
    } // end post check logic bolck
  {
      static ifstream rtl_tv_out_file;
      if (!rtl_tv_out_file.is_open()) {
        rtl_tv_out_file.open(AUTOTB_TVOUT_PC_q24);
        if (rtl_tv_out_file.good()) {
          rtl_tv_out_file >> AESL_token;
          if (AESL_token != "[[[runtime]]]")
            exit(1);
        }
      }
  
      if (rtl_tv_out_file.good()) {
        rtl_tv_out_file >> AESL_token; 
        rtl_tv_out_file >> AESL_num;  // transaction number
        if (AESL_token != "[[transaction]]") {
          cerr << "Unexpected token: " << AESL_token << endl;
          exit(1);
        }
        if (atoi(AESL_num.c_str()) == AESL_transaction_pc) {
          std::vector<sc_bv<24> > q24_pc_buffer(1);
          int i = 0;
          bool has_unknown_value = false;
          rtl_tv_out_file >> AESL_token; //data
          while (AESL_token != "[[/transaction]]"){

            has_unknown_value |= RTLOutputCheckAndReplacement(AESL_token);
  
            // push token into output port buffer
            if (AESL_token != "") {
              q24_pc_buffer[i] = AESL_token.c_str();;
              i++;
            }
  
            rtl_tv_out_file >> AESL_token; //data or [[/transaction]]
            if (AESL_token == "[[[/runtime]]]" || rtl_tv_out_file.eof())
              exit(1);
          }
          if (has_unknown_value) {
            cerr << "WARNING: [SIM 212-201] RTL produces unknown value 'x' or 'X' on port " 
                 << "q24" << ", possible cause: There are uninitialized variables in the C design."
                 << endl; 
          }
  
          if (i > 0) {((char*)__xlx_apatb_param_q24)[0*3+0] = q24_pc_buffer[0].range(7, 0).to_int64();
((char*)__xlx_apatb_param_q24)[0*3+1] = q24_pc_buffer[0].range(15, 8).to_int64();
((char*)__xlx_apatb_param_q24)[0*3+2] = q24_pc_buffer[0].range(23, 16).to_int64();
}
        } // end transaction
      } // end file is good
    } // end post check logic bolck
  {
      static ifstream rtl_tv_out_file;
      if (!rtl_tv_out_file.is_open()) {
        rtl_tv_out_file.open(AUTOTB_TVOUT_PC_q31);
        if (rtl_tv_out_file.good()) {
          rtl_tv_out_file >> AESL_token;
          if (AESL_token != "[[[runtime]]]")
            exit(1);
        }
      }
  
      if (rtl_tv_out_file.good()) {
        rtl_tv_out_file >> AESL_token; 
        rtl_tv_out_file >> AESL_num;  // transaction number
        if (AESL_token != "[[transaction]]") {
          cerr << "Unexpected token: " << AESL_token << endl;
          exit(1);
        }
        if (atoi(AESL_num.c_str()) == AESL_transaction_pc) {
          std::vector<sc_bv<24> > q31_pc_buffer(1);
          int i = 0;
          bool has_unknown_value = false;
          rtl_tv_out_file >> AESL_token; //data
          while (AESL_token != "[[/transaction]]"){

            has_unknown_value |= RTLOutputCheckAndReplacement(AESL_token);
  
            // push token into output port buffer
            if (AESL_token != "") {
              q31_pc_buffer[i] = AESL_token.c_str();;
              i++;
            }
  
            rtl_tv_out_file >> AESL_token; //data or [[/transaction]]
            if (AESL_token == "[[[/runtime]]]" || rtl_tv_out_file.eof())
              exit(1);
          }
          if (has_unknown_value) {
            cerr << "WARNING: [SIM 212-201] RTL produces unknown value 'x' or 'X' on port " 
                 << "q31" << ", possible cause: There are uninitialized variables in the C design."
                 << endl; 
          }
  
          if (i > 0) {((char*)__xlx_apatb_param_q31)[0*3+0] = q31_pc_buffer[0].range(7, 0).to_int64();
((char*)__xlx_apatb_param_q31)[0*3+1] = q31_pc_buffer[0].range(15, 8).to_int64();
((char*)__xlx_apatb_param_q31)[0*3+2] = q31_pc_buffer[0].range(23, 16).to_int64();
}
        } // end transaction
      } // end file is good
    } // end post check logic bolck
  {
      static ifstream rtl_tv_out_file;
      if (!rtl_tv_out_file.is_open()) {
        rtl_tv_out_file.open(AUTOTB_TVOUT_PC_q32);
        if (rtl_tv_out_file.good()) {
          rtl_tv_out_file >> AESL_token;
          if (AESL_token != "[[[runtime]]]")
            exit(1);
        }
      }
  
      if (rtl_tv_out_file.good()) {
        rtl_tv_out_file >> AESL_token; 
        rtl_tv_out_file >> AESL_num;  // transaction number
        if (AESL_token != "[[transaction]]") {
          cerr << "Unexpected token: " << AESL_token << endl;
          exit(1);
        }
        if (atoi(AESL_num.c_str()) == AESL_transaction_pc) {
          std::vector<sc_bv<24> > q32_pc_buffer(1);
          int i = 0;
          bool has_unknown_value = false;
          rtl_tv_out_file >> AESL_token; //data
          while (AESL_token != "[[/transaction]]"){

            has_unknown_value |= RTLOutputCheckAndReplacement(AESL_token);
  
            // push token into output port buffer
            if (AESL_token != "") {
              q32_pc_buffer[i] = AESL_token.c_str();;
              i++;
            }
  
            rtl_tv_out_file >> AESL_token; //data or [[/transaction]]
            if (AESL_token == "[[[/runtime]]]" || rtl_tv_out_file.eof())
              exit(1);
          }
          if (has_unknown_value) {
            cerr << "WARNING: [SIM 212-201] RTL produces unknown value 'x' or 'X' on port " 
                 << "q32" << ", possible cause: There are uninitialized variables in the C design."
                 << endl; 
          }
  
          if (i > 0) {((char*)__xlx_apatb_param_q32)[0*3+0] = q32_pc_buffer[0].range(7, 0).to_int64();
((char*)__xlx_apatb_param_q32)[0*3+1] = q32_pc_buffer[0].range(15, 8).to_int64();
((char*)__xlx_apatb_param_q32)[0*3+2] = q32_pc_buffer[0].range(23, 16).to_int64();
}
        } // end transaction
      } // end file is good
    } // end post check logic bolck
  {
      static ifstream rtl_tv_out_file;
      if (!rtl_tv_out_file.is_open()) {
        rtl_tv_out_file.open(AUTOTB_TVOUT_PC_q33);
        if (rtl_tv_out_file.good()) {
          rtl_tv_out_file >> AESL_token;
          if (AESL_token != "[[[runtime]]]")
            exit(1);
        }
      }
  
      if (rtl_tv_out_file.good()) {
        rtl_tv_out_file >> AESL_token; 
        rtl_tv_out_file >> AESL_num;  // transaction number
        if (AESL_token != "[[transaction]]") {
          cerr << "Unexpected token: " << AESL_token << endl;
          exit(1);
        }
        if (atoi(AESL_num.c_str()) == AESL_transaction_pc) {
          std::vector<sc_bv<24> > q33_pc_buffer(1);
          int i = 0;
          bool has_unknown_value = false;
          rtl_tv_out_file >> AESL_token; //data
          while (AESL_token != "[[/transaction]]"){

            has_unknown_value |= RTLOutputCheckAndReplacement(AESL_token);
  
            // push token into output port buffer
            if (AESL_token != "") {
              q33_pc_buffer[i] = AESL_token.c_str();;
              i++;
            }
  
            rtl_tv_out_file >> AESL_token; //data or [[/transaction]]
            if (AESL_token == "[[[/runtime]]]" || rtl_tv_out_file.eof())
              exit(1);
          }
          if (has_unknown_value) {
            cerr << "WARNING: [SIM 212-201] RTL produces unknown value 'x' or 'X' on port " 
                 << "q33" << ", possible cause: There are uninitialized variables in the C design."
                 << endl; 
          }
  
          if (i > 0) {((char*)__xlx_apatb_param_q33)[0*3+0] = q33_pc_buffer[0].range(7, 0).to_int64();
((char*)__xlx_apatb_param_q33)[0*3+1] = q33_pc_buffer[0].range(15, 8).to_int64();
((char*)__xlx_apatb_param_q33)[0*3+2] = q33_pc_buffer[0].range(23, 16).to_int64();
}
        } // end transaction
      } // end file is good
    } // end post check logic bolck
  {
      static ifstream rtl_tv_out_file;
      if (!rtl_tv_out_file.is_open()) {
        rtl_tv_out_file.open(AUTOTB_TVOUT_PC_q34);
        if (rtl_tv_out_file.good()) {
          rtl_tv_out_file >> AESL_token;
          if (AESL_token != "[[[runtime]]]")
            exit(1);
        }
      }
  
      if (rtl_tv_out_file.good()) {
        rtl_tv_out_file >> AESL_token; 
        rtl_tv_out_file >> AESL_num;  // transaction number
        if (AESL_token != "[[transaction]]") {
          cerr << "Unexpected token: " << AESL_token << endl;
          exit(1);
        }
        if (atoi(AESL_num.c_str()) == AESL_transaction_pc) {
          std::vector<sc_bv<24> > q34_pc_buffer(1);
          int i = 0;
          bool has_unknown_value = false;
          rtl_tv_out_file >> AESL_token; //data
          while (AESL_token != "[[/transaction]]"){

            has_unknown_value |= RTLOutputCheckAndReplacement(AESL_token);
  
            // push token into output port buffer
            if (AESL_token != "") {
              q34_pc_buffer[i] = AESL_token.c_str();;
              i++;
            }
  
            rtl_tv_out_file >> AESL_token; //data or [[/transaction]]
            if (AESL_token == "[[[/runtime]]]" || rtl_tv_out_file.eof())
              exit(1);
          }
          if (has_unknown_value) {
            cerr << "WARNING: [SIM 212-201] RTL produces unknown value 'x' or 'X' on port " 
                 << "q34" << ", possible cause: There are uninitialized variables in the C design."
                 << endl; 
          }
  
          if (i > 0) {((char*)__xlx_apatb_param_q34)[0*3+0] = q34_pc_buffer[0].range(7, 0).to_int64();
((char*)__xlx_apatb_param_q34)[0*3+1] = q34_pc_buffer[0].range(15, 8).to_int64();
((char*)__xlx_apatb_param_q34)[0*3+2] = q34_pc_buffer[0].range(23, 16).to_int64();
}
        } // end transaction
      } // end file is good
    } // end post check logic bolck
  {
      static ifstream rtl_tv_out_file;
      if (!rtl_tv_out_file.is_open()) {
        rtl_tv_out_file.open(AUTOTB_TVOUT_PC_q41);
        if (rtl_tv_out_file.good()) {
          rtl_tv_out_file >> AESL_token;
          if (AESL_token != "[[[runtime]]]")
            exit(1);
        }
      }
  
      if (rtl_tv_out_file.good()) {
        rtl_tv_out_file >> AESL_token; 
        rtl_tv_out_file >> AESL_num;  // transaction number
        if (AESL_token != "[[transaction]]") {
          cerr << "Unexpected token: " << AESL_token << endl;
          exit(1);
        }
        if (atoi(AESL_num.c_str()) == AESL_transaction_pc) {
          std::vector<sc_bv<24> > q41_pc_buffer(1);
          int i = 0;
          bool has_unknown_value = false;
          rtl_tv_out_file >> AESL_token; //data
          while (AESL_token != "[[/transaction]]"){

            has_unknown_value |= RTLOutputCheckAndReplacement(AESL_token);
  
            // push token into output port buffer
            if (AESL_token != "") {
              q41_pc_buffer[i] = AESL_token.c_str();;
              i++;
            }
  
            rtl_tv_out_file >> AESL_token; //data or [[/transaction]]
            if (AESL_token == "[[[/runtime]]]" || rtl_tv_out_file.eof())
              exit(1);
          }
          if (has_unknown_value) {
            cerr << "WARNING: [SIM 212-201] RTL produces unknown value 'x' or 'X' on port " 
                 << "q41" << ", possible cause: There are uninitialized variables in the C design."
                 << endl; 
          }
  
          if (i > 0) {((char*)__xlx_apatb_param_q41)[0*3+0] = q41_pc_buffer[0].range(7, 0).to_int64();
((char*)__xlx_apatb_param_q41)[0*3+1] = q41_pc_buffer[0].range(15, 8).to_int64();
((char*)__xlx_apatb_param_q41)[0*3+2] = q41_pc_buffer[0].range(23, 16).to_int64();
}
        } // end transaction
      } // end file is good
    } // end post check logic bolck
  {
      static ifstream rtl_tv_out_file;
      if (!rtl_tv_out_file.is_open()) {
        rtl_tv_out_file.open(AUTOTB_TVOUT_PC_q42);
        if (rtl_tv_out_file.good()) {
          rtl_tv_out_file >> AESL_token;
          if (AESL_token != "[[[runtime]]]")
            exit(1);
        }
      }
  
      if (rtl_tv_out_file.good()) {
        rtl_tv_out_file >> AESL_token; 
        rtl_tv_out_file >> AESL_num;  // transaction number
        if (AESL_token != "[[transaction]]") {
          cerr << "Unexpected token: " << AESL_token << endl;
          exit(1);
        }
        if (atoi(AESL_num.c_str()) == AESL_transaction_pc) {
          std::vector<sc_bv<24> > q42_pc_buffer(1);
          int i = 0;
          bool has_unknown_value = false;
          rtl_tv_out_file >> AESL_token; //data
          while (AESL_token != "[[/transaction]]"){

            has_unknown_value |= RTLOutputCheckAndReplacement(AESL_token);
  
            // push token into output port buffer
            if (AESL_token != "") {
              q42_pc_buffer[i] = AESL_token.c_str();;
              i++;
            }
  
            rtl_tv_out_file >> AESL_token; //data or [[/transaction]]
            if (AESL_token == "[[[/runtime]]]" || rtl_tv_out_file.eof())
              exit(1);
          }
          if (has_unknown_value) {
            cerr << "WARNING: [SIM 212-201] RTL produces unknown value 'x' or 'X' on port " 
                 << "q42" << ", possible cause: There are uninitialized variables in the C design."
                 << endl; 
          }
  
          if (i > 0) {((char*)__xlx_apatb_param_q42)[0*3+0] = q42_pc_buffer[0].range(7, 0).to_int64();
((char*)__xlx_apatb_param_q42)[0*3+1] = q42_pc_buffer[0].range(15, 8).to_int64();
((char*)__xlx_apatb_param_q42)[0*3+2] = q42_pc_buffer[0].range(23, 16).to_int64();
}
        } // end transaction
      } // end file is good
    } // end post check logic bolck
  {
      static ifstream rtl_tv_out_file;
      if (!rtl_tv_out_file.is_open()) {
        rtl_tv_out_file.open(AUTOTB_TVOUT_PC_q43);
        if (rtl_tv_out_file.good()) {
          rtl_tv_out_file >> AESL_token;
          if (AESL_token != "[[[runtime]]]")
            exit(1);
        }
      }
  
      if (rtl_tv_out_file.good()) {
        rtl_tv_out_file >> AESL_token; 
        rtl_tv_out_file >> AESL_num;  // transaction number
        if (AESL_token != "[[transaction]]") {
          cerr << "Unexpected token: " << AESL_token << endl;
          exit(1);
        }
        if (atoi(AESL_num.c_str()) == AESL_transaction_pc) {
          std::vector<sc_bv<24> > q43_pc_buffer(1);
          int i = 0;
          bool has_unknown_value = false;
          rtl_tv_out_file >> AESL_token; //data
          while (AESL_token != "[[/transaction]]"){

            has_unknown_value |= RTLOutputCheckAndReplacement(AESL_token);
  
            // push token into output port buffer
            if (AESL_token != "") {
              q43_pc_buffer[i] = AESL_token.c_str();;
              i++;
            }
  
            rtl_tv_out_file >> AESL_token; //data or [[/transaction]]
            if (AESL_token == "[[[/runtime]]]" || rtl_tv_out_file.eof())
              exit(1);
          }
          if (has_unknown_value) {
            cerr << "WARNING: [SIM 212-201] RTL produces unknown value 'x' or 'X' on port " 
                 << "q43" << ", possible cause: There are uninitialized variables in the C design."
                 << endl; 
          }
  
          if (i > 0) {((char*)__xlx_apatb_param_q43)[0*3+0] = q43_pc_buffer[0].range(7, 0).to_int64();
((char*)__xlx_apatb_param_q43)[0*3+1] = q43_pc_buffer[0].range(15, 8).to_int64();
((char*)__xlx_apatb_param_q43)[0*3+2] = q43_pc_buffer[0].range(23, 16).to_int64();
}
        } // end transaction
      } // end file is good
    } // end post check logic bolck
  {
      static ifstream rtl_tv_out_file;
      if (!rtl_tv_out_file.is_open()) {
        rtl_tv_out_file.open(AUTOTB_TVOUT_PC_q44);
        if (rtl_tv_out_file.good()) {
          rtl_tv_out_file >> AESL_token;
          if (AESL_token != "[[[runtime]]]")
            exit(1);
        }
      }
  
      if (rtl_tv_out_file.good()) {
        rtl_tv_out_file >> AESL_token; 
        rtl_tv_out_file >> AESL_num;  // transaction number
        if (AESL_token != "[[transaction]]") {
          cerr << "Unexpected token: " << AESL_token << endl;
          exit(1);
        }
        if (atoi(AESL_num.c_str()) == AESL_transaction_pc) {
          std::vector<sc_bv<24> > q44_pc_buffer(1);
          int i = 0;
          bool has_unknown_value = false;
          rtl_tv_out_file >> AESL_token; //data
          while (AESL_token != "[[/transaction]]"){

            has_unknown_value |= RTLOutputCheckAndReplacement(AESL_token);
  
            // push token into output port buffer
            if (AESL_token != "") {
              q44_pc_buffer[i] = AESL_token.c_str();;
              i++;
            }
  
            rtl_tv_out_file >> AESL_token; //data or [[/transaction]]
            if (AESL_token == "[[[/runtime]]]" || rtl_tv_out_file.eof())
              exit(1);
          }
          if (has_unknown_value) {
            cerr << "WARNING: [SIM 212-201] RTL produces unknown value 'x' or 'X' on port " 
                 << "q44" << ", possible cause: There are uninitialized variables in the C design."
                 << endl; 
          }
  
          if (i > 0) {((char*)__xlx_apatb_param_q44)[0*3+0] = q44_pc_buffer[0].range(7, 0).to_int64();
((char*)__xlx_apatb_param_q44)[0*3+1] = q44_pc_buffer[0].range(15, 8).to_int64();
((char*)__xlx_apatb_param_q44)[0*3+2] = q44_pc_buffer[0].range(23, 16).to_int64();
}
        } // end transaction
      } // end file is good
    } // end post check logic bolck
  {
      static ifstream rtl_tv_out_file;
      if (!rtl_tv_out_file.is_open()) {
        rtl_tv_out_file.open(AUTOTB_TVOUT_PC_r11);
        if (rtl_tv_out_file.good()) {
          rtl_tv_out_file >> AESL_token;
          if (AESL_token != "[[[runtime]]]")
            exit(1);
        }
      }
  
      if (rtl_tv_out_file.good()) {
        rtl_tv_out_file >> AESL_token; 
        rtl_tv_out_file >> AESL_num;  // transaction number
        if (AESL_token != "[[transaction]]") {
          cerr << "Unexpected token: " << AESL_token << endl;
          exit(1);
        }
        if (atoi(AESL_num.c_str()) == AESL_transaction_pc) {
          std::vector<sc_bv<24> > r11_pc_buffer(1);
          int i = 0;
          bool has_unknown_value = false;
          rtl_tv_out_file >> AESL_token; //data
          while (AESL_token != "[[/transaction]]"){

            has_unknown_value |= RTLOutputCheckAndReplacement(AESL_token);
  
            // push token into output port buffer
            if (AESL_token != "") {
              r11_pc_buffer[i] = AESL_token.c_str();;
              i++;
            }
  
            rtl_tv_out_file >> AESL_token; //data or [[/transaction]]
            if (AESL_token == "[[[/runtime]]]" || rtl_tv_out_file.eof())
              exit(1);
          }
          if (has_unknown_value) {
            cerr << "WARNING: [SIM 212-201] RTL produces unknown value 'x' or 'X' on port " 
                 << "r11" << ", possible cause: There are uninitialized variables in the C design."
                 << endl; 
          }
  
          if (i > 0) {((char*)__xlx_apatb_param_r11)[0*3+0] = r11_pc_buffer[0].range(7, 0).to_int64();
((char*)__xlx_apatb_param_r11)[0*3+1] = r11_pc_buffer[0].range(15, 8).to_int64();
((char*)__xlx_apatb_param_r11)[0*3+2] = r11_pc_buffer[0].range(23, 16).to_int64();
}
        } // end transaction
      } // end file is good
    } // end post check logic bolck
  {
      static ifstream rtl_tv_out_file;
      if (!rtl_tv_out_file.is_open()) {
        rtl_tv_out_file.open(AUTOTB_TVOUT_PC_r12);
        if (rtl_tv_out_file.good()) {
          rtl_tv_out_file >> AESL_token;
          if (AESL_token != "[[[runtime]]]")
            exit(1);
        }
      }
  
      if (rtl_tv_out_file.good()) {
        rtl_tv_out_file >> AESL_token; 
        rtl_tv_out_file >> AESL_num;  // transaction number
        if (AESL_token != "[[transaction]]") {
          cerr << "Unexpected token: " << AESL_token << endl;
          exit(1);
        }
        if (atoi(AESL_num.c_str()) == AESL_transaction_pc) {
          std::vector<sc_bv<24> > r12_pc_buffer(1);
          int i = 0;
          bool has_unknown_value = false;
          rtl_tv_out_file >> AESL_token; //data
          while (AESL_token != "[[/transaction]]"){

            has_unknown_value |= RTLOutputCheckAndReplacement(AESL_token);
  
            // push token into output port buffer
            if (AESL_token != "") {
              r12_pc_buffer[i] = AESL_token.c_str();;
              i++;
            }
  
            rtl_tv_out_file >> AESL_token; //data or [[/transaction]]
            if (AESL_token == "[[[/runtime]]]" || rtl_tv_out_file.eof())
              exit(1);
          }
          if (has_unknown_value) {
            cerr << "WARNING: [SIM 212-201] RTL produces unknown value 'x' or 'X' on port " 
                 << "r12" << ", possible cause: There are uninitialized variables in the C design."
                 << endl; 
          }
  
          if (i > 0) {((char*)__xlx_apatb_param_r12)[0*3+0] = r12_pc_buffer[0].range(7, 0).to_int64();
((char*)__xlx_apatb_param_r12)[0*3+1] = r12_pc_buffer[0].range(15, 8).to_int64();
((char*)__xlx_apatb_param_r12)[0*3+2] = r12_pc_buffer[0].range(23, 16).to_int64();
}
        } // end transaction
      } // end file is good
    } // end post check logic bolck
  {
      static ifstream rtl_tv_out_file;
      if (!rtl_tv_out_file.is_open()) {
        rtl_tv_out_file.open(AUTOTB_TVOUT_PC_r13);
        if (rtl_tv_out_file.good()) {
          rtl_tv_out_file >> AESL_token;
          if (AESL_token != "[[[runtime]]]")
            exit(1);
        }
      }
  
      if (rtl_tv_out_file.good()) {
        rtl_tv_out_file >> AESL_token; 
        rtl_tv_out_file >> AESL_num;  // transaction number
        if (AESL_token != "[[transaction]]") {
          cerr << "Unexpected token: " << AESL_token << endl;
          exit(1);
        }
        if (atoi(AESL_num.c_str()) == AESL_transaction_pc) {
          std::vector<sc_bv<24> > r13_pc_buffer(1);
          int i = 0;
          bool has_unknown_value = false;
          rtl_tv_out_file >> AESL_token; //data
          while (AESL_token != "[[/transaction]]"){

            has_unknown_value |= RTLOutputCheckAndReplacement(AESL_token);
  
            // push token into output port buffer
            if (AESL_token != "") {
              r13_pc_buffer[i] = AESL_token.c_str();;
              i++;
            }
  
            rtl_tv_out_file >> AESL_token; //data or [[/transaction]]
            if (AESL_token == "[[[/runtime]]]" || rtl_tv_out_file.eof())
              exit(1);
          }
          if (has_unknown_value) {
            cerr << "WARNING: [SIM 212-201] RTL produces unknown value 'x' or 'X' on port " 
                 << "r13" << ", possible cause: There are uninitialized variables in the C design."
                 << endl; 
          }
  
          if (i > 0) {((char*)__xlx_apatb_param_r13)[0*3+0] = r13_pc_buffer[0].range(7, 0).to_int64();
((char*)__xlx_apatb_param_r13)[0*3+1] = r13_pc_buffer[0].range(15, 8).to_int64();
((char*)__xlx_apatb_param_r13)[0*3+2] = r13_pc_buffer[0].range(23, 16).to_int64();
}
        } // end transaction
      } // end file is good
    } // end post check logic bolck
  {
      static ifstream rtl_tv_out_file;
      if (!rtl_tv_out_file.is_open()) {
        rtl_tv_out_file.open(AUTOTB_TVOUT_PC_r14);
        if (rtl_tv_out_file.good()) {
          rtl_tv_out_file >> AESL_token;
          if (AESL_token != "[[[runtime]]]")
            exit(1);
        }
      }
  
      if (rtl_tv_out_file.good()) {
        rtl_tv_out_file >> AESL_token; 
        rtl_tv_out_file >> AESL_num;  // transaction number
        if (AESL_token != "[[transaction]]") {
          cerr << "Unexpected token: " << AESL_token << endl;
          exit(1);
        }
        if (atoi(AESL_num.c_str()) == AESL_transaction_pc) {
          std::vector<sc_bv<24> > r14_pc_buffer(1);
          int i = 0;
          bool has_unknown_value = false;
          rtl_tv_out_file >> AESL_token; //data
          while (AESL_token != "[[/transaction]]"){

            has_unknown_value |= RTLOutputCheckAndReplacement(AESL_token);
  
            // push token into output port buffer
            if (AESL_token != "") {
              r14_pc_buffer[i] = AESL_token.c_str();;
              i++;
            }
  
            rtl_tv_out_file >> AESL_token; //data or [[/transaction]]
            if (AESL_token == "[[[/runtime]]]" || rtl_tv_out_file.eof())
              exit(1);
          }
          if (has_unknown_value) {
            cerr << "WARNING: [SIM 212-201] RTL produces unknown value 'x' or 'X' on port " 
                 << "r14" << ", possible cause: There are uninitialized variables in the C design."
                 << endl; 
          }
  
          if (i > 0) {((char*)__xlx_apatb_param_r14)[0*3+0] = r14_pc_buffer[0].range(7, 0).to_int64();
((char*)__xlx_apatb_param_r14)[0*3+1] = r14_pc_buffer[0].range(15, 8).to_int64();
((char*)__xlx_apatb_param_r14)[0*3+2] = r14_pc_buffer[0].range(23, 16).to_int64();
}
        } // end transaction
      } // end file is good
    } // end post check logic bolck
  {
      static ifstream rtl_tv_out_file;
      if (!rtl_tv_out_file.is_open()) {
        rtl_tv_out_file.open(AUTOTB_TVOUT_PC_r22);
        if (rtl_tv_out_file.good()) {
          rtl_tv_out_file >> AESL_token;
          if (AESL_token != "[[[runtime]]]")
            exit(1);
        }
      }
  
      if (rtl_tv_out_file.good()) {
        rtl_tv_out_file >> AESL_token; 
        rtl_tv_out_file >> AESL_num;  // transaction number
        if (AESL_token != "[[transaction]]") {
          cerr << "Unexpected token: " << AESL_token << endl;
          exit(1);
        }
        if (atoi(AESL_num.c_str()) == AESL_transaction_pc) {
          std::vector<sc_bv<24> > r22_pc_buffer(1);
          int i = 0;
          bool has_unknown_value = false;
          rtl_tv_out_file >> AESL_token; //data
          while (AESL_token != "[[/transaction]]"){

            has_unknown_value |= RTLOutputCheckAndReplacement(AESL_token);
  
            // push token into output port buffer
            if (AESL_token != "") {
              r22_pc_buffer[i] = AESL_token.c_str();;
              i++;
            }
  
            rtl_tv_out_file >> AESL_token; //data or [[/transaction]]
            if (AESL_token == "[[[/runtime]]]" || rtl_tv_out_file.eof())
              exit(1);
          }
          if (has_unknown_value) {
            cerr << "WARNING: [SIM 212-201] RTL produces unknown value 'x' or 'X' on port " 
                 << "r22" << ", possible cause: There are uninitialized variables in the C design."
                 << endl; 
          }
  
          if (i > 0) {((char*)__xlx_apatb_param_r22)[0*3+0] = r22_pc_buffer[0].range(7, 0).to_int64();
((char*)__xlx_apatb_param_r22)[0*3+1] = r22_pc_buffer[0].range(15, 8).to_int64();
((char*)__xlx_apatb_param_r22)[0*3+2] = r22_pc_buffer[0].range(23, 16).to_int64();
}
        } // end transaction
      } // end file is good
    } // end post check logic bolck
  {
      static ifstream rtl_tv_out_file;
      if (!rtl_tv_out_file.is_open()) {
        rtl_tv_out_file.open(AUTOTB_TVOUT_PC_r23);
        if (rtl_tv_out_file.good()) {
          rtl_tv_out_file >> AESL_token;
          if (AESL_token != "[[[runtime]]]")
            exit(1);
        }
      }
  
      if (rtl_tv_out_file.good()) {
        rtl_tv_out_file >> AESL_token; 
        rtl_tv_out_file >> AESL_num;  // transaction number
        if (AESL_token != "[[transaction]]") {
          cerr << "Unexpected token: " << AESL_token << endl;
          exit(1);
        }
        if (atoi(AESL_num.c_str()) == AESL_transaction_pc) {
          std::vector<sc_bv<24> > r23_pc_buffer(1);
          int i = 0;
          bool has_unknown_value = false;
          rtl_tv_out_file >> AESL_token; //data
          while (AESL_token != "[[/transaction]]"){

            has_unknown_value |= RTLOutputCheckAndReplacement(AESL_token);
  
            // push token into output port buffer
            if (AESL_token != "") {
              r23_pc_buffer[i] = AESL_token.c_str();;
              i++;
            }
  
            rtl_tv_out_file >> AESL_token; //data or [[/transaction]]
            if (AESL_token == "[[[/runtime]]]" || rtl_tv_out_file.eof())
              exit(1);
          }
          if (has_unknown_value) {
            cerr << "WARNING: [SIM 212-201] RTL produces unknown value 'x' or 'X' on port " 
                 << "r23" << ", possible cause: There are uninitialized variables in the C design."
                 << endl; 
          }
  
          if (i > 0) {((char*)__xlx_apatb_param_r23)[0*3+0] = r23_pc_buffer[0].range(7, 0).to_int64();
((char*)__xlx_apatb_param_r23)[0*3+1] = r23_pc_buffer[0].range(15, 8).to_int64();
((char*)__xlx_apatb_param_r23)[0*3+2] = r23_pc_buffer[0].range(23, 16).to_int64();
}
        } // end transaction
      } // end file is good
    } // end post check logic bolck
  {
      static ifstream rtl_tv_out_file;
      if (!rtl_tv_out_file.is_open()) {
        rtl_tv_out_file.open(AUTOTB_TVOUT_PC_r24);
        if (rtl_tv_out_file.good()) {
          rtl_tv_out_file >> AESL_token;
          if (AESL_token != "[[[runtime]]]")
            exit(1);
        }
      }
  
      if (rtl_tv_out_file.good()) {
        rtl_tv_out_file >> AESL_token; 
        rtl_tv_out_file >> AESL_num;  // transaction number
        if (AESL_token != "[[transaction]]") {
          cerr << "Unexpected token: " << AESL_token << endl;
          exit(1);
        }
        if (atoi(AESL_num.c_str()) == AESL_transaction_pc) {
          std::vector<sc_bv<24> > r24_pc_buffer(1);
          int i = 0;
          bool has_unknown_value = false;
          rtl_tv_out_file >> AESL_token; //data
          while (AESL_token != "[[/transaction]]"){

            has_unknown_value |= RTLOutputCheckAndReplacement(AESL_token);
  
            // push token into output port buffer
            if (AESL_token != "") {
              r24_pc_buffer[i] = AESL_token.c_str();;
              i++;
            }
  
            rtl_tv_out_file >> AESL_token; //data or [[/transaction]]
            if (AESL_token == "[[[/runtime]]]" || rtl_tv_out_file.eof())
              exit(1);
          }
          if (has_unknown_value) {
            cerr << "WARNING: [SIM 212-201] RTL produces unknown value 'x' or 'X' on port " 
                 << "r24" << ", possible cause: There are uninitialized variables in the C design."
                 << endl; 
          }
  
          if (i > 0) {((char*)__xlx_apatb_param_r24)[0*3+0] = r24_pc_buffer[0].range(7, 0).to_int64();
((char*)__xlx_apatb_param_r24)[0*3+1] = r24_pc_buffer[0].range(15, 8).to_int64();
((char*)__xlx_apatb_param_r24)[0*3+2] = r24_pc_buffer[0].range(23, 16).to_int64();
}
        } // end transaction
      } // end file is good
    } // end post check logic bolck
  {
      static ifstream rtl_tv_out_file;
      if (!rtl_tv_out_file.is_open()) {
        rtl_tv_out_file.open(AUTOTB_TVOUT_PC_r33);
        if (rtl_tv_out_file.good()) {
          rtl_tv_out_file >> AESL_token;
          if (AESL_token != "[[[runtime]]]")
            exit(1);
        }
      }
  
      if (rtl_tv_out_file.good()) {
        rtl_tv_out_file >> AESL_token; 
        rtl_tv_out_file >> AESL_num;  // transaction number
        if (AESL_token != "[[transaction]]") {
          cerr << "Unexpected token: " << AESL_token << endl;
          exit(1);
        }
        if (atoi(AESL_num.c_str()) == AESL_transaction_pc) {
          std::vector<sc_bv<24> > r33_pc_buffer(1);
          int i = 0;
          bool has_unknown_value = false;
          rtl_tv_out_file >> AESL_token; //data
          while (AESL_token != "[[/transaction]]"){

            has_unknown_value |= RTLOutputCheckAndReplacement(AESL_token);
  
            // push token into output port buffer
            if (AESL_token != "") {
              r33_pc_buffer[i] = AESL_token.c_str();;
              i++;
            }
  
            rtl_tv_out_file >> AESL_token; //data or [[/transaction]]
            if (AESL_token == "[[[/runtime]]]" || rtl_tv_out_file.eof())
              exit(1);
          }
          if (has_unknown_value) {
            cerr << "WARNING: [SIM 212-201] RTL produces unknown value 'x' or 'X' on port " 
                 << "r33" << ", possible cause: There are uninitialized variables in the C design."
                 << endl; 
          }
  
          if (i > 0) {((char*)__xlx_apatb_param_r33)[0*3+0] = r33_pc_buffer[0].range(7, 0).to_int64();
((char*)__xlx_apatb_param_r33)[0*3+1] = r33_pc_buffer[0].range(15, 8).to_int64();
((char*)__xlx_apatb_param_r33)[0*3+2] = r33_pc_buffer[0].range(23, 16).to_int64();
}
        } // end transaction
      } // end file is good
    } // end post check logic bolck
  {
      static ifstream rtl_tv_out_file;
      if (!rtl_tv_out_file.is_open()) {
        rtl_tv_out_file.open(AUTOTB_TVOUT_PC_r34);
        if (rtl_tv_out_file.good()) {
          rtl_tv_out_file >> AESL_token;
          if (AESL_token != "[[[runtime]]]")
            exit(1);
        }
      }
  
      if (rtl_tv_out_file.good()) {
        rtl_tv_out_file >> AESL_token; 
        rtl_tv_out_file >> AESL_num;  // transaction number
        if (AESL_token != "[[transaction]]") {
          cerr << "Unexpected token: " << AESL_token << endl;
          exit(1);
        }
        if (atoi(AESL_num.c_str()) == AESL_transaction_pc) {
          std::vector<sc_bv<24> > r34_pc_buffer(1);
          int i = 0;
          bool has_unknown_value = false;
          rtl_tv_out_file >> AESL_token; //data
          while (AESL_token != "[[/transaction]]"){

            has_unknown_value |= RTLOutputCheckAndReplacement(AESL_token);
  
            // push token into output port buffer
            if (AESL_token != "") {
              r34_pc_buffer[i] = AESL_token.c_str();;
              i++;
            }
  
            rtl_tv_out_file >> AESL_token; //data or [[/transaction]]
            if (AESL_token == "[[[/runtime]]]" || rtl_tv_out_file.eof())
              exit(1);
          }
          if (has_unknown_value) {
            cerr << "WARNING: [SIM 212-201] RTL produces unknown value 'x' or 'X' on port " 
                 << "r34" << ", possible cause: There are uninitialized variables in the C design."
                 << endl; 
          }
  
          if (i > 0) {((char*)__xlx_apatb_param_r34)[0*3+0] = r34_pc_buffer[0].range(7, 0).to_int64();
((char*)__xlx_apatb_param_r34)[0*3+1] = r34_pc_buffer[0].range(15, 8).to_int64();
((char*)__xlx_apatb_param_r34)[0*3+2] = r34_pc_buffer[0].range(23, 16).to_int64();
}
        } // end transaction
      } // end file is good
    } // end post check logic bolck
  {
      static ifstream rtl_tv_out_file;
      if (!rtl_tv_out_file.is_open()) {
        rtl_tv_out_file.open(AUTOTB_TVOUT_PC_r44);
        if (rtl_tv_out_file.good()) {
          rtl_tv_out_file >> AESL_token;
          if (AESL_token != "[[[runtime]]]")
            exit(1);
        }
      }
  
      if (rtl_tv_out_file.good()) {
        rtl_tv_out_file >> AESL_token; 
        rtl_tv_out_file >> AESL_num;  // transaction number
        if (AESL_token != "[[transaction]]") {
          cerr << "Unexpected token: " << AESL_token << endl;
          exit(1);
        }
        if (atoi(AESL_num.c_str()) == AESL_transaction_pc) {
          std::vector<sc_bv<24> > r44_pc_buffer(1);
          int i = 0;
          bool has_unknown_value = false;
          rtl_tv_out_file >> AESL_token; //data
          while (AESL_token != "[[/transaction]]"){

            has_unknown_value |= RTLOutputCheckAndReplacement(AESL_token);
  
            // push token into output port buffer
            if (AESL_token != "") {
              r44_pc_buffer[i] = AESL_token.c_str();;
              i++;
            }
  
            rtl_tv_out_file >> AESL_token; //data or [[/transaction]]
            if (AESL_token == "[[[/runtime]]]" || rtl_tv_out_file.eof())
              exit(1);
          }
          if (has_unknown_value) {
            cerr << "WARNING: [SIM 212-201] RTL produces unknown value 'x' or 'X' on port " 
                 << "r44" << ", possible cause: There are uninitialized variables in the C design."
                 << endl; 
          }
  
          if (i > 0) {((char*)__xlx_apatb_param_r44)[0*3+0] = r44_pc_buffer[0].range(7, 0).to_int64();
((char*)__xlx_apatb_param_r44)[0*3+1] = r44_pc_buffer[0].range(15, 8).to_int64();
((char*)__xlx_apatb_param_r44)[0*3+2] = r44_pc_buffer[0].range(23, 16).to_int64();
}
        } // end transaction
      } // end file is good
    } // end post check logic bolck
  {
      static ifstream rtl_tv_out_file;
      if (!rtl_tv_out_file.is_open()) {
        rtl_tv_out_file.open(AUTOTB_TVOUT_PC_done);
        if (rtl_tv_out_file.good()) {
          rtl_tv_out_file >> AESL_token;
          if (AESL_token != "[[[runtime]]]")
            exit(1);
        }
      }
  
      if (rtl_tv_out_file.good()) {
        rtl_tv_out_file >> AESL_token; 
        rtl_tv_out_file >> AESL_num;  // transaction number
        if (AESL_token != "[[transaction]]") {
          cerr << "Unexpected token: " << AESL_token << endl;
          exit(1);
        }
        if (atoi(AESL_num.c_str()) == AESL_transaction_pc) {
          std::vector<sc_bv<24> > done_pc_buffer(1);
          int i = 0;
          bool has_unknown_value = false;
          rtl_tv_out_file >> AESL_token; //data
          while (AESL_token != "[[/transaction]]"){

            has_unknown_value |= RTLOutputCheckAndReplacement(AESL_token);
  
            // push token into output port buffer
            if (AESL_token != "") {
              done_pc_buffer[i] = AESL_token.c_str();;
              i++;
            }
  
            rtl_tv_out_file >> AESL_token; //data or [[/transaction]]
            if (AESL_token == "[[[/runtime]]]" || rtl_tv_out_file.eof())
              exit(1);
          }
          if (has_unknown_value) {
            cerr << "WARNING: [SIM 212-201] RTL produces unknown value 'x' or 'X' on port " 
                 << "done" << ", possible cause: There are uninitialized variables in the C design."
                 << endl; 
          }
  
          if (i > 0) {((char*)__xlx_apatb_param_done)[0*3+0] = done_pc_buffer[0].range(7, 0).to_int64();
((char*)__xlx_apatb_param_done)[0*3+1] = done_pc_buffer[0].range(15, 8).to_int64();
((char*)__xlx_apatb_param_done)[0*3+2] = done_pc_buffer[0].range(23, 16).to_int64();
}
        } // end transaction
      } // end file is good
    } // end post check logic bolck
  
    AESL_transaction_pc++;
    return ;
  }
static unsigned AESL_transaction;
static INTER_TCL_FILE tcl_file(INTER_TCL);
std::vector<char> __xlx_sprintf_buffer(1024);
CodeState = ENTER_WRAPC;
CodeState = DUMP_INPUTS;
// print a11 Transactions
{
aesl_fh.write(AUTOTB_TVIN_a11, begin_str(AESL_transaction));
{
auto *pos = (unsigned char*)__xlx_apatb_param_a11;
aesl_fh.write(AUTOTB_TVIN_a11, formatData(pos, 24));
}
  tcl_file.set_num(1, &tcl_file.a11_depth);
aesl_fh.write(AUTOTB_TVIN_a11, end_str());
}

// print a12 Transactions
{
aesl_fh.write(AUTOTB_TVIN_a12, begin_str(AESL_transaction));
{
auto *pos = (unsigned char*)__xlx_apatb_param_a12;
aesl_fh.write(AUTOTB_TVIN_a12, formatData(pos, 24));
}
  tcl_file.set_num(1, &tcl_file.a12_depth);
aesl_fh.write(AUTOTB_TVIN_a12, end_str());
}

// print a13 Transactions
{
aesl_fh.write(AUTOTB_TVIN_a13, begin_str(AESL_transaction));
{
auto *pos = (unsigned char*)__xlx_apatb_param_a13;
aesl_fh.write(AUTOTB_TVIN_a13, formatData(pos, 24));
}
  tcl_file.set_num(1, &tcl_file.a13_depth);
aesl_fh.write(AUTOTB_TVIN_a13, end_str());
}

// print a14 Transactions
{
aesl_fh.write(AUTOTB_TVIN_a14, begin_str(AESL_transaction));
{
auto *pos = (unsigned char*)__xlx_apatb_param_a14;
aesl_fh.write(AUTOTB_TVIN_a14, formatData(pos, 24));
}
  tcl_file.set_num(1, &tcl_file.a14_depth);
aesl_fh.write(AUTOTB_TVIN_a14, end_str());
}

// print a21 Transactions
{
aesl_fh.write(AUTOTB_TVIN_a21, begin_str(AESL_transaction));
{
auto *pos = (unsigned char*)__xlx_apatb_param_a21;
aesl_fh.write(AUTOTB_TVIN_a21, formatData(pos, 24));
}
  tcl_file.set_num(1, &tcl_file.a21_depth);
aesl_fh.write(AUTOTB_TVIN_a21, end_str());
}

// print a22 Transactions
{
aesl_fh.write(AUTOTB_TVIN_a22, begin_str(AESL_transaction));
{
auto *pos = (unsigned char*)__xlx_apatb_param_a22;
aesl_fh.write(AUTOTB_TVIN_a22, formatData(pos, 24));
}
  tcl_file.set_num(1, &tcl_file.a22_depth);
aesl_fh.write(AUTOTB_TVIN_a22, end_str());
}

// print a23 Transactions
{
aesl_fh.write(AUTOTB_TVIN_a23, begin_str(AESL_transaction));
{
auto *pos = (unsigned char*)__xlx_apatb_param_a23;
aesl_fh.write(AUTOTB_TVIN_a23, formatData(pos, 24));
}
  tcl_file.set_num(1, &tcl_file.a23_depth);
aesl_fh.write(AUTOTB_TVIN_a23, end_str());
}

// print a24 Transactions
{
aesl_fh.write(AUTOTB_TVIN_a24, begin_str(AESL_transaction));
{
auto *pos = (unsigned char*)__xlx_apatb_param_a24;
aesl_fh.write(AUTOTB_TVIN_a24, formatData(pos, 24));
}
  tcl_file.set_num(1, &tcl_file.a24_depth);
aesl_fh.write(AUTOTB_TVIN_a24, end_str());
}

// print a31 Transactions
{
aesl_fh.write(AUTOTB_TVIN_a31, begin_str(AESL_transaction));
{
auto *pos = (unsigned char*)__xlx_apatb_param_a31;
aesl_fh.write(AUTOTB_TVIN_a31, formatData(pos, 24));
}
  tcl_file.set_num(1, &tcl_file.a31_depth);
aesl_fh.write(AUTOTB_TVIN_a31, end_str());
}

// print a32 Transactions
{
aesl_fh.write(AUTOTB_TVIN_a32, begin_str(AESL_transaction));
{
auto *pos = (unsigned char*)__xlx_apatb_param_a32;
aesl_fh.write(AUTOTB_TVIN_a32, formatData(pos, 24));
}
  tcl_file.set_num(1, &tcl_file.a32_depth);
aesl_fh.write(AUTOTB_TVIN_a32, end_str());
}

// print a33 Transactions
{
aesl_fh.write(AUTOTB_TVIN_a33, begin_str(AESL_transaction));
{
auto *pos = (unsigned char*)__xlx_apatb_param_a33;
aesl_fh.write(AUTOTB_TVIN_a33, formatData(pos, 24));
}
  tcl_file.set_num(1, &tcl_file.a33_depth);
aesl_fh.write(AUTOTB_TVIN_a33, end_str());
}

// print a34 Transactions
{
aesl_fh.write(AUTOTB_TVIN_a34, begin_str(AESL_transaction));
{
auto *pos = (unsigned char*)__xlx_apatb_param_a34;
aesl_fh.write(AUTOTB_TVIN_a34, formatData(pos, 24));
}
  tcl_file.set_num(1, &tcl_file.a34_depth);
aesl_fh.write(AUTOTB_TVIN_a34, end_str());
}

// print a41 Transactions
{
aesl_fh.write(AUTOTB_TVIN_a41, begin_str(AESL_transaction));
{
auto *pos = (unsigned char*)__xlx_apatb_param_a41;
aesl_fh.write(AUTOTB_TVIN_a41, formatData(pos, 24));
}
  tcl_file.set_num(1, &tcl_file.a41_depth);
aesl_fh.write(AUTOTB_TVIN_a41, end_str());
}

// print a42 Transactions
{
aesl_fh.write(AUTOTB_TVIN_a42, begin_str(AESL_transaction));
{
auto *pos = (unsigned char*)__xlx_apatb_param_a42;
aesl_fh.write(AUTOTB_TVIN_a42, formatData(pos, 24));
}
  tcl_file.set_num(1, &tcl_file.a42_depth);
aesl_fh.write(AUTOTB_TVIN_a42, end_str());
}

// print a43 Transactions
{
aesl_fh.write(AUTOTB_TVIN_a43, begin_str(AESL_transaction));
{
auto *pos = (unsigned char*)__xlx_apatb_param_a43;
aesl_fh.write(AUTOTB_TVIN_a43, formatData(pos, 24));
}
  tcl_file.set_num(1, &tcl_file.a43_depth);
aesl_fh.write(AUTOTB_TVIN_a43, end_str());
}

// print a44 Transactions
{
aesl_fh.write(AUTOTB_TVIN_a44, begin_str(AESL_transaction));
{
auto *pos = (unsigned char*)__xlx_apatb_param_a44;
aesl_fh.write(AUTOTB_TVIN_a44, formatData(pos, 24));
}
  tcl_file.set_num(1, &tcl_file.a44_depth);
aesl_fh.write(AUTOTB_TVIN_a44, end_str());
}

// print q11 Transactions
{
aesl_fh.write(AUTOTB_TVIN_q11, begin_str(AESL_transaction));
{
auto *pos = (unsigned char*)__xlx_apatb_param_q11;
aesl_fh.write(AUTOTB_TVIN_q11, formatData(pos, 24));
}
  tcl_file.set_num(1, &tcl_file.q11_depth);
aesl_fh.write(AUTOTB_TVIN_q11, end_str());
}

// print q12 Transactions
{
aesl_fh.write(AUTOTB_TVIN_q12, begin_str(AESL_transaction));
{
auto *pos = (unsigned char*)__xlx_apatb_param_q12;
aesl_fh.write(AUTOTB_TVIN_q12, formatData(pos, 24));
}
  tcl_file.set_num(1, &tcl_file.q12_depth);
aesl_fh.write(AUTOTB_TVIN_q12, end_str());
}

// print q13 Transactions
{
aesl_fh.write(AUTOTB_TVIN_q13, begin_str(AESL_transaction));
{
auto *pos = (unsigned char*)__xlx_apatb_param_q13;
aesl_fh.write(AUTOTB_TVIN_q13, formatData(pos, 24));
}
  tcl_file.set_num(1, &tcl_file.q13_depth);
aesl_fh.write(AUTOTB_TVIN_q13, end_str());
}

// print q14 Transactions
{
aesl_fh.write(AUTOTB_TVIN_q14, begin_str(AESL_transaction));
{
auto *pos = (unsigned char*)__xlx_apatb_param_q14;
aesl_fh.write(AUTOTB_TVIN_q14, formatData(pos, 24));
}
  tcl_file.set_num(1, &tcl_file.q14_depth);
aesl_fh.write(AUTOTB_TVIN_q14, end_str());
}

// print q21 Transactions
{
aesl_fh.write(AUTOTB_TVIN_q21, begin_str(AESL_transaction));
{
auto *pos = (unsigned char*)__xlx_apatb_param_q21;
aesl_fh.write(AUTOTB_TVIN_q21, formatData(pos, 24));
}
  tcl_file.set_num(1, &tcl_file.q21_depth);
aesl_fh.write(AUTOTB_TVIN_q21, end_str());
}

// print q22 Transactions
{
aesl_fh.write(AUTOTB_TVIN_q22, begin_str(AESL_transaction));
{
auto *pos = (unsigned char*)__xlx_apatb_param_q22;
aesl_fh.write(AUTOTB_TVIN_q22, formatData(pos, 24));
}
  tcl_file.set_num(1, &tcl_file.q22_depth);
aesl_fh.write(AUTOTB_TVIN_q22, end_str());
}

// print q23 Transactions
{
aesl_fh.write(AUTOTB_TVIN_q23, begin_str(AESL_transaction));
{
auto *pos = (unsigned char*)__xlx_apatb_param_q23;
aesl_fh.write(AUTOTB_TVIN_q23, formatData(pos, 24));
}
  tcl_file.set_num(1, &tcl_file.q23_depth);
aesl_fh.write(AUTOTB_TVIN_q23, end_str());
}

// print q24 Transactions
{
aesl_fh.write(AUTOTB_TVIN_q24, begin_str(AESL_transaction));
{
auto *pos = (unsigned char*)__xlx_apatb_param_q24;
aesl_fh.write(AUTOTB_TVIN_q24, formatData(pos, 24));
}
  tcl_file.set_num(1, &tcl_file.q24_depth);
aesl_fh.write(AUTOTB_TVIN_q24, end_str());
}

// print q31 Transactions
{
aesl_fh.write(AUTOTB_TVIN_q31, begin_str(AESL_transaction));
{
auto *pos = (unsigned char*)__xlx_apatb_param_q31;
aesl_fh.write(AUTOTB_TVIN_q31, formatData(pos, 24));
}
  tcl_file.set_num(1, &tcl_file.q31_depth);
aesl_fh.write(AUTOTB_TVIN_q31, end_str());
}

// print q32 Transactions
{
aesl_fh.write(AUTOTB_TVIN_q32, begin_str(AESL_transaction));
{
auto *pos = (unsigned char*)__xlx_apatb_param_q32;
aesl_fh.write(AUTOTB_TVIN_q32, formatData(pos, 24));
}
  tcl_file.set_num(1, &tcl_file.q32_depth);
aesl_fh.write(AUTOTB_TVIN_q32, end_str());
}

// print q33 Transactions
{
aesl_fh.write(AUTOTB_TVIN_q33, begin_str(AESL_transaction));
{
auto *pos = (unsigned char*)__xlx_apatb_param_q33;
aesl_fh.write(AUTOTB_TVIN_q33, formatData(pos, 24));
}
  tcl_file.set_num(1, &tcl_file.q33_depth);
aesl_fh.write(AUTOTB_TVIN_q33, end_str());
}

// print q34 Transactions
{
aesl_fh.write(AUTOTB_TVIN_q34, begin_str(AESL_transaction));
{
auto *pos = (unsigned char*)__xlx_apatb_param_q34;
aesl_fh.write(AUTOTB_TVIN_q34, formatData(pos, 24));
}
  tcl_file.set_num(1, &tcl_file.q34_depth);
aesl_fh.write(AUTOTB_TVIN_q34, end_str());
}

// print q41 Transactions
{
aesl_fh.write(AUTOTB_TVIN_q41, begin_str(AESL_transaction));
{
auto *pos = (unsigned char*)__xlx_apatb_param_q41;
aesl_fh.write(AUTOTB_TVIN_q41, formatData(pos, 24));
}
  tcl_file.set_num(1, &tcl_file.q41_depth);
aesl_fh.write(AUTOTB_TVIN_q41, end_str());
}

// print q42 Transactions
{
aesl_fh.write(AUTOTB_TVIN_q42, begin_str(AESL_transaction));
{
auto *pos = (unsigned char*)__xlx_apatb_param_q42;
aesl_fh.write(AUTOTB_TVIN_q42, formatData(pos, 24));
}
  tcl_file.set_num(1, &tcl_file.q42_depth);
aesl_fh.write(AUTOTB_TVIN_q42, end_str());
}

// print q43 Transactions
{
aesl_fh.write(AUTOTB_TVIN_q43, begin_str(AESL_transaction));
{
auto *pos = (unsigned char*)__xlx_apatb_param_q43;
aesl_fh.write(AUTOTB_TVIN_q43, formatData(pos, 24));
}
  tcl_file.set_num(1, &tcl_file.q43_depth);
aesl_fh.write(AUTOTB_TVIN_q43, end_str());
}

// print q44 Transactions
{
aesl_fh.write(AUTOTB_TVIN_q44, begin_str(AESL_transaction));
{
auto *pos = (unsigned char*)__xlx_apatb_param_q44;
aesl_fh.write(AUTOTB_TVIN_q44, formatData(pos, 24));
}
  tcl_file.set_num(1, &tcl_file.q44_depth);
aesl_fh.write(AUTOTB_TVIN_q44, end_str());
}

// print r11 Transactions
{
aesl_fh.write(AUTOTB_TVIN_r11, begin_str(AESL_transaction));
{
auto *pos = (unsigned char*)__xlx_apatb_param_r11;
aesl_fh.write(AUTOTB_TVIN_r11, formatData(pos, 24));
}
  tcl_file.set_num(1, &tcl_file.r11_depth);
aesl_fh.write(AUTOTB_TVIN_r11, end_str());
}

// print r12 Transactions
{
aesl_fh.write(AUTOTB_TVIN_r12, begin_str(AESL_transaction));
{
auto *pos = (unsigned char*)__xlx_apatb_param_r12;
aesl_fh.write(AUTOTB_TVIN_r12, formatData(pos, 24));
}
  tcl_file.set_num(1, &tcl_file.r12_depth);
aesl_fh.write(AUTOTB_TVIN_r12, end_str());
}

// print r13 Transactions
{
aesl_fh.write(AUTOTB_TVIN_r13, begin_str(AESL_transaction));
{
auto *pos = (unsigned char*)__xlx_apatb_param_r13;
aesl_fh.write(AUTOTB_TVIN_r13, formatData(pos, 24));
}
  tcl_file.set_num(1, &tcl_file.r13_depth);
aesl_fh.write(AUTOTB_TVIN_r13, end_str());
}

// print r14 Transactions
{
aesl_fh.write(AUTOTB_TVIN_r14, begin_str(AESL_transaction));
{
auto *pos = (unsigned char*)__xlx_apatb_param_r14;
aesl_fh.write(AUTOTB_TVIN_r14, formatData(pos, 24));
}
  tcl_file.set_num(1, &tcl_file.r14_depth);
aesl_fh.write(AUTOTB_TVIN_r14, end_str());
}

// print r22 Transactions
{
aesl_fh.write(AUTOTB_TVIN_r22, begin_str(AESL_transaction));
{
auto *pos = (unsigned char*)__xlx_apatb_param_r22;
aesl_fh.write(AUTOTB_TVIN_r22, formatData(pos, 24));
}
  tcl_file.set_num(1, &tcl_file.r22_depth);
aesl_fh.write(AUTOTB_TVIN_r22, end_str());
}

// print r23 Transactions
{
aesl_fh.write(AUTOTB_TVIN_r23, begin_str(AESL_transaction));
{
auto *pos = (unsigned char*)__xlx_apatb_param_r23;
aesl_fh.write(AUTOTB_TVIN_r23, formatData(pos, 24));
}
  tcl_file.set_num(1, &tcl_file.r23_depth);
aesl_fh.write(AUTOTB_TVIN_r23, end_str());
}

// print r24 Transactions
{
aesl_fh.write(AUTOTB_TVIN_r24, begin_str(AESL_transaction));
{
auto *pos = (unsigned char*)__xlx_apatb_param_r24;
aesl_fh.write(AUTOTB_TVIN_r24, formatData(pos, 24));
}
  tcl_file.set_num(1, &tcl_file.r24_depth);
aesl_fh.write(AUTOTB_TVIN_r24, end_str());
}

// print r33 Transactions
{
aesl_fh.write(AUTOTB_TVIN_r33, begin_str(AESL_transaction));
{
auto *pos = (unsigned char*)__xlx_apatb_param_r33;
aesl_fh.write(AUTOTB_TVIN_r33, formatData(pos, 24));
}
  tcl_file.set_num(1, &tcl_file.r33_depth);
aesl_fh.write(AUTOTB_TVIN_r33, end_str());
}

// print r34 Transactions
{
aesl_fh.write(AUTOTB_TVIN_r34, begin_str(AESL_transaction));
{
auto *pos = (unsigned char*)__xlx_apatb_param_r34;
aesl_fh.write(AUTOTB_TVIN_r34, formatData(pos, 24));
}
  tcl_file.set_num(1, &tcl_file.r34_depth);
aesl_fh.write(AUTOTB_TVIN_r34, end_str());
}

// print r44 Transactions
{
aesl_fh.write(AUTOTB_TVIN_r44, begin_str(AESL_transaction));
{
auto *pos = (unsigned char*)__xlx_apatb_param_r44;
aesl_fh.write(AUTOTB_TVIN_r44, formatData(pos, 24));
}
  tcl_file.set_num(1, &tcl_file.r44_depth);
aesl_fh.write(AUTOTB_TVIN_r44, end_str());
}

// print din Transactions
{
aesl_fh.write(AUTOTB_TVIN_din, begin_str(AESL_transaction));
{
auto *pos = (unsigned char*)__xlx_apatb_param_din;
aesl_fh.write(AUTOTB_TVIN_din, formatData(pos, 24));
}
  tcl_file.set_num(1, &tcl_file.din_depth);
aesl_fh.write(AUTOTB_TVIN_din, end_str());
}

// print done Transactions
{
aesl_fh.write(AUTOTB_TVIN_done, begin_str(AESL_transaction));
{
auto *pos = (unsigned char*)__xlx_apatb_param_done;
aesl_fh.write(AUTOTB_TVIN_done, formatData(pos, 24));
}
  tcl_file.set_num(1, &tcl_file.done_depth);
aesl_fh.write(AUTOTB_TVIN_done, end_str());
}

CodeState = CALL_C_DUT;
qr_hw_stub_wrapper(__xlx_apatb_param_a11, __xlx_apatb_param_a12, __xlx_apatb_param_a13, __xlx_apatb_param_a14, __xlx_apatb_param_a21, __xlx_apatb_param_a22, __xlx_apatb_param_a23, __xlx_apatb_param_a24, __xlx_apatb_param_a31, __xlx_apatb_param_a32, __xlx_apatb_param_a33, __xlx_apatb_param_a34, __xlx_apatb_param_a41, __xlx_apatb_param_a42, __xlx_apatb_param_a43, __xlx_apatb_param_a44, __xlx_apatb_param_q11, __xlx_apatb_param_q12, __xlx_apatb_param_q13, __xlx_apatb_param_q14, __xlx_apatb_param_q21, __xlx_apatb_param_q22, __xlx_apatb_param_q23, __xlx_apatb_param_q24, __xlx_apatb_param_q31, __xlx_apatb_param_q32, __xlx_apatb_param_q33, __xlx_apatb_param_q34, __xlx_apatb_param_q41, __xlx_apatb_param_q42, __xlx_apatb_param_q43, __xlx_apatb_param_q44, __xlx_apatb_param_r11, __xlx_apatb_param_r12, __xlx_apatb_param_r13, __xlx_apatb_param_r14, __xlx_apatb_param_r22, __xlx_apatb_param_r23, __xlx_apatb_param_r24, __xlx_apatb_param_r33, __xlx_apatb_param_r34, __xlx_apatb_param_r44, __xlx_apatb_param_din, __xlx_apatb_param_done);
CodeState = DUMP_OUTPUTS;
// print q11 Transactions
{
aesl_fh.write(AUTOTB_TVOUT_q11, begin_str(AESL_transaction));
{
auto *pos = (unsigned char*)__xlx_apatb_param_q11;
aesl_fh.write(AUTOTB_TVOUT_q11, formatData(pos, 24));
}
  tcl_file.set_num(1, &tcl_file.q11_depth);
aesl_fh.write(AUTOTB_TVOUT_q11, end_str());
}

// print q12 Transactions
{
aesl_fh.write(AUTOTB_TVOUT_q12, begin_str(AESL_transaction));
{
auto *pos = (unsigned char*)__xlx_apatb_param_q12;
aesl_fh.write(AUTOTB_TVOUT_q12, formatData(pos, 24));
}
  tcl_file.set_num(1, &tcl_file.q12_depth);
aesl_fh.write(AUTOTB_TVOUT_q12, end_str());
}

// print q13 Transactions
{
aesl_fh.write(AUTOTB_TVOUT_q13, begin_str(AESL_transaction));
{
auto *pos = (unsigned char*)__xlx_apatb_param_q13;
aesl_fh.write(AUTOTB_TVOUT_q13, formatData(pos, 24));
}
  tcl_file.set_num(1, &tcl_file.q13_depth);
aesl_fh.write(AUTOTB_TVOUT_q13, end_str());
}

// print q14 Transactions
{
aesl_fh.write(AUTOTB_TVOUT_q14, begin_str(AESL_transaction));
{
auto *pos = (unsigned char*)__xlx_apatb_param_q14;
aesl_fh.write(AUTOTB_TVOUT_q14, formatData(pos, 24));
}
  tcl_file.set_num(1, &tcl_file.q14_depth);
aesl_fh.write(AUTOTB_TVOUT_q14, end_str());
}

// print q21 Transactions
{
aesl_fh.write(AUTOTB_TVOUT_q21, begin_str(AESL_transaction));
{
auto *pos = (unsigned char*)__xlx_apatb_param_q21;
aesl_fh.write(AUTOTB_TVOUT_q21, formatData(pos, 24));
}
  tcl_file.set_num(1, &tcl_file.q21_depth);
aesl_fh.write(AUTOTB_TVOUT_q21, end_str());
}

// print q22 Transactions
{
aesl_fh.write(AUTOTB_TVOUT_q22, begin_str(AESL_transaction));
{
auto *pos = (unsigned char*)__xlx_apatb_param_q22;
aesl_fh.write(AUTOTB_TVOUT_q22, formatData(pos, 24));
}
  tcl_file.set_num(1, &tcl_file.q22_depth);
aesl_fh.write(AUTOTB_TVOUT_q22, end_str());
}

// print q23 Transactions
{
aesl_fh.write(AUTOTB_TVOUT_q23, begin_str(AESL_transaction));
{
auto *pos = (unsigned char*)__xlx_apatb_param_q23;
aesl_fh.write(AUTOTB_TVOUT_q23, formatData(pos, 24));
}
  tcl_file.set_num(1, &tcl_file.q23_depth);
aesl_fh.write(AUTOTB_TVOUT_q23, end_str());
}

// print q24 Transactions
{
aesl_fh.write(AUTOTB_TVOUT_q24, begin_str(AESL_transaction));
{
auto *pos = (unsigned char*)__xlx_apatb_param_q24;
aesl_fh.write(AUTOTB_TVOUT_q24, formatData(pos, 24));
}
  tcl_file.set_num(1, &tcl_file.q24_depth);
aesl_fh.write(AUTOTB_TVOUT_q24, end_str());
}

// print q31 Transactions
{
aesl_fh.write(AUTOTB_TVOUT_q31, begin_str(AESL_transaction));
{
auto *pos = (unsigned char*)__xlx_apatb_param_q31;
aesl_fh.write(AUTOTB_TVOUT_q31, formatData(pos, 24));
}
  tcl_file.set_num(1, &tcl_file.q31_depth);
aesl_fh.write(AUTOTB_TVOUT_q31, end_str());
}

// print q32 Transactions
{
aesl_fh.write(AUTOTB_TVOUT_q32, begin_str(AESL_transaction));
{
auto *pos = (unsigned char*)__xlx_apatb_param_q32;
aesl_fh.write(AUTOTB_TVOUT_q32, formatData(pos, 24));
}
  tcl_file.set_num(1, &tcl_file.q32_depth);
aesl_fh.write(AUTOTB_TVOUT_q32, end_str());
}

// print q33 Transactions
{
aesl_fh.write(AUTOTB_TVOUT_q33, begin_str(AESL_transaction));
{
auto *pos = (unsigned char*)__xlx_apatb_param_q33;
aesl_fh.write(AUTOTB_TVOUT_q33, formatData(pos, 24));
}
  tcl_file.set_num(1, &tcl_file.q33_depth);
aesl_fh.write(AUTOTB_TVOUT_q33, end_str());
}

// print q34 Transactions
{
aesl_fh.write(AUTOTB_TVOUT_q34, begin_str(AESL_transaction));
{
auto *pos = (unsigned char*)__xlx_apatb_param_q34;
aesl_fh.write(AUTOTB_TVOUT_q34, formatData(pos, 24));
}
  tcl_file.set_num(1, &tcl_file.q34_depth);
aesl_fh.write(AUTOTB_TVOUT_q34, end_str());
}

// print q41 Transactions
{
aesl_fh.write(AUTOTB_TVOUT_q41, begin_str(AESL_transaction));
{
auto *pos = (unsigned char*)__xlx_apatb_param_q41;
aesl_fh.write(AUTOTB_TVOUT_q41, formatData(pos, 24));
}
  tcl_file.set_num(1, &tcl_file.q41_depth);
aesl_fh.write(AUTOTB_TVOUT_q41, end_str());
}

// print q42 Transactions
{
aesl_fh.write(AUTOTB_TVOUT_q42, begin_str(AESL_transaction));
{
auto *pos = (unsigned char*)__xlx_apatb_param_q42;
aesl_fh.write(AUTOTB_TVOUT_q42, formatData(pos, 24));
}
  tcl_file.set_num(1, &tcl_file.q42_depth);
aesl_fh.write(AUTOTB_TVOUT_q42, end_str());
}

// print q43 Transactions
{
aesl_fh.write(AUTOTB_TVOUT_q43, begin_str(AESL_transaction));
{
auto *pos = (unsigned char*)__xlx_apatb_param_q43;
aesl_fh.write(AUTOTB_TVOUT_q43, formatData(pos, 24));
}
  tcl_file.set_num(1, &tcl_file.q43_depth);
aesl_fh.write(AUTOTB_TVOUT_q43, end_str());
}

// print q44 Transactions
{
aesl_fh.write(AUTOTB_TVOUT_q44, begin_str(AESL_transaction));
{
auto *pos = (unsigned char*)__xlx_apatb_param_q44;
aesl_fh.write(AUTOTB_TVOUT_q44, formatData(pos, 24));
}
  tcl_file.set_num(1, &tcl_file.q44_depth);
aesl_fh.write(AUTOTB_TVOUT_q44, end_str());
}

// print r11 Transactions
{
aesl_fh.write(AUTOTB_TVOUT_r11, begin_str(AESL_transaction));
{
auto *pos = (unsigned char*)__xlx_apatb_param_r11;
aesl_fh.write(AUTOTB_TVOUT_r11, formatData(pos, 24));
}
  tcl_file.set_num(1, &tcl_file.r11_depth);
aesl_fh.write(AUTOTB_TVOUT_r11, end_str());
}

// print r12 Transactions
{
aesl_fh.write(AUTOTB_TVOUT_r12, begin_str(AESL_transaction));
{
auto *pos = (unsigned char*)__xlx_apatb_param_r12;
aesl_fh.write(AUTOTB_TVOUT_r12, formatData(pos, 24));
}
  tcl_file.set_num(1, &tcl_file.r12_depth);
aesl_fh.write(AUTOTB_TVOUT_r12, end_str());
}

// print r13 Transactions
{
aesl_fh.write(AUTOTB_TVOUT_r13, begin_str(AESL_transaction));
{
auto *pos = (unsigned char*)__xlx_apatb_param_r13;
aesl_fh.write(AUTOTB_TVOUT_r13, formatData(pos, 24));
}
  tcl_file.set_num(1, &tcl_file.r13_depth);
aesl_fh.write(AUTOTB_TVOUT_r13, end_str());
}

// print r14 Transactions
{
aesl_fh.write(AUTOTB_TVOUT_r14, begin_str(AESL_transaction));
{
auto *pos = (unsigned char*)__xlx_apatb_param_r14;
aesl_fh.write(AUTOTB_TVOUT_r14, formatData(pos, 24));
}
  tcl_file.set_num(1, &tcl_file.r14_depth);
aesl_fh.write(AUTOTB_TVOUT_r14, end_str());
}

// print r22 Transactions
{
aesl_fh.write(AUTOTB_TVOUT_r22, begin_str(AESL_transaction));
{
auto *pos = (unsigned char*)__xlx_apatb_param_r22;
aesl_fh.write(AUTOTB_TVOUT_r22, formatData(pos, 24));
}
  tcl_file.set_num(1, &tcl_file.r22_depth);
aesl_fh.write(AUTOTB_TVOUT_r22, end_str());
}

// print r23 Transactions
{
aesl_fh.write(AUTOTB_TVOUT_r23, begin_str(AESL_transaction));
{
auto *pos = (unsigned char*)__xlx_apatb_param_r23;
aesl_fh.write(AUTOTB_TVOUT_r23, formatData(pos, 24));
}
  tcl_file.set_num(1, &tcl_file.r23_depth);
aesl_fh.write(AUTOTB_TVOUT_r23, end_str());
}

// print r24 Transactions
{
aesl_fh.write(AUTOTB_TVOUT_r24, begin_str(AESL_transaction));
{
auto *pos = (unsigned char*)__xlx_apatb_param_r24;
aesl_fh.write(AUTOTB_TVOUT_r24, formatData(pos, 24));
}
  tcl_file.set_num(1, &tcl_file.r24_depth);
aesl_fh.write(AUTOTB_TVOUT_r24, end_str());
}

// print r33 Transactions
{
aesl_fh.write(AUTOTB_TVOUT_r33, begin_str(AESL_transaction));
{
auto *pos = (unsigned char*)__xlx_apatb_param_r33;
aesl_fh.write(AUTOTB_TVOUT_r33, formatData(pos, 24));
}
  tcl_file.set_num(1, &tcl_file.r33_depth);
aesl_fh.write(AUTOTB_TVOUT_r33, end_str());
}

// print r34 Transactions
{
aesl_fh.write(AUTOTB_TVOUT_r34, begin_str(AESL_transaction));
{
auto *pos = (unsigned char*)__xlx_apatb_param_r34;
aesl_fh.write(AUTOTB_TVOUT_r34, formatData(pos, 24));
}
  tcl_file.set_num(1, &tcl_file.r34_depth);
aesl_fh.write(AUTOTB_TVOUT_r34, end_str());
}

// print r44 Transactions
{
aesl_fh.write(AUTOTB_TVOUT_r44, begin_str(AESL_transaction));
{
auto *pos = (unsigned char*)__xlx_apatb_param_r44;
aesl_fh.write(AUTOTB_TVOUT_r44, formatData(pos, 24));
}
  tcl_file.set_num(1, &tcl_file.r44_depth);
aesl_fh.write(AUTOTB_TVOUT_r44, end_str());
}

// print done Transactions
{
aesl_fh.write(AUTOTB_TVOUT_done, begin_str(AESL_transaction));
{
auto *pos = (unsigned char*)__xlx_apatb_param_done;
aesl_fh.write(AUTOTB_TVOUT_done, formatData(pos, 24));
}
  tcl_file.set_num(1, &tcl_file.done_depth);
aesl_fh.write(AUTOTB_TVOUT_done, end_str());
}

CodeState = DELETE_CHAR_BUFFERS;
AESL_transaction++;
tcl_file.set_num(AESL_transaction , &tcl_file.trans_num);
}
