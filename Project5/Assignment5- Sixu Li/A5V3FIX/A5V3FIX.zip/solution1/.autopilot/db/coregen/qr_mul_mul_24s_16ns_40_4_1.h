// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2022.1 (64-bit)
// Tool Version Limit: 2022.04
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef __qr_mul_mul_24s_16ns_40_4_1__HH__
#define __qr_mul_mul_24s_16ns_40_4_1__HH__
#include "qr_mul_mul_24s_16ns_40_4_1_DSP48_0.h"
#include <systemc>

template<
    int ID,
    int NUM_STAGE,
    int din0_WIDTH,
    int din1_WIDTH,
    int dout_WIDTH>
SC_MODULE(qr_mul_mul_24s_16ns_40_4_1) {
    sc_core::sc_in_clk clk;
    sc_core::sc_in<sc_dt::sc_logic> reset;
    sc_core::sc_in<sc_dt::sc_logic> ce;
    sc_core::sc_in< sc_dt::sc_lv<din0_WIDTH> >   din0;
    sc_core::sc_in< sc_dt::sc_lv<din1_WIDTH> >   din1;
    sc_core::sc_out< sc_dt::sc_lv<dout_WIDTH> >   dout;



    qr_mul_mul_24s_16ns_40_4_1_DSP48_0 qr_mul_mul_24s_16ns_40_4_1_DSP48_0_U;

    SC_CTOR(qr_mul_mul_24s_16ns_40_4_1):  qr_mul_mul_24s_16ns_40_4_1_DSP48_0_U ("qr_mul_mul_24s_16ns_40_4_1_DSP48_0_U") {
        qr_mul_mul_24s_16ns_40_4_1_DSP48_0_U.clk(clk);
        qr_mul_mul_24s_16ns_40_4_1_DSP48_0_U.rst(reset);
        qr_mul_mul_24s_16ns_40_4_1_DSP48_0_U.ce(ce);
        qr_mul_mul_24s_16ns_40_4_1_DSP48_0_U.a(din0);
        qr_mul_mul_24s_16ns_40_4_1_DSP48_0_U.b(din1);
        qr_mul_mul_24s_16ns_40_4_1_DSP48_0_U.p(dout);

    }

};

#endif //
