/**
* @file lab_five_qrd_sinit.c
*
* The implementation of the lab_five_qrd driver's static initialzation
* functionality.
*
* @note
*
* None
*
*/
#ifndef __linux__
#include "xstatus.h"
#include "xparameters.h"
#include "lab_five_qrd.h"
extern lab_five_qrd_Config lab_five_qrd_ConfigTable[];
/**
* Lookup the device configuration based on the unique device ID.  The table
* ConfigTable contains the configuration info for each device in the system.
*
* @param DeviceId is the device identifier to lookup.
*
* @return
*     - A pointer of data type lab_five_qrd_Config which
*    points to the device configuration if DeviceID is found.
*    - NULL if DeviceID is not found.
*
* @note    None.
*
*/
lab_five_qrd_Config *lab_five_qrd_LookupConfig(u16 DeviceId) {
    lab_five_qrd_Config *ConfigPtr = NULL;
    int Index;
    for (Index = 0; Index < XPAR_LAB_FIVE_QRD_NUM_INSTANCES; Index++) {
        if (lab_five_qrd_ConfigTable[Index].DeviceId == DeviceId) {
            ConfigPtr = &lab_five_qrd_ConfigTable[Index];
            break;
        }
    }
    return ConfigPtr;
}
int lab_five_qrd_Initialize(lab_five_qrd *InstancePtr, u16 DeviceId) {
    lab_five_qrd_Config *ConfigPtr;
    Xil_AssertNonvoid(InstancePtr != NULL);
    ConfigPtr = lab_five_qrd_LookupConfig(DeviceId);
    if (ConfigPtr == NULL) {
        InstancePtr->IsReady = 0;
        return (XST_DEVICE_NOT_FOUND);
    }
    return lab_five_qrd_CfgInitialize(InstancePtr, ConfigPtr);
}
#endif
