#include "lab_five_qrd.h"
#ifndef __linux__
int lab_five_qrd_CfgInitialize(lab_five_qrd *InstancePtr, lab_five_qrd_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->lab_five_qrd_array_input_BaseAddress = ConfigPtr->lab_five_qrd_array_input_BaseAddress;
    InstancePtr->lab_five_qrd_control_BaseAddress = ConfigPtr->lab_five_qrd_control_BaseAddress;
    InstancePtr->lab_five_qrd_output_BaseAddress = ConfigPtr->lab_five_qrd_output_BaseAddress;

    InstancePtr->IsReady = 1;
    return XST_SUCCESS;
}
#endif
void lab_five_qrd_sine_in3_write(lab_five_qrd *InstancePtr, int Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    lab_five_qrd_WriteReg(InstancePtr->lab_five_qrd_array_input_BaseAddress, 0, Data);
}
int lab_five_qrd_sine_in3_read(lab_five_qrd *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = lab_five_qrd_ReadReg(InstancePtr->lab_five_qrd_array_input_BaseAddress, 0);
    return Data;
}
void lab_five_qrd_sine_in2_write(lab_five_qrd *InstancePtr, int Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    lab_five_qrd_WriteReg(InstancePtr->lab_five_qrd_array_input_BaseAddress, 4, Data);
}
int lab_five_qrd_sine_in2_read(lab_five_qrd *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = lab_five_qrd_ReadReg(InstancePtr->lab_five_qrd_array_input_BaseAddress, 4);
    return Data;
}
void lab_five_qrd_sine_in1_write(lab_five_qrd *InstancePtr, int Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    lab_five_qrd_WriteReg(InstancePtr->lab_five_qrd_array_input_BaseAddress, 8, Data);
}
int lab_five_qrd_sine_in1_read(lab_five_qrd *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = lab_five_qrd_ReadReg(InstancePtr->lab_five_qrd_array_input_BaseAddress, 8);
    return Data;
}
void lab_five_qrd_sine_in_write(lab_five_qrd *InstancePtr, int Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    lab_five_qrd_WriteReg(InstancePtr->lab_five_qrd_array_input_BaseAddress, 12, Data);
}
int lab_five_qrd_sine_in_read(lab_five_qrd *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = lab_five_qrd_ReadReg(InstancePtr->lab_five_qrd_array_input_BaseAddress, 12);
    return Data;
}
void lab_five_qrd_read_sig_write(lab_five_qrd *InstancePtr, u32 Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    lab_five_qrd_WriteReg(InstancePtr->lab_five_qrd_control_BaseAddress, 0, Data);
}
u32 lab_five_qrd_read_sig_read(lab_five_qrd *InstancePtr) {

    u32 Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = lab_five_qrd_ReadReg(InstancePtr->lab_five_qrd_control_BaseAddress, 0);
    return Data;
}
void lab_five_qrd_ap_write_write(lab_five_qrd *InstancePtr, u32 Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    lab_five_qrd_WriteReg(InstancePtr->lab_five_qrd_control_BaseAddress, 4, Data);
}
u32 lab_five_qrd_ap_write_read(lab_five_qrd *InstancePtr) {

    u32 Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = lab_five_qrd_ReadReg(InstancePtr->lab_five_qrd_control_BaseAddress, 4);
    return Data;
}
void lab_five_qrd_ap_start_write(lab_five_qrd *InstancePtr, u32 Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    lab_five_qrd_WriteReg(InstancePtr->lab_five_qrd_control_BaseAddress, 8, Data);
}
u32 lab_five_qrd_ap_start_read(lab_five_qrd *InstancePtr) {

    u32 Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = lab_five_qrd_ReadReg(InstancePtr->lab_five_qrd_control_BaseAddress, 8);
    return Data;
}
void lab_five_qrd_ap_rst_write(lab_five_qrd *InstancePtr, u32 Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    lab_five_qrd_WriteReg(InstancePtr->lab_five_qrd_control_BaseAddress, 12, Data);
}
u32 lab_five_qrd_ap_rst_read(lab_five_qrd *InstancePtr) {

    u32 Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = lab_five_qrd_ReadReg(InstancePtr->lab_five_qrd_control_BaseAddress, 12);
    return Data;
}
int lab_five_qrd_row_2_read(lab_five_qrd *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = lab_five_qrd_ReadReg(InstancePtr->lab_five_qrd_output_BaseAddress, 0);
    return Data;
}
int lab_five_qrd_row_3_read(lab_five_qrd *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = lab_five_qrd_ReadReg(InstancePtr->lab_five_qrd_output_BaseAddress, 4);
    return Data;
}
int lab_five_qrd_row_1_read(lab_five_qrd *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = lab_five_qrd_ReadReg(InstancePtr->lab_five_qrd_output_BaseAddress, 8);
    return Data;
}
int lab_five_qrd_row_4_read(lab_five_qrd *InstancePtr) {

    int Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = lab_five_qrd_ReadReg(InstancePtr->lab_five_qrd_output_BaseAddress, 12);
    return Data;
}
u32 lab_five_qrd_qrd_done_read(lab_five_qrd *InstancePtr) {

    u32 Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = lab_five_qrd_ReadReg(InstancePtr->lab_five_qrd_output_BaseAddress, 16);
    return Data;
}
