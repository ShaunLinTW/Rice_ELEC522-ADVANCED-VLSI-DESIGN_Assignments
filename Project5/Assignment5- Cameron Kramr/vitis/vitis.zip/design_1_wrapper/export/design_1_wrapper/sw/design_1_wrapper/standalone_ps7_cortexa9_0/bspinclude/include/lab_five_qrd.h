#ifndef LAB_FIVE_QRD__H
#define LAB_FIVE_QRD__H
#ifdef __cplusplus
extern "C" {
#endif
/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "lab_five_qrd_hw.h"
/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
#else
typedef struct {
    u16 DeviceId;
    u32 lab_five_qrd_array_input_BaseAddress;
    u32 lab_five_qrd_control_BaseAddress;
    u32 lab_five_qrd_output_BaseAddress;
} lab_five_qrd_Config;
#endif
/**
* The lab_five_qrd driver instance data. The user is required to
* allocate a variable of this type for every lab_five_qrd device in the system.
* A pointer to a variable of this type is then passed to the driver
* API functions.
*/
typedef struct {
    u32 lab_five_qrd_array_input_BaseAddress;
    u32 lab_five_qrd_control_BaseAddress;
    u32 lab_five_qrd_output_BaseAddress;
    u32 IsReady;
} lab_five_qrd;
/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define lab_five_qrd_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define lab_five_qrd_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define lab_five_qrd_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define lab_five_qrd_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif
/************************** Function Prototypes *****************************/
#ifndef __linux__
int lab_five_qrd_Initialize(lab_five_qrd *InstancePtr, u16 DeviceId);
lab_five_qrd_Config* lab_five_qrd_LookupConfig(u16 DeviceId);
int lab_five_qrd_CfgInitialize(lab_five_qrd *InstancePtr, lab_five_qrd_Config *ConfigPtr);
#else
int lab_five_qrd_Initialize(lab_five_qrd *InstancePtr, const char* InstanceName);
int lab_five_qrd_Release(lab_five_qrd *InstancePtr);
#endif
/**
* Write to sine_in3 gateway of lab_five_qrd. Assignments are LSB-justified.
*
* @param	InstancePtr is the sine_in3 instance to operate on.
* @param	Data is value to be written to gateway sine_in3.
*
* @return	None.
*
* @note    .
*
*/
void lab_five_qrd_sine_in3_write(lab_five_qrd *InstancePtr, int Data);
/**
* Read from sine_in3 gateway of lab_five_qrd. Assignments are LSB-justified.
*
* @param	InstancePtr is the sine_in3 instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int lab_five_qrd_sine_in3_read(lab_five_qrd *InstancePtr);
/**
* Write to sine_in2 gateway of lab_five_qrd. Assignments are LSB-justified.
*
* @param	InstancePtr is the sine_in2 instance to operate on.
* @param	Data is value to be written to gateway sine_in2.
*
* @return	None.
*
* @note    .
*
*/
void lab_five_qrd_sine_in2_write(lab_five_qrd *InstancePtr, int Data);
/**
* Read from sine_in2 gateway of lab_five_qrd. Assignments are LSB-justified.
*
* @param	InstancePtr is the sine_in2 instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int lab_five_qrd_sine_in2_read(lab_five_qrd *InstancePtr);
/**
* Write to sine_in1 gateway of lab_five_qrd. Assignments are LSB-justified.
*
* @param	InstancePtr is the sine_in1 instance to operate on.
* @param	Data is value to be written to gateway sine_in1.
*
* @return	None.
*
* @note    .
*
*/
void lab_five_qrd_sine_in1_write(lab_five_qrd *InstancePtr, int Data);
/**
* Read from sine_in1 gateway of lab_five_qrd. Assignments are LSB-justified.
*
* @param	InstancePtr is the sine_in1 instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int lab_five_qrd_sine_in1_read(lab_five_qrd *InstancePtr);
/**
* Write to sine_in gateway of lab_five_qrd. Assignments are LSB-justified.
*
* @param	InstancePtr is the sine_in instance to operate on.
* @param	Data is value to be written to gateway sine_in.
*
* @return	None.
*
* @note    .
*
*/
void lab_five_qrd_sine_in_write(lab_five_qrd *InstancePtr, int Data);
/**
* Read from sine_in gateway of lab_five_qrd. Assignments are LSB-justified.
*
* @param	InstancePtr is the sine_in instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int lab_five_qrd_sine_in_read(lab_five_qrd *InstancePtr);
/**
* Write to read_sig gateway of lab_five_qrd. Assignments are LSB-justified.
*
* @param	InstancePtr is the read_sig instance to operate on.
* @param	Data is value to be written to gateway read_sig.
*
* @return	None.
*
* @note    .
*
*/
void lab_five_qrd_read_sig_write(lab_five_qrd *InstancePtr, u32 Data);
/**
* Read from read_sig gateway of lab_five_qrd. Assignments are LSB-justified.
*
* @param	InstancePtr is the read_sig instance to operate on.
*
* @return	u32
*
* @note    .
*
*/
u32 lab_five_qrd_read_sig_read(lab_five_qrd *InstancePtr);
/**
* Write to ap_write gateway of lab_five_qrd. Assignments are LSB-justified.
*
* @param	InstancePtr is the ap_write instance to operate on.
* @param	Data is value to be written to gateway ap_write.
*
* @return	None.
*
* @note    .
*
*/
void lab_five_qrd_ap_write_write(lab_five_qrd *InstancePtr, u32 Data);
/**
* Read from ap_write gateway of lab_five_qrd. Assignments are LSB-justified.
*
* @param	InstancePtr is the ap_write instance to operate on.
*
* @return	u32
*
* @note    .
*
*/
u32 lab_five_qrd_ap_write_read(lab_five_qrd *InstancePtr);
/**
* Write to ap_start gateway of lab_five_qrd. Assignments are LSB-justified.
*
* @param	InstancePtr is the ap_start instance to operate on.
* @param	Data is value to be written to gateway ap_start.
*
* @return	None.
*
* @note    .
*
*/
void lab_five_qrd_ap_start_write(lab_five_qrd *InstancePtr, u32 Data);
/**
* Read from ap_start gateway of lab_five_qrd. Assignments are LSB-justified.
*
* @param	InstancePtr is the ap_start instance to operate on.
*
* @return	u32
*
* @note    .
*
*/
u32 lab_five_qrd_ap_start_read(lab_five_qrd *InstancePtr);
/**
* Write to ap_rst gateway of lab_five_qrd. Assignments are LSB-justified.
*
* @param	InstancePtr is the ap_rst instance to operate on.
* @param	Data is value to be written to gateway ap_rst.
*
* @return	None.
*
* @note    .
*
*/
void lab_five_qrd_ap_rst_write(lab_five_qrd *InstancePtr, u32 Data);
/**
* Read from ap_rst gateway of lab_five_qrd. Assignments are LSB-justified.
*
* @param	InstancePtr is the ap_rst instance to operate on.
*
* @return	u32
*
* @note    .
*
*/
u32 lab_five_qrd_ap_rst_read(lab_five_qrd *InstancePtr);
/**
* Read from row_2 gateway of lab_five_qrd. Assignments are LSB-justified.
*
* @param	InstancePtr is the row_2 instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int lab_five_qrd_row_2_read(lab_five_qrd *InstancePtr);
/**
* Read from row_3 gateway of lab_five_qrd. Assignments are LSB-justified.
*
* @param	InstancePtr is the row_3 instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int lab_five_qrd_row_3_read(lab_five_qrd *InstancePtr);
/**
* Read from row_1 gateway of lab_five_qrd. Assignments are LSB-justified.
*
* @param	InstancePtr is the row_1 instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int lab_five_qrd_row_1_read(lab_five_qrd *InstancePtr);
/**
* Read from row_4 gateway of lab_five_qrd. Assignments are LSB-justified.
*
* @param	InstancePtr is the row_4 instance to operate on.
*
* @return	int
*
* @note    .
*
*/
int lab_five_qrd_row_4_read(lab_five_qrd *InstancePtr);
/**
* Read from qrd_done gateway of lab_five_qrd. Assignments are LSB-justified.
*
* @param	InstancePtr is the qrd_done instance to operate on.
*
* @return	u32
*
* @note    .
*
*/
u32 lab_five_qrd_qrd_done_read(lab_five_qrd *InstancePtr);
#ifdef __cplusplus
}
#endif
#endif
