/**
*
* @file lab_five_qrd_hw.h
*
* This header file contains identifiers and driver functions (or
* macros) that can be used to access the device.  The user should refer to the
* hardware device specification for more details of the device operation.
*/ 
#define LAB_FIVE_QRD_SINE_IN3 0x0/**< sine_in3 */
#define LAB_FIVE_QRD_SINE_IN2 0x4/**< sine_in2 */
#define LAB_FIVE_QRD_SINE_IN1 0x8/**< sine_in1 */
#define LAB_FIVE_QRD_SINE_IN 0xc/**< sine_in */
#define LAB_FIVE_QRD_READ_SIG 0x0/**< read_sig */
#define LAB_FIVE_QRD_AP_WRITE 0x4/**< ap_write */
#define LAB_FIVE_QRD_AP_START 0x8/**< ap_start */
#define LAB_FIVE_QRD_AP_RST 0xc/**< ap_rst */
#define LAB_FIVE_QRD_ROW_2 0x0/**< row_2 */
#define LAB_FIVE_QRD_ROW_3 0x4/**< row_3 */
#define LAB_FIVE_QRD_ROW_1 0x8/**< row_1 */
#define LAB_FIVE_QRD_ROW_4 0xc/**< row_4 */
#define LAB_FIVE_QRD_QRD_DONE 0x10/**< qrd_done */
